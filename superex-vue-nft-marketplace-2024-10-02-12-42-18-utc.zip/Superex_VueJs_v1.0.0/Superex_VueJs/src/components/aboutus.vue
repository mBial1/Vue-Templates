<template>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-md-6">
                <div class="about-image position-relative">
                    <img src="../assets/images/about.jpg" class="img-fluid rounded shadow" alt="">
                </div>
            </div><!--end col-->

            <div class="col-lg-7 col-md-6 mt-4 pt-2 mt-sm-0 pt-sm-0">
                <div class="section-title ms-lg-5">
                    <h6 class="text-primary fw-normal">Creative Vision & Mission</h6>
                    <h4 class="title mb-4">We develop & create <br> digital art.</h4>
                    <p class="text-muted">Launch your campaign and benefit from our expertise on designing and managing
                        conversion centered bootstrap html page.</p>
                    <p class="text-muted mb-0">It seems that only fragments of the original text remain in the Lorem
                        Ipsum texts used today. One may speculate that over the course of time certain letters were
                        added or deleted at various positions within the text. This might also explain why one can now
                        find slightly different versions.</p>

                    <div class="mt-4 pt-2">
                        <a href="javascript:void(0)" class="btn btn-primary rounded-md">Read More <i
                                class="uil uil-arrow-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</template>

<script setup>

</script>

<style lang="scss" scoped></style>