<template>
   <div class="row px-0">
                    <div class="bg-half-100 bg-gradient-primary">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="section-title text-center mb-4 pb-2">
                                        <h4 class="title text-white title-dark mb-4">Join the fastest growing Superex NFTs <br> with more than 2000+ NFTs</h4>
                                        <p class="text-white-50 para-desc mb-0 mx-auto">We are a huge marketplace dedicated to connecting great artists of all Superex with their fans and unique token collectors!</p>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->

                            <div class="row">
                                <div class="col-md-6 mt-4 pt-2">
                                    <div class="card p-4 rounded-md shadow bg-white">
                                        <h4 class="mb-4">Join our community</h4>
                                        <p class="text-muted mb-0">We are a huge marketplace dedicated to connecting great artists of all Superex.</p>

                                        <div class="mt-3">
                                            <router-link to="/aboutus" class="btn btn-link primary text-dark">Read More <i class="uil uil-arrow-right"></i></router-link>
                                        </div>
                                        <div class="py-4"></div>
                                        <div class="position-absolute bottom-0 end-0">
                                            <img src="../assets/images/svg/community.png" class="avatar avatar-medium opacity-05" alt="">
                                        </div>
                                    </div>
                                </div><!--end col-->
                                
                                <div class="col-md-6 mt-4 pt-2">
                                    <div class="card p-4 rounded-md shadow bg-white">
                                        <h4 class="mb-4">Learn more about Superex</h4>
                                        <p class="text-muted mb-0">We are a huge marketplace dedicated to connecting great artists of all Superex.</p>

                                        <div class="mt-3">
                                            <router-link to="/aboutus" class="btn btn-link primary text-dark">Read More <i class="uil uil-arrow-right"></i></router-link>
                                        </div>
                                        <div class="py-4"></div>
                                        <div class="position-absolute bottom-0 end-0">
                                            <img src="../assets/images/svg/united.png" class="avatar avatar-medium opacity-05" alt="">
                                        </div>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div><!--end container-->
                    </div>
                </div><!--end row-->
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>