<template>
    <div class="row">
        <div class="col-12 mt-4 pt-2">
            <ul class="pagination justify-content-center mb-0">
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">
                        <span aria-hidden="true"><i class="uil uil-arrow-left fs-5"></i></span>
                    </a>
                </li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item active"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">
                        <span aria-hidden="true"><i class="uil uil-arrow-right fs-5"></i></span>
                    </a>
                </li>
            </ul>
        </div><!--end col-->
    </div><!--end row-->
</template>

<script setup>

</script>

<style lang="scss" scoped></style>