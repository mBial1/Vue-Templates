<template>
    <div class="container mt-100 mt-60">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="section-title text-center">
                    <h6 class="text-muted fw-normal mb-3">Contact us and we'll get back to you as soon as we can.</h6>
                    <h4 class="title mb-4">Can't find your answer?</h4>
                    <div class="mt-4 pt-2">
                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#contactform"
                            class="btn btn-primary rounded-md">Help Center</a>
                    </div>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</template>

<script setup>

</script>

<style lang="scss" scoped></style>