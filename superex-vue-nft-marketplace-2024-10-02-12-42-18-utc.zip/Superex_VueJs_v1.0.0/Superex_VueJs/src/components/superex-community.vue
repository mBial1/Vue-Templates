<template>
    <div class="container mt-100 mt-60">
                <div class="row">
                    <div class="col">
                        <div class="section-two rounded-md shadow bg-gradient-primary px-md-5 px-4">
                            <div class="row align-items-end">
                                <div class="col-md-8">
                                    <div class="section-title text-md-start text-center">
                                        <h6 class="text-white-50 mb-1">Join with Superex Community</h6>
                                        <h4 class="title text-white title-dark mb-4">Become a Creator!</h4>
    
                                        <p class="text-white-50 para-desc mb-0">We are a huge marketplace dedicated to connecting great artists of all Superex with their fans and unique token collectors!</p>
                                    </div>
                                </div><!--end col-->
    
                                <div class="col-md-4 mt-4 pt-2 mt-sm-0 pt-sm-0">
                                    <div class="text-md-end text-center">
                                        <router-link to="/become-creator" class="btn btn-primary rounded-md">Click here <i class="uil uil-arrow-right"></i></router-link>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>