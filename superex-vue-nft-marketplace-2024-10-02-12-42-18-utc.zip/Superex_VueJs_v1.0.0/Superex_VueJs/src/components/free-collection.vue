<template>

    <div class="container">
        <div class="bg-black rounded-md p-md-5 p-4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="app-subscribe text-center text-md-start">
                            <img src="../assets/images/cta.png" class="img-fluid" height="120" alt="">
                        </div>
                    </div><!--end col-->

                    <div class="col-lg-8 col-md-6 mt-4 pt-2 mt-sm-0 pt-sm-0">
                        <div class="section-title text-center text-md-start ms-xl-5 ms-md-4">
                            <h4 class="display-6 fw-bold text-white title-dark mb-0">Get <span
                                    class="text-gradient-primary fw-bold">Free collections </span> <br> with your
                                subscription</h4>

                            <div class="mt-4">
                                <a href="javascript:void(0)"
                                    class="btn btn-link primary text-white title-dark">Subscribe Now <i
                                        class="uil uil-arrow-right"></i></a>
                            </div>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
        </div>
    </div><!--end container-->

</template>

<script setup>

</script>

<style lang="scss" scoped></style>