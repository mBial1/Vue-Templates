<template>
      <!-- Start Footer -->
      <div class="text-center">
          <small class="mb-0 text-light title-dark">© {{date}} Superex. Design & Develop with <i class="mdi mdi-heart text-danger"></i> by <a href="https://shreethemes.in/" target="_blank" class="text-reset">Shreethemes</a>.</small>
      </div>
     <!-- End Footer -->
</template>

<script setup>
const date = new Date().getFullYear()

</script>

<style lang="scss" scoped>

</style>