<template>
  <li
    :style="{
      gap: '10px',
      paddingLeft: '10px',
      position: 'relative',
      borderRadius: 'var(--border-radius)',
      backgroundColor: 'var(--white-color)',
    }"
    :class="'row-c'"
  >
    <!-- ITEM IMAGE -->
    <img
      alt="item"
      :src="item.image"
      :class="'clickable'"
      :style="{width: '87px', height: '87px', borderRadius: '10px'}"
      :onClick="
        () => router.push({name: appRoutes.DISH, params: {id: item.id}})
      "
    />

    <!-- ITEM INFO -->
    <div :class="'flex-column'" :style="{flex: '1'}">
      <p :class="'t14'" :style="{marginBottom: '2px'}">{{ item.name }}</p>
      <span :class="'t10'" :style="{marginBottom: '8px'}"
        >{{ item.kcal }} kcal - {{ item.weight }}g</span
      >
      <span :class="'t14'" :style="{color: 'var(--main-color)'}"
        >{{ item.price }}$</span
      >
    </div>

    <!-- ITEM COUNTER -->
    <div :class="'flex-column flex-center'">
      <div :style="{padding: '14px 14px 8px 14px'}" :class="'clickable'">
        <svg.MinusSvg :dish="item" />
      </div>

      <span :class="'t12'">{{ item.quantity }}</span>

      <div :style="{padding: '8px 14px 14px 14px'}" :class="'clickable'">
        <svg.PlusSvg :dish="item" />
      </div>
    </div>

    <!-- NEW ITEM -->
    <svg.NewSvg
      :style="{
        position: 'absolute',
        left: '7px',
        top: '7px',
      }"
      v-if="item.isNew"
    />
  </li>
</template>

<script setup>
import {defineProps} from 'vue';

import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {composables} from '../composables';

const {router} = composables.useRouter();

const props = defineProps({
  item: {
    type: Object,
    required: true,
  },
});
</script>
