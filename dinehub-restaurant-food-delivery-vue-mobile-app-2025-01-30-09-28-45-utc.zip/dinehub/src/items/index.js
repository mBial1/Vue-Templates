import {defineAsyncComponent} from 'vue';

export const items = {
  OrderItem: defineAsyncComponent(() => import('./OrderItem.vue')),
};
