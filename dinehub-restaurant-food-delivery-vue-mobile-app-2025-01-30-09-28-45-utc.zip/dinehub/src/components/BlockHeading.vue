<template>
  <div :style="containerStyle" class="row-c-sb">
    <h4 :style="{textTransform: 'capitalize'}">{{ title }}</h4>
    <component
      v-if="showViewAll"
      :is="svg.ViewAllSvg"
      @click="viewAllOnClick"
      :class="'clickable'"
    />
  </div>
</template>

<script setup>
import {svg} from '../assets/svg';

defineProps({
  title: String,
  viewAllOnClick: Function,
  showViewAll: {type: Boolean, default: false},
  containerStyle: {type: Object, default: () => ({})},
});
</script>
