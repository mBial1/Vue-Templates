import {defineAsyncComponent} from 'vue';

export const components = {
  Screen: defineAsyncComponent(() => import('./Screen.vue')),
  Header: defineAsyncComponent(() => import('./Header.vue')),
  Button: defineAsyncComponent(() => import('./Button.vue')),
  Switcher: defineAsyncComponent(() => import('./Switcher.vue')),
  InputField: defineAsyncComponent(() => import('./InputField.vue')),
  ReviewRating: defineAsyncComponent(() => import('./ReviewRating.vue')),
  BlockHeading: defineAsyncComponent(() => import('./BlockHeading.vue')),
  BottomTabBar: defineAsyncComponent(() => import('./BottomTabBar.vue')),
};
