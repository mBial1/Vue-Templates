<template>
  <div
    :style="{
      display: 'flex',
      alignItems: 'center',
      gap: '14px',
      padding: '5px 0 5px 5px',
      borderRadius: '10px',
      backgroundColor: '#E9F3F6',
      ...containerStyle,
    }"
  >
    <!-- LEFT ICON -->
    <component :is="props.inputType === 'email' && svg.MailSvg" />
    <component :is="props.inputType === 'password' && svg.KeySvg" />
    <component :is="props.inputType === 'username' && svg.UserSvg" />
    <component :is="props.inputType === 'phone' && svg.SmartphoneSvg" />
    <component :is="props.inputType === 'location' && svg.MapSvg" />
    <component :is="props.inputType === 'coupon' && svg.TagSvg" />
    <component :is="props.inputType === 'search' && svg.MenuSearchSvg" />

    <!-- INPUT -->
    <input
      ref="inputRef"
      class="input"
      type="text"
      :placeholder="placeholder"
      @click="focusInput"
      :style="{
        border: 'none',
        height: '100%',
        width: '100%',
        fontSize: '16px',
        backgroundColor: 'transparent',
      }"
    />

    <!-- RIGHT ICON -->
    <div
      :style="{padding: '10px 19px'}"
      @click="rightIconOnClick"
      :class="rightIconOnClick ? 'clickable' : ''"
    >
      <component :is="props.inputType === 'email' && svg.CheckSvg" />
      <component :is="props.inputType === 'password' && svg.EyeOffSvg" />
    </div>
  </div>
</template>

<script setup>
import {ref} from 'vue';

const inputRef = ref(null);
const focusInput = () => {
  if (inputRef.value) {
    inputRef.value.focus();
  }
};

import {svg} from '../assets/svg';

const props = defineProps({
  inputType: {
    type: String,
    default: '',
  },
  editable: {
    type: Boolean,
    default: true,
  },
  value: {
    type: String,
    default: '',
  },
  placeholder: {
    type: String,
    default: 'Enter your text',
  },
  containerStyle: {
    type: Object,
    default: () => ({}),
  },
  rightIconOnClick: {
    type: Function,
    default: null,
  },
});
</script>
