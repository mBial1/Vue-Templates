<template>
  <div
    id="screen"
    :style="{opacity: opacity, transition: 'opacity 0.5s ease-in-out'}"
  >
    <slot></slot>
  </div>
</template>

<script setup>
import {ref, onMounted, onBeforeUnmount} from 'vue';

const opacity = ref(0);

onMounted(() => {
  window.scrollTo(0, 0);
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;

  const timer = setTimeout(() => {
    opacity.value = 1;
  }, 100);

  onBeforeUnmount(() => {
    clearTimeout(timer);
  });
});
</script>
