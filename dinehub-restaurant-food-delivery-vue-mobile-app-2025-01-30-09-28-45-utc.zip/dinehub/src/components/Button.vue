<template>
  <div :style="{width: '100%', ...containerStyle}">
    <button
      class="button flex-center"
      :style="{
        height: '50px',
        width: '100%',
        borderRadius: '10px',
        backgroundColor:
          colorScheme === 'primary' ? 'var(--main-turquoise)' : 'transparent',
        border: '1px solid var(--main-turquoise)',
      }"
      @click="onclick"
    >
      <span
        :style="{
          fontFamily: 'DM Sans',
          fontSize: '14px',
          color:
            colorScheme === 'primary'
              ? 'var(--white-color)'
              : 'var(--main-turquoise)',
          fontWeight: 'bold',
          textTransform: 'capitalize',
        }"
      >
        {{ title }}
      </span>
    </button>
  </div>
</template>

<script setup>
defineProps({
  title: String,
  onclick: Function,
  colorScheme: {
    type: String,
    default: 'primary',
  },
  containerStyle: {
    type: Object,
    default: () => ({}),
  },
});
</script>
