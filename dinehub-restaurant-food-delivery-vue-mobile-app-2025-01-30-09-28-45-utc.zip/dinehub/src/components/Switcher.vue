<template>
  <div
    :style="{
      width: '40px',
      height: '24px',
      padding: '2px',
      borderRadius: '12px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: isChecked ? 'flex-end' : 'flex-start',
      backgroundColor: isChecked ? '#00B0B9' : '#DCE2E7',
      transition: 'background-color 0.3s, justify-content 0.3s',
    }"
    :class="'clickable'"
    @click="toggleSwitch"
  >
    <div
      :style="{
        width: '20px',
        height: '20px',
        borderRadius: '50%',
        backgroundColor: isChecked ? '#FFFFFF' : '#748BA0',
        transition: 'background-color 0.3s, transform 0.3s',
      }"
    />
  </div>
</template>

<script setup>
import {ref} from 'vue';

const isChecked = ref(false);

const toggleSwitch = () => {
  isChecked.value = !isChecked.value;
};
</script>
