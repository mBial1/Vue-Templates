<template>
  <div :style="{width: '58px', height: '10px'}">
    <svg
      width="58"
      height="10"
      viewBox="0 0 58 10"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_0_3)">
        <path
          d="M5 0.833333L6.2875 3.44167L9.16667 3.8625L7.08333 5.89167L7.575 8.75833L5 7.40417L2.425 8.75833L2.91667 5.89167L0.833333 3.8625L3.7125 3.44167L5 0.833333Z"
          :fill="rating >= 1 ? '#FFCA40' : 'transparent'"
          stroke="#FFCA40"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <g clip-path="url(#clip1_0_3)">
        <path
          d="M17 0.833333L18.2875 3.44167L21.1667 3.8625L19.0833 5.89167L19.575 8.75833L17 7.40417L14.425 8.75833L14.9167 5.89167L12.8333 3.8625L15.7125 3.44167L17 0.833333Z"
          :fill="rating >= 2 ? '#FFCA40' : 'transparent'"
          stroke="#FFCA40"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <g clip-path="url(#clip2_0_3)">
        <path
          d="M29 0.833333L30.2875 3.44167L33.1667 3.8625L31.0833 5.89167L31.575 8.75833L29 7.40417L26.425 8.75833L26.9167 5.89167L24.8333 3.8625L27.7125 3.44167L29 0.833333Z"
          :fill="rating >= 3 ? '#FFCA40' : 'transparent'"
          stroke="#FFCA40"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <g clip-path="url(#clip3_0_3)">
        <path
          d="M41 0.833333L42.2875 3.44167L45.1667 3.8625L43.0833 5.89167L43.575 8.75833L41 7.40417L38.425 8.75833L38.9167 5.89167L36.8333 3.8625L39.7125 3.44167L41 0.833333Z"
          :fill="rating >= 4 ? '#FFCA40' : 'transparent'"
          stroke="#FFCA40"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <g clip-path="url(#clip4_0_3)">
        <path
          d="M53 0.833333L54.2875 3.44167L57.1667 3.8625L55.0833 5.89167L55.575 8.75833L53 7.40417L50.425 8.75833L50.9167 5.89167L48.8333 3.8625L51.7125 3.44167L53 0.833333Z"
          :fill="rating >= 5 ? '#FFCA40' : 'transparent'"
          stroke="#FFCA40"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_0_3">
          <rect width="10" height="10" fill="white" />
        </clipPath>
        <clipPath id="clip1_0_3">
          <rect width="10" height="10" fill="white" transform="translate(12)" />
        </clipPath>
        <clipPath id="clip2_0_3">
          <rect width="10" height="10" fill="white" transform="translate(24)" />
        </clipPath>
        <clipPath id="clip3_0_3">
          <rect width="10" height="10" fill="white" transform="translate(36)" />
        </clipPath>
        <clipPath id="clip4_0_3">
          <rect width="10" height="10" fill="white" transform="translate(48)" />
        </clipPath>
      </defs>
    </svg>
  </div>
</template>

<script setup>
import {ref} from 'vue';
defineProps(['rating']);
</script>
