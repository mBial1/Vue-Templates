<template>
  <header
    class="row-c-sb header"
    :style="{position: 'relative', height: 'var(--header-height)'}"
  >
    <!-- USER -->
    <button
      :style="{
        left: '0px',
        gap: '10px',
        padding: '0 20px',
        position: 'absolute',
      }"
      v-if="showUser"
      :class="'row-c'"
      @click="openModal"
    >
      <img
        alt="User"
        :style="{width: '22px', height: '22px', borderRadius: '11px'}"
        src="https://george-fx.github.io/dinehub_api/assets/users/01.jpg"
      />
      <h5 v-if="showUserName">Jordan Hebert</h5>
    </button>

    <!-- GO BACK -->
    <button
      :onClick="() => router.go(-1)"
      :style="{
        position: 'absolute',
        left: '0',
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        padding: '0 20px',
        borderRadius: '4px',
      }"
      v-if="showGoBack"
    >
      <component :is="svg.GoBackSvg" />
    </button>

    <!-- TITLE -->
    <div
      :style="{
        position: 'absolute',
        left: '50%',
        transform: 'translateX(-50%)',
      }"
    >
      <span
        class="t16"
        :style="{color: 'var(--main-dark)', lineHeight: '1.2'}"
        >{{ title }}</span
      >
    </div>

    <!-- BASKET -->
    <button
      :style="{
        right: '0px',
        height: '100%',
        padding: '0 20px',
        position: 'absolute',
      }"
      class="flex-center"
      v-if="showBasket"
      :onClick="
        () => {
          tabStore.setTab(tabRoutes.ORDER);
          router.push(appRoutes.TAB_NAVIGATOR);
        }
      "
    >
      <div
        :style="{
          minWidth: '22px',
          height: '22px',
          borderRadius: '14px',
          paddingLeft: '4px',
          paddingRight: '4px',
          marginRight: '2px',
          backgroundColor: 'var(--main-turquoise)',
        }"
        :class="'flex-center'"
      >
        <span
          :style="{
            fontSize: '10px',
            fontWeight: '700',
            color: 'var(--white-color)',
          }"
        >
          ${{ cartStore.list.length ? total.toFixed(2) : 0 }}
        </span>
      </div>
      <component :is="svg.BasketSvg" />
    </button>
  </header>

  <!-- MODAL -->
  <div
    v-if="isModalOpen"
    :style="{
      position: 'absolute',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      zIndex: '100',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    }"
    @click="closeModal"
  >
    <div
      :style="{
        position: 'absolute',
        width: '77%',
        height: '100%',
        backgroundColor: 'var(--white-color)',
        display: 'flex',
        flexDirection: 'column',
        zIndex: '101',
      }"
      @click.stop
    >
      <!-- USER -->
      <div
        :class="'row-c'"
        :style="{
          gap: '14px',
          padding: '30px 20px 20px 20px',
          borderBottom: '1px solid #DBE9F5',
        }"
      >
        <img
          alt="User"
          :style="{width: 'calc(14%)', height: 'auto'}"
          src="https://george-fx.github.io/dinehub_api/assets/users/01.jpg"
        />
        <div :class="'flex-column'">
          <span
            :class="'t14 number-of-lines-1'"
            :style="{
              fontWeight: '600',
              color: 'var(--main-dark)',
              textTransform: 'capitalize',
            }"
            >Jordan Hebert</span
          >
          <span :class="'t14 number-of-lines-1'">jordanhebert@mail.com</span>
        </div>
      </div>

      <!-- MODAL ITEMS -->
      <ul
        :class="'container scrollable'"
        :style="{paddingTop: '14px', paddingBottom: '20px'}"
      >
        <li
          :key="item.id"
          v-for="item in modalMenu"
          :class="'clickable row-c-sb'"
          :style="{paddingTop: '12px', paddingBottom: '12px'}"
          @click="handleItemClick(item.route)"
        >
          <span :class="'t14'" :style="{color: 'var(--main-dark)'}">{{
            item.title
          }}</span>
          <component :is="svg.RightArrowSvg" v-if="item.route" />
          <Switcher v-if="item.switch" @click.stop />
        </li>
      </ul>
    </div>

    <component
      :is="svg.CloseSvg"
      @click="closeModal"
      :style="{
        position: 'absolute',
        top: '0px',
        right: '23%',
        transform: 'translateX(100%)',
      }"
      :class="'clickable'"
    />
  </div>
</template>

<script setup>
import {ref, computed, nextTick} from 'vue';

const themeColor = ref('#F6F9F9');

import {stores} from '../stores';
import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {tabRoutes} from '../routes';
import {composables} from '../composables';

const {router} = composables.useRouter();

import Switcher from '../components/Switcher.vue';

const isModalOpen = ref(false);

const tabStore = stores.tabStore();
const cartStore = stores.cartStore();

const total = computed(() => cartStore.total);

const openModal = () => {
  isModalOpen.value = true;
  document
    .querySelector('meta[name="theme-color"]')
    .setAttribute('content', '#fff');
};

const closeModal = () => {
  isModalOpen.value = false;
  document
    .querySelector('meta[name="theme-color"]')
    .setAttribute('content', themeColor.value);
};

const modalMenu = [
  {
    id: 1,
    title: 'Personal information',
    route: appRoutes.EDIT_PROFILE,
    switch: false,
  },
  {
    id: 2,
    title: 'My orders',
    route: appRoutes.ORDER_HISTORY,
    switch: false,
  },
  {
    id: 3,
    title: 'My orders Empty',
    route: appRoutes.ORDER_HISTORY_EMPTY,
    switch: false,
  },
  {
    id: 4,
    title: 'Promocodes & gift cards',
    route: appRoutes.PROMOCODES,
    switch: false,
  },
  {
    id: 5,
    title: 'Promocodes & gift cards Empty',
    route: appRoutes.PROMOCODES_EMPTY,
    switch: false,
  },
  {
    id: 6,
    title: 'Notifications',
    route: '',
    switch: true,
  },
  {
    id: 7,
    title: 'Face ID',
    route: '',
    switch: true,
  },
  {
    id: 8,
    title: 'Support center',
    route: '',
    switch: false,
  },
  {
    id: 9,
    title: 'Sign out',
    route: appRoutes.SIGN_IN,
    switch: false,
  },
  {
    id: 10,
    title: 'Onboarding',
    route: appRoutes.ONBOARDING,
    switch: false,
  },
];

const handleItemClick = (route) => {
  closeModal();

  nextTick(() => {
    router.push(route);
  });
};

defineProps({
  title: String,
  showGoBack: {
    type: Boolean,
    default: false,
  },
  showBasket: {
    type: Boolean,
    default: false,
  },
  showUser: {
    type: Boolean,
    default: false,
  },
  showUserName: {
    type: Boolean,
    default: false,
  },
});
</script>
