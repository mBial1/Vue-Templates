<template>
  <div :class="'container'" :style="{marginBottom: '10px', marginTop: '10px'}">
    <ul
      :class="'row-c'"
      :style="{
        backgroundColor: 'var(--white-color)',
        borderRadius: '10px',
        paddingTop: '15px',
        paddingBottom: '15px',
      }"
    >
      <li
        v-for="tab in tabs"
        :key="tab.id"
        @click="setTab(tab.tabRoute)"
        :class="'clickable'"
        :style="{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          width: 'calc(100% / 5)',
        }"
      >
        <component :is="tab.icon" :currentTab="currentTab" />
        <span
          :style="{
            textAlign: 'center',
            fontSize: '10px',
            fontFamily: 'DM Sans',
            marginTop: '2px',
            color:
              currentTab === tab.tabRoute
                ? 'var(--main-turquoise)'
                : 'var(--text-color)',
            textTransform: 'capitalize',
          }"
          >{{ tab.tabRoute }}</span
        >
      </li>
    </ul>
  </div>
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../stores';
import {tabRoutes} from '../routes';

const tabStore = stores.tabStore();
const currentTab = computed(() => tabStore.currentTab);

const setTab = (tab) => tabStore.setTab(tab);

import HomeTabSvg from '../assets/svg/tabs/HomeTabSvg.vue';
import MenuTabSvg from '../assets/svg/tabs/MenuTabSvg.vue';
import OrderTabSvg from '../assets/svg/tabs/OrderTabSvg.vue';
import FavoriteTabSvg from '../assets/svg/tabs/FavoriteTabSvg.vue';
import NotificationsTabSvg from '../assets/svg/tabs/NotificationsTabSvg.vue';

const tabs = [
  {
    id: 1,
    tabRoute: tabRoutes.HOME,
    icon: HomeTabSvg,
  },
  {
    id: 2,
    tabRoute: tabRoutes.MENU,
    icon: MenuTabSvg,
  },
  {
    id: 3,
    tabRoute: tabRoutes.ORDER,
    icon: OrderTabSvg,
  },
  {
    id: 4,
    tabRoute: tabRoutes.FAVORITE,
    icon: FavoriteTabSvg,
  },
  {
    id: 5,
    tabRoute: tabRoutes.NOTIFICATIONS,
    icon: NotificationsTabSvg,
  },
];
</script>
