import {getCurrentInstance} from 'vue';
import {useRouter as useVueRouter, useRoute as useVueRoute} from 'vue-router';

export function useRouter() {
  const instance = getCurrentInstance();
  if (!instance) {
    throw new Error('useRouter must be called from within a setup function');
  }

  const router = useVueRouter();
  const route = useVueRoute();

  return {router, route};
}
