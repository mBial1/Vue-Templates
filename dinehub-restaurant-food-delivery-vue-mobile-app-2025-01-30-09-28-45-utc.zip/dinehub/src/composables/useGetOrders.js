import {ref, onMounted} from 'vue';
import axios from 'axios';
import {URLS} from '../config';

export const useGetOrders = () => {
  const orders = ref([]);
  const ordersLoading = ref(false);

  const getOrders = async () => {
    ordersLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_ORDERS);
      orders.value = response.data.orders;
    } catch (error) {
      console.error(error);
    } finally {
      ordersLoading.value = false;
    }
  };

  onMounted(() => {
    getOrders();
  });

  return {ordersLoading, orders};
};
