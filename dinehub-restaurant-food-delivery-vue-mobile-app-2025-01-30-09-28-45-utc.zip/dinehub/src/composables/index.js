import {useRouter} from './useRouter';
import {useGetMenu} from './useGetMenu';
import {useGetDishes} from './useGetDishes';
import {useGetOrders} from './useGetOrders';
import {useGetReviews} from './useGetReviews';
import {useGetCarousel} from './useGetCarousel';
import {useGetPromocodes} from './useGetPromocodes';
import {useGetNotifications} from './useGetNotifications';

export const composables = {
  useRouter,
  useGetMenu,
  useGetOrders,
  useGetDishes,
  useGetReviews,
  useGetCarousel,
  useGetPromocodes,
  useGetNotifications,
};
