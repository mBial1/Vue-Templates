import {ref, onMounted} from 'vue';
import axios from 'axios';
import {URLS} from '../config';

export const useGetNotifications = () => {
  const notifications = ref([]);
  const notificationsLoading = ref(false);

  const getNotifivations = async () => {
    notificationsLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_NOTIFICATIONS);
      notifications.value = response.data.notifications;
    } catch (error) {
      console.error(error);
    } finally {
      notificationsLoading.value = false;
    }
  };

  onMounted(() => {
    getNotifivations();
  });

  return {
    notificationsLoading: notificationsLoading,
    notifications: notifications,
  };
};
