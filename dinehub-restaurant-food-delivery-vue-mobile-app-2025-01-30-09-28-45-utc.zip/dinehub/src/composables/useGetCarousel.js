import {ref, onMounted} from 'vue';
import axios from 'axios';
import {URLS} from '../config';

export const useGetCarousel = () => {
  const carousel = ref([]);
  const carouselLoading = ref(false);

  const getCarousel = async () => {
    carouselLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_CAROUSEL);
      carousel.value = response.data.carousel;
    } catch (error) {
      console.error(error);
    } finally {
      carouselLoading.value = false;
    }
  };

  onMounted(() => {
    getCarousel();
  });

  return {carouselLoading, carousel};
};
