import axios from 'axios';
import {ref, onMounted} from 'vue';

import {URLS} from '../config';

export const useGetReviews = () => {
  const reviews = ref([]);
  const reviewsLoading = ref(false);

  const getReviews = async () => {
    reviewsLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_REVIEWS);
      reviews.value = response.data.reviews;
    } catch (error) {
      console.error(error);
    } finally {
      reviewsLoading.value = false;
    }
  };

  onMounted(() => {
    getReviews();
  });

  return {reviewsLoading, reviews};
};
