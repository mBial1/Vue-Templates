import axios from 'axios';
import {ref, onMounted} from 'vue';

import {URLS} from '../config';

export const useGetPromocodes = () => {
  const promocodes = ref([]);
  const promocodesLoading = ref(false);

  const getPromocodes = async () => {
    promocodesLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_PROMOCODES);
      promocodes.value = response.data.promocodes;
    } catch (error) {
      console.error(error);
    } finally {
      promocodesLoading.value = false;
    }
  };

  onMounted(() => {
    getPromocodes();
  });

  return {promocodesLoading, promocodes};
};
