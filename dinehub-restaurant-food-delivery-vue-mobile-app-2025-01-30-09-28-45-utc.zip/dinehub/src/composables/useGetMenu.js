import axios from 'axios';
import {ref, onMounted} from 'vue';

import {URLS} from '../config';

export const useGetMenu = () => {
  const menu = ref([]);
  const menuLoading = ref(false);

  const getMenu = async () => {
    menuLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_MENU);
      menu.value = response.data.menu;
    } catch (error) {
      console.error(error);
    } finally {
      menuLoading.value = false;
    }
  };

  onMounted(() => {
    getMenu();
  });

  return {menuLoading: menuLoading, menu};
};
