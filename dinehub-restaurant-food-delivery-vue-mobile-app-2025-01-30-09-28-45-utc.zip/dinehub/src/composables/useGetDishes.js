import {ref, onMounted} from 'vue';
import axios from 'axios';
import {URLS} from '../config';

export const useGetDishes = () => {
  const dishes = ref([]);
  const dishesLoading = ref(false);

  const getDishes = async () => {
    dishesLoading.value = true;

    try {
      const response = await axios.get(URLS.GET_DISHES);
      dishes.value = response.data.dishes;
    } catch (error) {
      console.error(error);
    } finally {
      dishesLoading.value = false;
    }
  };

  onMounted(() => {
    getDishes();
  });

  return {dishesLoading, dishes};
};
