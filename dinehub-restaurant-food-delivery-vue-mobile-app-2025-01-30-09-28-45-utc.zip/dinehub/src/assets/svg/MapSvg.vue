<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <g clip-path="url(#clip0_188_1366)">
        <path
          d="M12.6667 16.0002V26.6668L17.3333 24.0002L22.6667 26.6668L27.3333 24.0002V13.3335L22.6667 16.0002L17.3333 13.3335L12.6667 16.0002Z"
          stroke="white"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M17.3333 13.3335V24.0002"
          stroke="white"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M22.6667 16V26.6667"
          stroke="white"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_188_1366">
          <rect
            width="16"
            height="16"
            fill="white"
            transform="translate(12 12)"
          />
        </clipPath>
      </defs>
    </svg>
  </div>
</template>
