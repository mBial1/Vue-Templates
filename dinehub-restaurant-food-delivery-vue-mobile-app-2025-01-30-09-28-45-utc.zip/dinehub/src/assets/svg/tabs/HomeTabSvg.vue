<template>
  <div :style="{width: '24px', height: '24px'}">
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M5.4 7.87061L12 2.40002L18.6 7.87061V21H5.4V7.87061Z"
        :fill="
          currentTab === tabRoutes.HOME
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        fill-opacity="0.15"
      />
      <path
        d="M5 21H19"
        :stroke="
          currentTab === tabRoutes.HOME
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M5 21V8M19 21V8"
        :stroke="
          currentTab === tabRoutes.HOME
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M2 10L12 2L22 10"
        :stroke="
          currentTab === tabRoutes.HOME
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../../../stores';
import {tabRoutes} from '../../../routes';

const tabStore = stores.tabStore();
const currentTab = computed(() => tabStore.currentTab);
</script>
