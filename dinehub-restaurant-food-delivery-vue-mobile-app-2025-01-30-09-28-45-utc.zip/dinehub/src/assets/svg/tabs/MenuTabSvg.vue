<template>
  <div :style="{width: '24px', height: '24px'}">
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.8055 15.1945 2 10.5 2C5.8055 2 2 5.8055 2 10.5C2 15.1945 5.8055 19 10.5 19Z"
        :fill="
          currentTab === tabRoutes.MENU
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        fill-opacity="0.15"
        :stroke="
          currentTab === tabRoutes.MENU
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        d="M13.3285 7.1715C12.9575 6.79952 12.5166 6.50453 12.0312 6.30348C11.5458 6.10244 11.0254 5.9993 10.5 6C9.97461 5.9993 9.45426 6.10244 8.96885 6.30348C8.48344 6.50453 8.04255 6.79952 7.67151 7.1715M16.611 16.611L20.8535 20.8535"
        :stroke="
          currentTab === tabRoutes.MENU
            ? 'var(--main-turquoise)'
            : 'var(--text-color)'
        "
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../../../stores';
import {tabRoutes} from '../../../routes';

const tabStore = stores.tabStore();
const currentTab = computed(() => tabStore.currentTab);
</script>
