<template>
  <div
    @click.stop
    :class="'clickable'"
    @click="toggleWishlist"
    :style="{borderRadius: '10px', ...containerStyle}"
  >
    <div :style="{width: '24px', height: '27px'}">
      <svg
        width="24"
        height="27"
        viewBox="0 0 24 27"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M20.84 5.06421C20.3292 4.50779 19.7228 4.0664 19.0554 3.76526C18.3879 3.46411 17.6725 3.30911 16.95 3.30911C16.2275 3.30911 15.5121 3.46411 14.8446 3.76526C14.1772 4.0664 13.5708 4.50779 13.06 5.06421L12 6.21843L10.94 5.06421C9.90831 3.94081 8.50903 3.30969 7.05 3.30969C5.59096 3.30969 4.19169 3.94081 3.16 5.06421C2.1283 6.18761 1.54871 7.71126 1.54871 9.29999C1.54871 10.8887 2.1283 12.4124 3.16 13.5358L4.22 14.69L12 23.1615L19.78 14.69L20.84 13.5358C21.351 12.9796 21.7564 12.3193 22.0329 11.5925C22.3095 10.8657 22.4518 10.0867 22.4518 9.29999C22.4518 8.51328 22.3095 7.73428 22.0329 7.00749C21.7564 6.2807 21.351 5.62037 20.84 5.06421V5.06421Z"
          :fill="ifInWishlist ? 'var(--accent-color)' : 'none'"
          :stroke="ifInWishlist ? 'var(--accent-color)' : 'var(--text-color)'"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </div>
  </div>
</template>

<script setup>
import {computed} from 'vue';
import {stores} from '../../stores';

const props = defineProps({
  dish: {type: Object, required: true},
  containerStyle: {type: Object, default: () => ({})},
});

const wishlistStore = stores.wishlistStore();

const ifInWishlist = computed(() =>
  wishlistStore.list.find((item) => item.id === props.dish.id)
);

const toggleWishlist = () => {
  if (ifInWishlist.value) {
    wishlistStore.removeFromWishlist(props.dish);
  } else {
    wishlistStore.addToWishlist(props.dish);
  }
};
</script>
