<template>
  <div @click="removeFromCart">
    <div :style="{width: '21px', height: '21px'}">
      <svg
        width="21"
        height="21"
        viewBox="0 0 21 21"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect width="21" height="21" rx="10.5" fill="#E6F3F8" />
        <path
          d="M6.125 10.5H14.875"
          stroke="#0C1D2E"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </div>
  </div>
</template>

<script setup>
import {defineProps} from 'vue';

import {stores} from '../../stores';

const props = defineProps({
  dish: {type: Object, required: true},
});

const cartStore = stores.cartStore();

const removeFromCart = () => {
  cartStore.removeFromCart(props.dish);
};
</script>
