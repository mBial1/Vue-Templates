<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <path
        d="M25.3334 26V24.6667C25.3334 23.9594 25.0525 23.2811 24.5524 22.781C24.0523 22.281 23.374 22 22.6667 22H17.3334C16.6262 22 15.9479 22.281 15.4478 22.781C14.9477 23.2811 14.6667 23.9594 14.6667 24.6667V26"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M19.9999 19.3333C21.4727 19.3333 22.6666 18.1394 22.6666 16.6667C22.6666 15.1939 21.4727 14 19.9999 14C18.5272 14 17.3333 15.1939 17.3333 16.6667C17.3333 18.1394 18.5272 19.3333 19.9999 19.3333Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
