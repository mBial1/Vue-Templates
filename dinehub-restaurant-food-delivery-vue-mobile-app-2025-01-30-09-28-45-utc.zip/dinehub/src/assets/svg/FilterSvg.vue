<template>
  <div :style="{width: '24px', height: '24px'}">
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3 4.5L10.2 12.909V19.222L13.8 21V12.909L21 4.5H3Z"
        fill="#748BA0"
        fill-opacity="0.15"
        stroke="#748BA0"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
