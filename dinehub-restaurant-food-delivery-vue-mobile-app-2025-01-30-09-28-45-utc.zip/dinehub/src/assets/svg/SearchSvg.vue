<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <path
        d="M19.3333 24.6667C22.2789 24.6667 24.6667 22.2789 24.6667 19.3333C24.6667 16.3878 22.2789 14 19.3333 14C16.3878 14 14 16.3878 14 19.3333C14 22.2789 16.3878 24.6667 19.3333 24.6667Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M26 26L23.1 23.1"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
