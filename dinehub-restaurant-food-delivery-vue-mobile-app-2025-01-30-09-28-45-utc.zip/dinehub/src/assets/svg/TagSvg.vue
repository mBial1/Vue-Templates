<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <path
        d="M25.7267 20.4402L20.9467 25.2202C20.8229 25.3441 20.6758 25.4425 20.514 25.5096C20.3521 25.5767 20.1786 25.6112 20.0034 25.6112C19.8282 25.6112 19.6547 25.5767 19.4928 25.5096C19.3309 25.4425 19.1839 25.3441 19.06 25.2202L13.3334 19.5002V12.8335H20L25.7267 18.5602C25.975 18.81 26.1144 19.1479 26.1144 19.5002C26.1144 19.8524 25.975 20.1903 25.7267 20.4402Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M16.6666 16.1665H16.6733"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
