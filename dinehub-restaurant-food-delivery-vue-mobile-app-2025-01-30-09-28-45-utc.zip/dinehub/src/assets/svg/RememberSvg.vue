<template>
  <div :style="{width: '12px', height: '9px'}">
    <svg
      width="12"
      height="9"
      viewBox="0 0 12 9"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_3538_2864)">
        <path
          d="M10.2656 1.57594L4.39179 7.44979L1.72186 4.77986"
          stroke="#6C6D84"
          stroke-width="1.20147"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_3538_2864">
          <rect
            width="11.2137"
            height="8.00979"
            fill="white"
            transform="translate(0.386902 0.507973)"
          />
        </clipPath>
      </defs>
    </svg>
  </div>
</template>
