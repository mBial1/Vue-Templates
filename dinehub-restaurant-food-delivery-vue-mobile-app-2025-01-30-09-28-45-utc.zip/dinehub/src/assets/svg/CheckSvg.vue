<template>
  <div :style="{width: '14px', height: '11px'}">
    <svg
      width="14"
      height="11"
      viewBox="0 0 14 11"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clip-path="url(#clip0_188_2623)">
        <path
          d="M12.3333 1.5L4.99996 8.83333L1.66663 5.5"
          stroke="#00B0B9"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_188_2623">
          <rect
            width="14"
            height="10"
            fill="white"
            transform="translate(0 0.5)"
          />
        </clipPath>
      </defs>
    </svg>
  </div>
</template>
