<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <path
        d="M14.6667 14.6666H25.3334C26.0667 14.6666 26.6667 15.2666 26.6667 16V24C26.6667 24.7333 26.0667 25.3333 25.3334 25.3333H14.6667C13.9334 25.3333 13.3334 24.7333 13.3334 24V16C13.3334 15.2666 13.9334 14.6666 14.6667 14.6666Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M26.6667 16L20 20.6667L13.3334 16"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
