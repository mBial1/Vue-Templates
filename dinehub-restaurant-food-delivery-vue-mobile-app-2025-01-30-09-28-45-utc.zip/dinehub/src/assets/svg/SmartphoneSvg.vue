<template>
  <div :style="{width: '40px', height: '40px'}">
    <svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="40" height="40" rx="8" fill="#00B0B9" />
      <path
        d="M23.3333 13.3333H16.6666C15.9302 13.3333 15.3333 13.9303 15.3333 14.6667V25.3333C15.3333 26.0697 15.9302 26.6667 16.6666 26.6667H23.3333C24.0696 26.6667 24.6666 26.0697 24.6666 25.3333V14.6667C24.6666 13.9303 24.0696 13.3333 23.3333 13.3333Z"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M20 24H20.0067"
        stroke="white"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  </div>
</template>
