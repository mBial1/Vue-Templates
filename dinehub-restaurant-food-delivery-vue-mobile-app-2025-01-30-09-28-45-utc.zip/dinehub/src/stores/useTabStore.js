import {defineStore} from 'pinia';
import {tabRoutes} from '../routes';

export const useTabStore = defineStore('tab', {
  state: () => ({
    currentTab: tabRoutes.HOME,
  }),
  actions: {
    setTab(tab) {
      this.currentTab = tab;
    },
  },
  persist: true,
});
