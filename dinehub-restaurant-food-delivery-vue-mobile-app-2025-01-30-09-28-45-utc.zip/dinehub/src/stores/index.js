import {useTabStore} from './useTabStore';
import {useCartStore} from './useCartStore';
import {useWishlistStore} from './useWishlistStore';

export const stores = {
  tabStore: useTabStore,
  cartStore: useCartStore,
  wishlistStore: useWishlistStore,
};
