import {defineStore} from 'pinia';

export const useWishlistStore = defineStore('wishlist', {
  state: () => ({
    list: [],
  }),
  actions: {
    addToWishlist(dish) {
      const inWishlist = this.list.find((item) => item.id === dish.id);
      if (!inWishlist) {
        this.list.push(dish);
      }
    },
    removeFromWishlist(dish) {
      this.list = this.list.filter((item) => item.id !== dish.id);
    },
    isInWishlist(dish) {
      return this.list.some((item) => item.id === dish.id);
    },
    resetWishlist() {
      this.list = [];
    },
  },
  persist: {enabled: true},
});
