import {defineStore} from 'pinia';

export const useCartStore = defineStore('cart', {
  state: () => ({
    total: 0,
    list: [],
    delivery: 0,
    discount: 0,
    subtotal: 0,
    promoCode: '',
    discountAmount: 0,
  }),
  actions: {
    addToCart(dish) {
      const inCart = this.list.find((item) => item.id === dish.id);

      if (inCart) {
        this.list = this.list.map((item) => {
          if (item.id === dish.id) {
            if (item.quantity) {
              item.quantity += 1;
            }
          }
          return item;
        });
        this.subtotal += Number(dish.price);
        this.discountAmount = Number((this.subtotal - this.total).toFixed(2));
        this.total += Number(dish.price) * (1 - this.discount / 100);
      } else {
        this.list.push({
          ...dish,
          quantity: 1,
        });
        this.subtotal += Number(dish.price);
        this.total += Number(dish.price) * (1 - this.discount / 100);
      }
    },
    removeFromCart(dish) {
      const inCart = this.list.find((item) => item.id === dish.id);

      if (inCart) {
        this.list = this.list.filter((item) => {
          if (item.id === dish.id) {
            if (item.quantity > 1) {
              item.quantity -= 1;
              return true;
            } else {
              return false;
            }
          }
          return true;
        });
        this.subtotal -= Number(dish.price);
        this.discountAmount = Number((this.subtotal - this.total).toFixed(2));
        this.total -= Number(dish.price) * (1 - this.discount / 100);

        if (this.list.length === 0) {
          this.discount = 0;
          this.promoCode = '';
        }
      }
    },
    setDiscount(discount) {
      if (this.list.length === 0) {
        this.discount = 0;
      } else {
        this.discount = discount;
      }
      const newTotal = this.subtotal * (1 - this.discount / 100);
      this.discountAmount = Number((this.subtotal - newTotal).toFixed(2));
      this.total = this.subtotal * (1 - this.discount / 100);
    },
    resetCart() {
      this.list = [];
      this.subtotal = 0;
      this.total = 0;
      this.discount = 0;
      this.promoCode = '';
      this.delivery = 0;
      this.discountAmount = 0;
    },
    setPromoCode(promoCode) {
      this.promoCode = promoCode;
    },
    getItemQty(id) {
      const item = this.list.find((item) => item.id === id);
      return item ? item.quantity : 0;
    },
  },
  persist: {enabled: true},
});
