<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Verify number'" />

    <!-- MAIN -->
    <main :class="'scrollable container'">
      <section
        :style="{
          marginTop: '10px',
          paddingTop: '30px',
          paddingBottom: '30px',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          We have sent you an SMS with a code <br />
          to number +17 0123456789.
        </p>
        <components.InputField
          :inputType="'phone'"
          :placeholder="'Phone number'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.Button
          :title="'confirm'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.CONFIRMATION_CODE)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
