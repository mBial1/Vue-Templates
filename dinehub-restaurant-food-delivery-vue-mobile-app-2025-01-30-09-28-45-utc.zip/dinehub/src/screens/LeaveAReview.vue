<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Leave a review'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <section
        :style="{
          paddingTop: '20px',
          paddingBottom: '20px',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <img
          alt="rate service"
          :class="'center'"
          :style="{marginBottom: '14px', width: '54%'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/08.jpg"
        />
        <h2
          :style="{
            textTransform: 'capitalize',
            textAlign: 'center',
            marginBottom: '14px',
          }"
        >
          Please rate the quality of <br />
          service for the order!
        </h2>
        <div
          :style="{width: '216px', height: '40px', marginBottom: '20px'}"
          :class="'center'"
        >
          <svg
            width="216"
            height="40"
            viewBox="0 0 216 40"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M20 3.33333L25.15 13.7667L36.6667 15.45L28.3333 23.5667L30.3 35.0333L20 29.6167L9.7 35.0333L11.6667 23.5667L3.33333 15.45L14.85 13.7667L20 3.33333Z"
              :fill="rating >= 1 ? 'var(--accent-color)' : '#E9F3F6'"
              :stroke="rating >= 1 ? 'var(--accent-color)' : '#E9F3F6'"
              stroke-linecap="round"
              stroke-linejoin="round"
              :onClick="() => setRating(1)"
            />
            <path
              d="M64 3.33333L69.15 13.7667L80.6667 15.45L72.3333 23.5667L74.3 35.0333L64 29.6167L53.7 35.0333L55.6667 23.5667L47.3333 15.45L58.85 13.7667L64 3.33333Z"
              :fill="rating >= 2 ? 'var(--accent-color)' : '#E9F3F6'"
              :stroke="rating >= 2 ? 'var(--accent-color)' : '#E9F3F6'"
              stroke-linecap="round"
              stroke-linejoin="round"
              :onClick="() => setRating(2)"
            />
            <path
              d="M108 3.33333L113.15 13.7667L124.667 15.45L116.333 23.5667L118.3 35.0333L108 29.6167L97.7 35.0333L99.6667 23.5667L91.3333 15.45L102.85 13.7667L108 3.33333Z"
              :fill="rating >= 3 ? 'var(--accent-color)' : '#E9F3F6'"
              :stroke="rating >= 3 ? 'var(--accent-color)' : '#E9F3F6'"
              stroke-linecap="round"
              stroke-linejoin="round"
              :onClick="() => setRating(3)"
            />
            <path
              d="M152 3.33333L157.15 13.7667L168.667 15.45L160.333 23.5667L162.3 35.0333L152 29.6167L141.7 35.0333L143.667 23.5667L135.333 15.45L146.85 13.7667L152 3.33333Z"
              :fill="rating >= 4 ? 'var(--accent-color)' : '#E9F3F6'"
              :stroke="rating >= 4 ? 'var(--accent-color)' : '#E9F3F6'"
              stroke-linecap="round"
              stroke-linejoin="round"
              :onClick="() => setRating(4)"
            />
            <path
              d="M196 3.33333L201.15 13.7667L212.667 15.45L204.333 23.5667L206.3 35.0333L196 29.6167L185.7 35.0333L187.667 23.5667L179.333 15.45L190.85 13.7667L196 3.33333Z"
              :fill="rating >= 5 ? 'var(--accent-color)' : '#E9F3F6'"
              :stroke="rating >= 5 ? 'var(--accent-color)' : '#E9F3F6'"
              stroke-linecap="round"
              stroke-linejoin="round"
              :onClick="() => setRating(5)"
            />
          </svg>
        </div>
        <p :class="'t16'" :style="{textAlign: 'center', marginBottom: '30px'}">
          Your comments and suggestions help <br />
          us improve the service quality better!
        </p>
        <div :style="{marginBottom: '20px'}">
          <textarea
            :placeholder="'Enter your comment'"
            :style="{
              height: '127px',
              width: '100%',
              padding: '14px',
              borderRadius: '10px',
              border: 'none',
              fontSize: '16px',
              fontFamily: 'DM Sans',
              color: '#748BA0',
              backgroundColor: '#E9F3F6',
              resize: 'none',
            }"
          />
        </div>
        <components.Button
          :title="'Send review'"
          :onclick="() => router.go(-1)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';

import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const rating = ref(3);
const setRating = (value) => (rating.value = value);
</script>
