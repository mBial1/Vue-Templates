<template>
  <components.Screen>
    <!-- SWIPER -->
    <section class="flex-center" :style="{display: 'flex', height: '100%'}">
      <swiper @slideChange="onSlideChange">
        <swiper-slide
          :key="item.id"
          v-for="item in onboarding"
          :class="'clickable'"
        >
          <img
            :src="item.image"
            alt="onboarding"
            :class="'center'"
            :style="{width: '60%', height: '100%'}"
          />
        </swiper-slide>
      </swiper>
    </section>

    <!-- DOTS -->
    <div :class="'center row-c'" :style="{marginBottom: '10%', gap: '8px'}">
      <div
        v-for="(item, index) in onboarding"
        :key="item.id"
        :style="{
          width: '8px',
          height: index === currentSlideIndex ? '20px' : '8px',
          borderRadius: 'var(--border-radius)',
          backgroundColor:
            index === currentSlideIndex ? '#00B0B9' : `${'#00B0B9'}50`,
        }"
        :class="['dot', {active: index === currentSlideIndex}]"
      />
    </div>

    <!-- CONTENT -->
    <section :class="'container'">
      <div
        :style="{
          width: '100%',
          backgroundColor: 'var(--white-color)',
          borderRadius: '10px',
          paddingTop: '10%',
          paddingBottom: '10%',
        }"
      >
        <h1 :style="{textAlign: 'center'}">
          {{ onboarding[currentSlideIndex].title1 }}
        </h1>
        <h1 :style="{textAlign: 'center', marginBottom: '20px'}">
          {{ onboarding[currentSlideIndex].title2 }}
        </h1>
        <p :style="{textAlign: 'center'}" :class="'t16'">
          {{ onboarding[currentSlideIndex].descriptionLine1 }}
        </p>
        <p :style="{textAlign: 'center'}" :class="'t16'">
          {{ onboarding[currentSlideIndex].descriptionLine2 }}
        </p>
      </div>
    </section>

    <!-- BUTTON -->
    <section :style="{padding: '20px'}">
      <components.Button
        :onClick="() => router.push(appRoutes.SIGN_IN)"
        :title="'Get Started'"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';
import {Swiper} from 'swiper/vue';
import {SwiperSlide} from 'swiper/vue';

import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router, route} = composables.useRouter();

const currentSlideIndex = ref(0);

const onSlideChange = (swiper) => {
  currentSlideIndex.value = swiper.activeIndex;
};

const onboarding = [
  {
    id: 1,
    title1: 'Embark On Culinary ',
    title2: 'Adventures',
    image: 'https://george-fx.github.io/dinehub_api/assets/images/05.jpg',
    descriptionLine1: 'Embark on an exciting culinary',
    descriptionLine2: 'journey with our app.',
  },
  {
    id: 2,
    title1: 'Craft Your',
    title2: 'Perfect Order',
    image: 'https://george-fx.github.io/dinehub_api/assets/images/06.jpg',
    descriptionLine1: 'Customize your cravings and place',
    descriptionLine2: 'orders effortlessly.',
  },
  {
    id: 3,
    title1: 'Taste The',
    title2: 'Delivered Magic',
    image: 'https://george-fx.github.io/dinehub_api/assets/images/07.jpg',
    descriptionLine1: 'Enjoy the convenience of doorstep',
    descriptionLine2: 'culinary delights.',
  },
];
</script>
