<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Order history'" />

    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'flex-center container'"
      >
        <img
          alt="rate service"
          :class="'center'"
          :style="{marginBottom: '14px', width: '80%'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/10.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          No Order History Yet!
        </h2>
        <p :class="'t16'" :style="{marginBottom: '30px', textAlign: 'center'}">
          It looks like your order history is empty. <br />
          Place your order now to start building <br />
          your history!
        </p>
      </section>
    </main>

    <!-- BUTTON -->
    <section :style="{padding: '20px'}">
      <components.Button
        :title="'Explore Our Menu'"
        :onClick="
          () => {
            tabStore.setTab(tabRoutes.MENU);
            router.push(appRoutes.TAB_NAVIGATOR);
          }
        "
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {stores} from '../stores';
import {tabRoutes} from '../routes';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const tabStore = stores.tabStore();
</script>
