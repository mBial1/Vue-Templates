<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Promocodes & gift cards'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
      v-if="!promocodesLoading"
    >
      <ul>
        <li
          :key="promocode.id"
          v-for="(promocode, index) in promocodes"
          @click="copyToClipboard(promocode.code)"
          :style="{
            gap: '7px',
            padding: '20px',
            borderRadius: 'var(--border-radius)',
            backgroundColor: 'var(--white-color)',
            marginBottom: index === promocodes.length - 1 ? '0' : '14px',
          }"
          :class="'flex-column clickable'"
        >
          <div :class="'row-c-sb'">
            <h3>{{ promocode.code }}</h3>
            <svg.CopySvg />
          </div>
          <div :class="'row-c-sb'">
            <div
              :style="{
                padding: '3px 8px',
                borderRadius: '5px',
                backgroundColor:
                  promocode.discount === 35
                    ? '#FFA462'
                    : promocode.discount === 50
                    ? '#FA5555'
                    : '#00B0B9',
              }"
              :class="'flex-center'"
            >
              <span :class="'t12'" :style="{color: '#fff'}"
                >{{ promocode.discount }}% discount</span
              >
            </div>
            <span :class="'t12'">Expire {{ promocode.expiry }}</span>
          </div>
        </li>
      </ul>
    </main>

    <!-- LOADING TEXT -->
    <div
      v-if="promocodesLoading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>

    <!-- BOTTOM BAR -->
    <section
      :style="{padding: '20px', gap: '10px'}"
      v-if="!promocodesLoading"
      :class="'flex-row'"
    >
      <components.InputField
        :inputType="'coupon'"
        :placeholder="'Add new coupon'"
        :containerStyle="{width: '100%'}"
      />
      <components.Button :title="'+ add'" :containerStyle="{width: '40%'}" />
    </section>
  </components.Screen>
</template>

<script setup>
import {svg} from '../assets/svg';
import {components} from '../components';
import {composables} from '../composables';

const {promocodesLoading, promocodes} = composables.useGetPromocodes();

const copyToClipboard = (text) => {
  navigator.clipboard
    .writeText(text)
    .then(() => {
      alert('Promocode copied to clipboard!');
    })
    .catch((err) => {
      console.error('Could not copy text: ', err);
    });
};
</script>
