<template>
  <components.Screen>
    <!-- MAIN CONTENT -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container flex-center'"
      >
        <img
          alt="rate service"
          :class="'status-img center'"
          :style="{marginBottom: '14px'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/11.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          Sorry! Your order <br />
          has failed!
        </h2>
        <p :style="{textAlign: 'center'}" :class="'t16'">
          Something went wrong. Please try <br />
          again to continue your order.
        </p>
      </section>
    </main>

    <!-- BUTTONS -->
    <section :style="{padding: '20px'}">
      <components.Button
        :style="{marginBottom: '14px'}"
        :title="'Try again'"
        :onClick="
          () => {
            router.push(appRoutes.TAB_NAVIGATOR);
          }
        "
      />
      <components.Button
        :title="'Go back to the order'"
        :colorScheme="'secondary'"
        :onClick="() => router.push(appRoutes.TAB_NAVIGATOR)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
