<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Track your order'" />

    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <!-- ORDER STATUS -->
      <section
        :style="{
          gap: '10px',
          padding: '20px',
          marginBottom: '10px',
          borderRadius: 'var(--border-radius)',
          border: '1px solid var(--main-turquoise)',
        }"
        :class="'flex-column'"
      >
        <div :class="'row-c'" :style="{gap: '14px'}">
          <span :class="'t14'">Your order:</span>
          <h5 :style="{color: 'var(--main-turquoise)'}">456654</h5>
        </div>
        <div :class="'row-c'" :style="{gap: '14px'}">
          <span :class="'t14'">Date:</span>
          <h5 :style="{color: 'var(--main-turquoise)'}">Aug 31 at 8:32 pm</h5>
        </div>
      </section>

      <!-- PROGRESS -->
      <section
        :style="{
          padding: '20px',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
      >
        <ul :class="'flex-column'">
          <li
            :key="item.id"
            v-for="(item, index) in progress"
            :style="{gap: '24px', marginBottom: '7px'}"
            :class="'flex-row'"
          >
            <!-- LEFT -->
            <section :style="{width: '30px'}">
              <svg.StatusCheckSvg v-if="item.status === 'done'" />
              <svg.CircleSvg v-if="item.status === 'pending'" />
              <div
                :style="{
                  width: '2px',
                  height: '30px',
                  marginTop: '7px',
                  borderRadius: 'var(--border-radius)',
                  backgroundColor: 'var(--main-turquoise)',
                }"
                :class="'center'"
                v-if="index !== progress.length - 1"
              />
            </section>
            <!-- RIGHT -->
            <section
              :class="'flex-column'"
              :style="{gap: '6px', marginTop: '2px'}"
            >
              <span
                :class="'t14'"
                :style="{color: 'var(--main-dark)', fontWeight: 'Medium'}"
                >{{ item.title }}</span
              >
              <span :class="'t14'">{{ item.description }}</span>
            </section>
          </li>
        </ul>
      </section>
    </main>

    <!-- BUTTON -->
    <section :style="{padding: '20px'}">
      <components.Button :title="'Chat support'" />
    </section>
  </components.Screen>
</template>

<script setup>
import {svg} from '../assets/svg';
import {components} from '../components';

const progress = [
  {
    id: 1,
    title: 'Order Confirmed',
    description: 'Your order has been confirmed',
    status: 'done',
  },
  {
    id: 2,
    title: 'Order is Being Cooked',
    description: 'Estimated for 9:02 pm',
    status: 'done',
  },
  {
    id: 3,
    title: 'Courier Delivering',
    description: 'Estimated for 9:12 pm',
    status: 'pending',
  },
  {
    id: 4,
    title: 'Receiving',
    description: 'Estimated for 9:32 pm',
    status: 'pending',
  },
];
</script>
