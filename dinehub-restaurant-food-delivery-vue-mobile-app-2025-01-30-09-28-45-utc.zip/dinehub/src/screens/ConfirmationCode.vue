<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Verify number'" />

    <!-- MAIN -->
    <main :class="'scrollable container'">
      <section
        :style="{
          marginTop: '10px',
          paddingTop: '30px',
          paddingBottom: '30px',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          Enter your OTP code here.
        </p>
        <ul :class="'row-c'" :style="{gap: '13px', marginBottom: '30px'}">
          <li
            v-for="input in inputs"
            :key="input.id"
            :style="{
              width: '100%',
              height: '60px',
              backgroundColor: 'var(--white-color)',
              border: '1px solid #00B0B9',
            }"
          >
            <input
              :type="'text'"
              maxlength="1"
              size="1"
              :style="{
                width: '100%',
                height: '100%',
                borderRadius: '10px',
                border: 'none',
                backgroundColor: 'var(--white-color)',
                textAlign: 'center',
                fontSize: '20px',
                color: 'var(--main-dark)',
              }"
            />
          </li>
        </ul>
        <div :style="{marginBottom: '20px'}">
          <span :class="'t16'">Didn’t receive the OTP? Resend.</span>
          <span
            :class="'t16 clickable'"
            :style="{color: 'var(--main-turquoise)'}"
          >
            Resend.</span
          >
        </div>
        <components.Button
          :title="'verify'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.SIGN_UP_ACCOUNT_CREATED)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const inputs = ['1', '2', '3', '4', '5'];
</script>
