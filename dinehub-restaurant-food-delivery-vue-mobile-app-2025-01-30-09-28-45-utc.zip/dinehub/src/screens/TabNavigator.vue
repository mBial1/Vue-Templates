<template>
  <!-- HEADER -->
  <Header
    :showBasket="true"
    :showUser="
      currentTab === tabRoutes.HOME ||
      currentTab === tabRoutes.MENU ||
      currentTab === tabRoutes.NOTIFICATIONS ||
      currentTab === tabRoutes.FAVORITE ||
      currentTab === tabRoutes.ORDER
    "
    :title="
      currentTab === tabRoutes.NOTIFICATIONS
        ? 'Notifications'
        : currentTab === tabRoutes.FAVORITE
        ? 'Favorite'
        : currentTab === tabRoutes.ORDER
        ? 'Order'
        : ''
    "
    :showUserName="
      currentTab === tabRoutes.HOME || currentTab === tabRoutes.MENU
    "
  />

  <!-- MAIN -->
  <Home v-if="currentTab === tabRoutes.HOME" />
  <Menu v-if="currentTab === tabRoutes.MENU" />
  <Notifications v-if="currentTab === tabRoutes.NOTIFICATIONS" />
  <Order v-if="currentTab === tabRoutes.ORDER && cartStore.list.length > 0" />
  <OrderEmpty
    v-if="currentTab === tabRoutes.ORDER && cartStore.list.length === 0"
  />
  <FavoriteEmpty
    v-if="currentTab === tabRoutes.FAVORITE && wishlistStore.list.length === 0"
  />
  <Favorite
    v-if="currentTab === tabRoutes.FAVORITE && wishlistStore.list.length > 0"
  />

  <!-- BOTTOM TABS -->
  <BottomTabBar />
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../stores';
import {tabRoutes} from '../routes';
import Header from '../components/Header.vue';
import BottomTabBar from '../components/BottomTabBar.vue';

import Home from './tabs/Home.vue';
import Menu from './tabs/Menu.vue';
import Order from './tabs/Order.vue';
import Favorite from './tabs/Favorite.vue';
import OrderEmpty from './tabs/OrderEmpty.vue';
import Notifications from './tabs/Notifications.vue';
import FavoriteEmpty from './tabs/FavoriteEmpty.vue';

const tabStore = stores.tabStore();
const cartStore = stores.cartStore();
const wishlistStore = stores.wishlistStore();

const currentTab = computed(() => tabStore.currentTab);
</script>
