<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Filter'" />

    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <div
        :style="{
          paddingTop: '10%',
          paddingBottom: '10%',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <!-- NEW AND SPICY -->
        <section :style="{marginBottom: '30px'}">
          <ul :class="'row-c'" :style="{gap: '8px'}">
            <li
              v-for="(filter, index) in newAndSpicy"
              :key="index"
              :style="{
                padding: '10px 20px',
                borderRadius: 'var(--border-radius)',
                backgroundColor: filter.selected
                  ? 'var(--main-turquoise)'
                  : '#E9F3F6',
              }"
              :class="'flex-column clickable'"
              @click="filter.selected = !filter.selected"
            >
              <span
                :class="'t14'"
                :style="{
                  color: filter.selected
                    ? 'var(--white-color)'
                    : 'var(--main-color)',
                }"
                >{{ filter.title }}</span
              >
            </li>
          </ul>
        </section>

        <!-- CATEGORY -->
        <section :style="{marginBottom: '30px'}">
          <span
            :class="'t14'"
            :style="{
              display: 'block',
              color: 'var(--main-color)',
              marginBottom: '14px',
              fontWeight: 'var(--fw-medium)',
            }"
            >Category</span
          >
          <ul :class="'row-c'" :style="{gap: '8px', flexWrap: 'wrap'}">
            <li
              v-for="(filter, index) in category"
              :key="index"
              :style="{
                padding: '10px 20px',
                borderRadius: 'var(--border-radius)',
                backgroundColor: filter.selected
                  ? 'var(--main-turquoise)'
                  : '#E9F3F6',
              }"
              :class="'flex-column clickable'"
              @click="filter.selected = !filter.selected"
            >
              <span
                :class="'t14'"
                :style="{
                  color: filter.selected
                    ? 'var(--white-color)'
                    : 'var(--main-color)',
                }"
                >{{ filter.title }}</span
              >
            </li>
          </ul>
        </section>

        <!-- DATA PREFERENCES -->
        <section>
          <span
            :class="'t14'"
            :style="{
              display: 'block',
              color: 'var(--main-color)',
              marginBottom: '14px',
              fontWeight: 'var(--fw-medium)',
            }"
            >Dietary Preferences</span
          >
          <ul :class="'row-c'" :style="{gap: '8px', flexWrap: 'wrap'}">
            <li
              v-for="(filter, index) in dataPreferences"
              :key="index"
              :style="{
                padding: '10px 20px',
                borderRadius: 'var(--border-radius)',
                backgroundColor: filter.selected
                  ? 'var(--main-turquoise)'
                  : '#E9F3F6',
              }"
              :class="'flex-column clickable'"
              @click="filter.selected = !filter.selected"
            >
              <span
                :class="'t14'"
                :style="{
                  color: filter.selected
                    ? 'var(--white-color)'
                    : 'var(--main-color)',
                }"
                >{{ filter.title }}</span
              >
            </li>
          </ul>
        </section>
      </div>
    </main>

    <!-- BUTTONS -->
    <section :style="{padding: '10px 20px 10px 20px'}">
      <components.Button
        :title="'apply filters'"
        :onClick="() => router.go(-1)"
      />
      <div :class="'flex-center clickable'" :style="{height: '50px'}">
        <span
          :class="'t16'"
          :style="{color: 'var(--main-turquoise)'}"
          @click="resetFilters"
          >Reset filters</span
        >
      </div>
    </section>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';

import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const newAndSpicy = ref([
  {title: 'New', selected: false},
  {title: 'Spicy', selected: false},
]);

const category = ref([
  {title: 'Salads', selected: false},
  {title: 'Meat', selected: false},
  {title: 'Pasta', selected: false},
  {title: 'First courses', selected: false},
  {title: 'Hot meals', selected: false},
  {title: 'Sea food', selected: false},
  {title: 'Snacks', selected: false},
]);

const dataPreferences = ref([
  {title: 'Vegetarian', selected: false},
  {title: 'Vegan', selected: false},
  {title: 'Gluten free', selected: false},
  {title: 'Lactose free', selected: false},
  {title: 'Nut-Free', selected: false},
  {title: 'Egg-Free', selected: false},
  {title: 'Sugar-Free', selected: false},
  {title: 'Low Carb', selected: false},
]);

const resetFilters = () => {
  newAndSpicy.value.forEach((filter) => (filter.selected = false));
  category.value.forEach((filter) => (filter.selected = false));
  dataPreferences.value.forEach((filter) => (filter.selected = false));
};
</script>
