<template>
  <components.Screen>
    <!-- MAIN CONTENT -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container flex-center'"
      >
        <img
          alt="rate service"
          :class="'status-img center'"
          :style="{marginBottom: '14px'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/03.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          Thank you for <br />
          your order!
        </h2>
        <p :style="{textAlign: 'center'}" :class="'t16'">
          Your order will be delivered on time. <br />
          Thank you!
        </p>
      </section>
    </main>

    <!-- BUTTONS -->
    <section :style="{padding: '20px'}">
      <components.Button
        :style="{marginBottom: '14px'}"
        :title="'Continue Shopping'"
        :onClick="() => router.push(appRoutes.TAB_NAVIGATOR)"
      />
      <components.Button :title="'View orders'" :colorScheme="'secondary'" />
    </section>
  </components.Screen>
</template>

<script setup>
import {onBeforeMount} from 'vue';

import {stores} from '../stores';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const cartStore = stores.cartStore();

onBeforeMount(() => {
  cartStore.resetCart();
});
</script>
