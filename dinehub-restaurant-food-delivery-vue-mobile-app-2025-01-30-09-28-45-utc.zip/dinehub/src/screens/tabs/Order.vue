<template>
  <components.Screen>
    <!-- MAIN CONTENT -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section>
        <!-- CART ITEMS -->
        <ul v-if="cartStore.list.length">
          <items.OrderItem
            :item="item"
            :key="item.id"
            v-for="(item, index) in cartStore.list"
            :style="{
              marginBottom: index === cartStore.list.length - 1 ? '0' : '14px',
            }"
          />
        </ul>

        <!-- APPLY PROMOCODE -->
        <div
          :style="{paddingTop: '20px', paddingBottom: '18%'}"
          :class="'clickable'"
        >
          <svg.ApplyPromocode />
        </div>

        <!-- TOTAL -->
        <div
          :style="{
            padding: '20px',
            borderRadius: 'var(--border-radius)',
            border: '1px solid var(--main-turquoise)',
          }"
        >
          <div :class="'row-c-sb'" :style="{marginBottom: '10px'}">
            <span :class="'t14'" :style="{color: 'var(--main-color)'}"
              >Subtotal</span
            >
            <span :class="'t14'" :style="{color: 'var(--main-color)'}"
              >${{ cartStore.subtotal.toFixed(2) }}</span
            >
          </div>
          <div :class="'row-c-sb'" :style="{marginBottom: '10px'}">
            <span :class="'t14'">Discount</span>
            <span :class="'t14'">- ${{ cartStore.discount }}</span>
          </div>
          <div
            :class="'row-c-sb'"
            :style="{
              marginBottom: '10px',
              borderBottom: '1px solid #DBE9F5',
              paddingBottom: '14px',
              marginBottom: '20px',
            }"
          >
            <span :class="'t14'">Delivery</span>
            <span :class="'t14'">${{ cartStore.delivery }}</span>
          </div>
          <div :class="'row-c-sb'">
            <h4>Total</h4>
            <h4>${{ cartStore.total.toFixed(2) }}</h4>
          </div>
        </div>
      </section>
    </main>

    <!-- BUTTON  -->
    <section
      :style="{padding: '20px 20px 10px 20px'}"
      v-if="cartStore.list.length > 0"
    >
      <components.Button
        :title="'Checkout'"
        :onClick="() => router.push(appRoutes.CHECKOUT)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {items} from '../../items';
import {stores} from '../../stores';
import {svg} from '../../assets/svg';
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();

const cartStore = stores.cartStore();
</script>
