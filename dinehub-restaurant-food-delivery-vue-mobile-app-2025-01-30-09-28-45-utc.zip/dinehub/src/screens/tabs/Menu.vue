<template>
  <components.Screen>
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: ' 10px'}"
    >
      <ul
        :style="{
          gap: '15px',
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
        }"
      >
        <li
          v-for="item in menu"
          :key="item.id"
          :style="{
            backgroundColor: 'var(--white-color)',
            borderRadius: '10px',
            position: 'relative',
          }"
          :class="'clickable'"
          :onClick="() => router.push(appRoutes.MENU_LIST)"
        >
          <img
            :src="item.image"
            :alt="item.title"
            :style="{width: '100%', borderRadius: '10px'}"
          />
          <div
            :style="{
              position: 'absolute',
              bottom: 0,
              left: 0,
              padding: '10px 15px',
            }"
          >
            <span
              :class="'t16 number-of-lines-1'"
              :style="{color: 'var(--main-color)'}"
            >
              {{ item.name }}
            </span>
          </div>
        </li>
      </ul>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();

const {menuLoading, menu} = composables.useGetMenu();
</script>
