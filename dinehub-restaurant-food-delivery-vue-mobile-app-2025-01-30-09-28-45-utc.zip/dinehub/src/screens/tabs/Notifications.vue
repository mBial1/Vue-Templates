<template>
  <components.Screen>
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: ' 10px'}"
    >
      <!-- NOTIFICATIONS -->
      <ul v-if="!notificationsLoading">
        <li
          :key="notification.id"
          v-for="(notification, index) in notifications"
          :style="{
            padding: '20px',
            backgroundColor: 'var(--white-color)',
            borderRadius: '10px',
            marginBottom: index === notifications.length - 1 ? '0' : '14px',
          }"
        >
          <div
            :style="{
              opacity: readNotifications.includes(notification.id)
                ? '0.5'
                : '1',
            }"
          >
            <div :class="'row-c'" :style="{gap: '8px', marginBottom: '14px'}">
              <img
                :src="notification.icon"
                :alt="notification.title"
                :style="{width: '24px', height: '24px'}"
              />
              <h5>{{ notification.title }}</h5>
            </div>
            <p :class="'t14'" :style="{marginBottom: '14px'}">
              {{ notification.description }}
            </p>
            <div :class="'row-c-sb'">
              <span :class="'t12'">{{ notification.date }}</span>
              <span
                :class="'t12 clickable'"
                @click="markAsRead(notification.id)"
                v-if="!readNotifications.includes(notification.id)"
                :style="{color: 'var(--main-turquoise)', cursor: 'pointer'}"
              >
                Mark as read
              </span>
            </div>
          </div>
        </li>
      </ul>

      <!-- LOADER -->
      <div
        :style="{height: '100%'}"
        :class="'flex-center t14'"
        v-if="notificationsLoading"
      >
        Loading...
      </div>
    </main>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';

import {components} from '../../components';
import {composables} from '../../composables';

const {notificationsLoading, notifications} = composables.useGetNotifications();

const readNotifications = ref([]);

const markAsRead = (id) => {
  if (!readNotifications.value.includes(id)) {
    readNotifications.value.push(id);
  }
};
</script>
