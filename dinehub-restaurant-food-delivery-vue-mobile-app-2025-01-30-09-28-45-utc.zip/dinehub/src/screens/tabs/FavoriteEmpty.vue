<template>
  <components.Screen>
    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '20px'}"
    >
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          backgroundColor: 'var(--white-color)',
          borderRadius: 'var(--border-radius)',
        }"
        :class="'flex-center'"
      >
        <img
          alt="rate service"
          :class="'center'"
          :style="{marginBottom: '14px', width: '60%'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/01.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          Your favorite list <br />
          is empty!
        </h2>
        <p :class="'t16'" :style="{textAlign: 'center'}">
          Your list of favorite dishes is currently <br />
          empty. Why not start adding dishes <br />
          that you love?
        </p>
      </section>
    </main>

    <!-- BUTTON -->
    <section :class="'container'">
      <components.Button
        title="Explore Our Menu"
        :onClick="() => router.push(appRoutes.MENU_LIST)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();
</script>
