<template>
  <components.Screen>
    <!-- MAIN -->
    <main
      v-if="!loading"
      :class="'scrollable'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <!-- CAROUSEL SECTION -->
      <section :style="{position: 'relative'}">
        <!-- CAROUSEL -->
        <swiper
          :style="{marginBottom: '30px'}"
          @slideChange="handleSlideChange"
        >
          <swiper-slide
            v-for="item in carousel"
            :key="item.id"
            :class="'clickable'"
            :onClick="
              () => router.push({name: appRoutes.DISH, params: {id: item.id}})
            "
          >
            <img
              :src="item.banner"
              :alt="item.title"
              :style="{width: '100%', height: 'auto'}"
            />
          </swiper-slide>
        </swiper>
        <!-- DOTS -->
        <div
          :style="{
            gap: '8px',
            position: 'absolute',
            bottom: '20px',
            zIndex: '1',
            width: '100%',
          }"
          :class="'flex-center'"
        >
          <div
            v-for="(item, index) in carousel"
            :key="item.id"
            :style="{
              width: '8px',
              height: activeIndex === index ? '20px' : '8px',
              borderRadius: '10px',
              backgroundColor:
                activeIndex === index
                  ? 'var(--white-color)'
                  : 'rgba(255, 255, 255, 0.5)',
            }"
          ></div>
        </div>
      </section>

      <!-- CATEGORY SECTION -->
      <section :style="{marginBottom: '30px'}">
        <components.BlockHeading
          title="We offer"
          :class="'container'"
          :showViewAll="true"
          :container-style="{marginBottom: '14px'}"
          :viewAllOnClick="() => $router.push(appRoutes.MENU_LIST)"
        />
        <swiper
          :slides-per-view="3.5"
          :space-between="10"
          :style="{paddingLeft: '20px', paddingRight: '20px'}"
        >
          <swiper-slide
            v-for="item in menu"
            :key="item.id"
            :style="{position: 'relative', borderRadius: '10px'}"
            :class="'clickable'"
            :onClick="() => router.push({name: appRoutes.MENU_LIST})"
          >
            <img
              :src="item.image"
              :alt="item.name"
              :style="{
                width: '100%',
                height: 'auto',
                borderRadius: '10px',
              }"
            />
            <div
              :style="{
                padding: '10px 15px',
                position: 'absolute',
                bottom: 0,
                left: 0,
              }"
            >
              <span
                :class="'t10 number-of-lines-1'"
                :style="{
                  color: 'var(--main-color)',
                }"
                >{{ item.name }}</span
              >
            </div>
          </swiper-slide>
        </swiper>
      </section>

      <!-- RECOMMENDED FOR YOU -->
      <section :style="{marginBottom: '30px'}">
        <components.BlockHeading
          title="Recommended for you"
          :class="'container'"
          :container-style="{marginBottom: '14px'}"
        />
        <swiper
          v-if="!dishesLoading && dishes.length"
          :slides-per-view="1.7"
          :space-between="14"
          :style="{paddingLeft: '20px', paddingRight: '20px'}"
        >
          <swiper-slide
            v-for="dish in dishes"
            :key="dish.id"
            :style="{
              backgroundColor: 'var(--white-color)',
              borderRadius: '10px',
              padding: '14px',
            }"
            :class="'clickable'"
            :onClick="
              () => router.push({name: appRoutes.DISH, params: {id: dish.id}})
            "
          >
            <svg.NewSvg
              v-if="dish.isNew"
              :style="{
                position: 'absolute',
                top: '14px',
                left: '14px',
              }"
            />
            <img
              :src="dish.image"
              :alt="dish.name"
              :style="{
                width: '100%',
                height: 'auto',
                borderRadius: '10px',
                marginBottom: '14px',
              }"
            />
            <p :class="'t14 number-of-lines-1'">{{ dish.name }}</p>
            <div :style="{gap: '8px'}" :class="'row-c'">
              <span
                :class="'t14'"
                :style="{
                  fontWeight: '600',
                  color: 'var(--main-color)',
                }"
                >${{ dish.price }}</span
              >
              <span
                :style="{
                  fontSize: '12px',
                  fontWeight: '700',
                  color: '#D5DCE3',
                }"
                >|</span
              >
              <span :class="'t10'">{{ dish.weight }}g</span>
            </div>
            <svg.HeartSvg
              :dish="dish"
              :containerStyle="{
                padding: '14px',
                position: 'absolute',
                right: '0',
                bottom: 'calc(66px - 14px)',
              }"
            />
            <svg.PlusSvg
              :dish="dish"
              :containerStyle="{
                position: 'absolute',
                right: '0',
                bottom: '0',
                padding: '14px',
              }"
            />
          </swiper-slide>
        </swiper>
      </section>

      <!-- REVIEWS SECTION -->
      <section>
        <components.BlockHeading
          title="Our Happy clients say"
          :class="'container'"
          :showViewAll="true"
          :container-style="{marginBottom: '14px'}"
          :viewAllOnClick="() => $router.push(appRoutes.REVIEWS)"
        />
        <swiper
          :space-between="14"
          :slides-per-view="1.1"
          :style="{paddingLeft: '20px', paddingRight: '20px'}"
        >
          <swiper-slide
            v-for="review in reviews"
            :key="review.id"
            :style="{
              padding: '14px',
              borderRadius: '10px',
              height: 'auto',
              backgroundColor: 'var(--white-color)',
            }"
          >
            <!-- REVIEW HEADER -->
            <div
              :class="'row-c'"
              :style="{
                gap: '14px',
                borderBottom: '1px solid #F1F3F6',
                paddingBottom: '11px',
              }"
            >
              <img
                :src="review.avatar"
                :alt="review.name"
                :style="{width: '30px', height: '30px', borderRadius: '50%'}"
              />
              <div>
                <h5 :style="{marginBottom: '4px', textTransform: 'capitalize'}">
                  {{ review.name }}
                </h5>
                <!-- <ReviewRating :rating="review.rating" /> -->
              </div>
              <div :style="{marginLeft: 'auto'}" :class="'flex-column'">
                <span
                  :style="{textAlign: 'right', marginBottom: '2px'}"
                  :class="'t10'"
                >
                  {{ review.date }}
                </span>
                <span
                  :style="{textAlign: 'right', color: 'var(--main-turquoise)'}"
                  :class="'t10 clickable'"
                  >Reply</span
                >
              </div>
            </div>
            <!-- REVIEW BODY -->
            <p :style="{marginTop: '14px'}" :class="'t14 number-of-lines-2'">
              {{ review.comment }}
            </p>
          </swiper-slide>
        </swiper>
      </section>
    </main>

    <!-- LOADING TEXT -->
    <div
      v-if="loading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>
  </components.Screen>
</template>

<script setup>
import {ref, computed} from 'vue';
import {Swiper} from 'swiper/vue';
import {SwiperSlide} from 'swiper/vue';

import {svg} from '../../assets/svg';
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();

const {menuLoading, menu} = composables.useGetMenu();
const {dishesLoading, dishes} = composables.useGetDishes();
const {reviewsLoading, reviews} = composables.useGetReviews();
const {carouselLoading, carousel} = composables.useGetCarousel();

const loading = computed(
  () =>
    menuLoading.value ||
    dishesLoading.value ||
    reviewsLoading.value ||
    carouselLoading.value
);

const activeIndex = ref(0);

const handleSlideChange = (swiper) => {
  activeIndex.value = swiper.activeIndex;
};
</script>
