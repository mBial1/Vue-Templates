<template>
  <components.Screen>
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <!-- FAVORITE -->
      <ul
        :style="{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '15px',
        }"
        v-if="list.length"
      >
        <li
          v-for="item in list"
          :key="item.id"
          :style="{
            padding: '14px',
            borderRadius: '10px',
            position: 'relative',
            backgroundColor: 'var(--white-color)',
          }"
        >
          <component
            :is="NewSvg"
            v-if="item.isNew"
            :style="{position: 'absolute', top: '14px', left: '14px'}"
          />
          <img
            :src="item.image"
            :alt="item.title"
            style="width: 100%"
            :class="'clickable'"
            :onClick="
              () => router.push({name: appRoutes.DISH, params: {id: item.id}})
            "
          />
          <span
            :class="'t14 number-of-lines-1'"
            :style="{marginBottom: '3px'}"
            >{{ item.name }}</span
          >
          <div :style="{gap: '8px'}" :class="'row-c'">
            <span
              :class="'t14'"
              :style="{
                fontWeight: '600',
                color: 'var(--main-color)',
              }"
              >${{ item.price }}</span
            >
            <span
              :style="{
                fontSize: '12px',
                fontWeight: '700',
                color: '#D5DCE3',
              }"
              >|</span
            >
            <span :class="'t10'">{{ item.weight }}g</span>
          </div>
          <button
            :style="{
              position: 'absolute',
              right: '0',
              bottom: '0',
              padding: '14px',
            }"
            :class="'clickable'"
          >
            <svg.PlusSvg :dish="item" />
          </button>
          <button
            :style="{
              right: '0',
              position: 'absolute',
              bottom: 'calc(66px - 14px)',
            }"
            :class="'clickable'"
          >
            <svg.HeartSvg :dish="item" />
          </button>
        </li>
      </ul>
    </main>
  </components.Screen>
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../../stores';
import {svg} from '../../assets/svg';
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();

const wishlistStore = stores.wishlistStore();
const list = computed(() => wishlistStore.list);
</script>
