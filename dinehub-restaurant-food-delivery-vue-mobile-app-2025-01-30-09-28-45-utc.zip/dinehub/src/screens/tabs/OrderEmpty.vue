<template>
  <components.Screen>
    <!-- MAIN CONTENT -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container flex-center'"
      >
        <img
          alt="rate service"
          :class="'center'"
          :style="{marginBottom: '14px', width: '80%'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/02.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          Your cart is empty!
        </h2>
        <p :style="{textAlign: 'center'}" :class="'t16'">
          Looks like you haven't made <br />
          your order yet.
        </p>
      </section>
    </main>

    <!-- BUTTON IF CART IS EMPTY -->
    <section :style="{padding: '20px 20px 0px 20px'}">
      <components.Button
        :title="'Shop now'"
        :onClick="() => router.push(appRoutes.MENU_LIST)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../../routes';
import {components} from '../../components';
import {composables} from '../../composables';

const {router} = composables.useRouter();
</script>
