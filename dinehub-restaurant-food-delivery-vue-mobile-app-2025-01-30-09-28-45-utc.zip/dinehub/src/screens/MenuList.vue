<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :showBasket="true" :title="'Menu'" />

    <!-- SEARCH -->
    <section
      :class="'container row-c'"
      :style="{
        gap: '5px',
        height: '50px',
        marginTop: '5px',
        marginBottom: '14px',
      }"
      v-if="!dishesLoading"
    >
      <components.InputField
        :inputType="'search'"
        :placeholder="'Search ...'"
        :containerStyle="{backgroundColor: 'var(--white-color)', flex: 1}"
      />
      <div
        :style="{
          width: '50px',
          height: '100%',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'flex-center clickable'"
        :onClick="() => router.push(appRoutes.FILTER)"
      >
        <svg.FilterSvg />
      </div>
    </section>

    <!-- DISHES -->
    <main
      v-if="!dishesLoading"
      :class="'container scrollable'"
      :style="{paddingBottom: '20px'}"
    >
      <ul>
        <li
          v-for="(dish, index) in dishes"
          :key="dish.id"
          :style="{
            gap: '10px',
            backgroundColor: 'var(--white-color)',
            borderRadius: 'var(--border-radius)',
            marginBottom: index === dishes.length - 1 ? '0px' : '14px',
            paddingLeft: '10px',
            paddingTop: '14px',
            paddingBottom: '14px',
            paddingRight: '14px',
            position: 'relative',
          }"
          :class="'row-c clickable'"
          :onClick="
            () => router.push({name: appRoutes.DISH, params: {id: dish.id}})
          "
        >
          <img
            :src="dish.image"
            :alt="dish.name"
            :style="{
              width: '34%',
              height: 'auto',
              borderRadius: 'var(--border-radius)',
            }"
          />
          <div>
            <span
              :class="'t14 number-of-lines-1'"
              :style="{
                marginBottom: '4px',
                color: 'var(--main-color)',
                marginRight: '20px',
              }"
              >{{ dish.name }}</span
            >
            <p :class="'t10 number-of-lines-2'" :style="{marginBottom: '4px'}">
              {{ dish.description }}
            </p>
            <div :style="{gap: '8px', marginBottom: '6px'}" :class="'row-c'">
              <span :class="'t10'">{{ dish.kcal }} kcal</span>
              <span
                :style="{
                  fontSize: '12px',
                  fontWeight: '700',
                  color: '#D5DCE3',
                }"
                >|</span
              >
              <span :class="'t10'">{{ dish.weight }}g</span>
            </div>
            <span
              :class="'t14'"
              :style="{
                fontWeight: '600',
                color: 'var(--main-color)',
              }"
              >${{ dish.price }}</span
            >
          </div>
          <svg.HeartSvg
            :dish="dish"
            :containerStyle="{
              padding: '14px',
              position: 'absolute',
              right: '0',
              top: '0',
            }"
          />
          <svg.PlusSvg
            :dish="dish"
            :containerStyle="{
              position: 'absolute',
              right: '0',
              bottom: '0',
              padding: '14px',
            }"
          />
          <svg.NewSvg
            v-if="dish.isNew"
            :style="{
              position: 'absolute',
              top: '7px',
              left: '7px',
            }"
          />
          <img
            :src="peper"
            :style="{
              width: '13px',
              position: 'absolute',
              top: '7px',
              left: '7px',
            }"
            v-if="dish.isHot"
          />
        </li>
      </ul>
    </main>

    <!-- LOADING TEXT -->
    <div
      v-if="dishesLoading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>
  </components.Screen>
</template>

<script setup>
import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

import peper from '../assets/icons/01.png';

const {router} = composables.useRouter();

const {dishesLoading, dishes} = composables.useGetDishes();
</script>
