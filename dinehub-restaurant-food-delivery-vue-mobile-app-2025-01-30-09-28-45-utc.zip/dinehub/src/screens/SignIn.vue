<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" />

    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <h1 :style="{marginBottom: '14px'}">Welcome Back!</h1>
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          Sign in to continue
        </p>
        <components.InputField
          :placeholder="'Email'"
          :inputType="'email'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Password'"
          :inputType="'password'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '14px'}"
        />
        <div :class="'row-c-sb'" :style="{marginBottom: '40px'}">
          <button
            :class="'row-c'"
            :style="{gap: '10px'}"
            @click="toggleCheckbox"
          >
            <div
              :style="{
                width: '18px',
                height: '18px',
                backgroundColor: '#E6EFF8',
                borderRadius: '4px',
              }"
              :class="'flex-center'"
            >
              <component v-if="isChecked" :is="svg.RememberSvg" />
            </div>
            <span :class="'t14'">Remember me</span>
          </button>
          <span
            :class="'t14 clickable'"
            :style="{color: 'var(--main-turquoise)'}"
            :onClick="() => router.push(appRoutes.FORGOT_PASSWORD)"
            >Forgot password?</span
          >
        </div>
        <components.Button
          :title="'Sign In'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.TAB_NAVIGATOR)"
        />
        <p :class="'t14'">
          Don’t have an account?
          <span
            :style="{color: 'var(--main-turquoise)'}"
            :class="'clickable'"
            :onClick="() => router.push(appRoutes.SIGN_UP)"
            >Sign up.</span
          >
        </p>
      </section>
    </main>

    <!-- SOCIAL -->
    <section
      :class="'container row-c'"
      :style="{paddingTop: '10px', paddingBottom: '20px', gap: '15px'}"
    >
      <button
        :style="{
          backgroundColor: 'var(--white-color)',
          width: '100%',
          height: '50px',
          borderBottomLeftRadius: '10px',
          borderBottomRightRadius: '10px',
        }"
        :class="'flex-center clickable'"
      >
        <component :is="svg.FacebookSvg" />
      </button>
      <button
        :style="{
          backgroundColor: 'var(--white-color)',
          width: '100%',
          height: '50px',
          borderBottomLeftRadius: '10px',
          borderBottomRightRadius: '10px',
        }"
        :class="'flex-center clickable'"
      >
        <component :is="svg.GoogleSvg" />
      </button>
    </section>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';

import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const toggleCheckbox = () => (isChecked.value = !isChecked.value);
const isChecked = ref(false);
</script>
