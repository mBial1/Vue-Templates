<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Promocodes & gift cards'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '20px'}"
    >
      <section
        :style="{
          height: '100%',
          flexDirection: 'column',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'flex-center container'"
      >
        <img
          alt="rate service"
          :class="'center'"
          :style="{marginBottom: '14px', width: '80%'}"
          src="https://george-fx.github.io/dinehub_api/assets/images/04.jpg"
        />
        <h2
          :style="{
            textAlign: 'center',
            textTransform: 'capitalize',
            marginBottom: '14px',
          }"
        >
          You don’t have <br />
          promocodes yet!
        </h2>
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          Stay tuned for and discounts to <br />
          enhance your dining experience.
        </p>
        <components.InputField
          :inputType="'coupon'"
          :placeholder="'Add new coupon'"
          :containerStyle="{width: '100%'}"
        />
        <components.Button
          :title="'add promocode'"
          :style="{marginTop: '20px'}"
          :onClick="() => router.push(appRoutes.PROMOCODES)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
