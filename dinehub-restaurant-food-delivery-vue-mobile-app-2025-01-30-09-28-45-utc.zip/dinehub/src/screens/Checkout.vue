<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Checkout'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <!-- SUMMARY -->
      <section
        :style="{
          padding: '20px',
          marginBottom: '14px',
          borderRadius: 'var(--border-radius)',
          border: '1px solid var(--main-turquoise)',
        }"
      >
        <div
          :class="'row-c-sb'"
          :style="{
            marginBottom: '20px',
            paddingBottom: '20px',
            borderBottom: '1px solid #DBE9F5',
          }"
        >
          <h4>My Order</h4>
          <h4>$25.83</h4>
        </div>
        <ul>
          <li
            v-for="(item, index) in filteredCart"
            :key="item.id"
            :class="'row-c-sb'"
            :style="{
              marginBottom: index === filteredCart.length - 1 ? '10px' : '10px',
            }"
          >
            <span :class="'t14'">{{ item.name }}</span>
            <span :class="'t14'">{{ item.quantity }} x ${{ item.price }}</span>
          </li>
        </ul>
        <div :class="'row-c-sb'" :style="{marginBottom: '10px'}">
          <span :class="'t14'">Discount</span>
          <span :class="'t14'">- ${{ cartStore.discount }}</span>
        </div>
        <div :class="'row-c-sb'">
          <span :class="'t14'">Delivery</span>
          <span :class="'t14'">${{ cartStore.delivery }}</span>
        </div>
      </section>

      <!-- ADDRESS -->
      <section
        :style="{
          padding: '20px',
          marginBottom: '14px',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'row-c-sb clickable'"
      >
        <div :class="'flex-column'">
          <span
            :class="'t14 number-of-lines-1'"
            :style="{
              marginBottom: '10px',
              color: 'var(--main-color)',
              textTransform: 'capitalize',
              fontWeight: 'var(--fw-medium)',
            }"
            >Shipping details</span
          >
          <span :class="'t14 number-of-lines-1'"
            >8000 S Kirkland Ave, Chicago, IL 6065...</span
          >
        </div>
        <svg.RightArrowSvg />
      </section>

      <!-- PAYMENT -->
      <section
        :style="{
          padding: '20px',
          borderRadius: 'var(--border-radius)',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'row-c-sb clickable'"
      >
        <div :class="'flex-column'">
          <span
            :class="'t14 number-of-lines-1'"
            :style="{
              marginBottom: '10px',
              color: 'var(--main-color)',
              textTransform: 'capitalize',
              fontWeight: 'var(--fw-medium)',
            }"
            >Payment method</span
          >
          <span :class="'t14 number-of-lines-1'">4947 **** **** 3157</span>
        </div>
        <svg.RightArrowSvg />
      </section>
    </main>

    <!-- BUTTON -->
    <section :style="{padding: '20px'}">
      <components.Button
        :title="'Confirm order'"
        :onClick="() => router.push(appRoutes.ORDER_SUCCESSFUL)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {computed} from 'vue';

import {stores} from '../stores';
import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const cartStore = stores.cartStore();
const cart = computed(() => cartStore.list);
const filteredCart = computed(() => cart.value.filter((item) => item !== null));
</script>
