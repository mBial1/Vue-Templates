<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Reviews'" />

    <!-- MAIN -->
    <main
      v-if="!reviewsLoading"
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <ul>
        <li
          :key="review.id"
          v-for="(review, index) in reviews"
          :style="{
            padding: '20px',
            borderRadius: 'var(--border-radius)',
            backgroundColor: 'var(--white-color)',
            marginBottom: index === reviews.length - 1 ? '0' : '14px',
          }"
        >
          <div
            :class="'row-c'"
            :style="{
              gap: '14px',
              borderBottom: '1px solid #F1F3F6',
              paddingBottom: '11px',
            }"
          >
            <img
              :src="review.avatar"
              :alt="review.name"
              :style="{width: '30px', height: '30px', borderRadius: '50%'}"
            />
            <div>
              <h5 :style="{marginBottom: '4px', textTransform: 'capitalize'}">
                {{ review.name }}
              </h5>
              <components.ReviewRating :rating="review.rating" />
            </div>
            <div :style="{marginLeft: 'auto'}" :class="'flex-column'">
              <span
                :style="{textAlign: 'right', marginBottom: '2px'}"
                :class="'t10'"
              >
                {{ review.date }}
              </span>
              <span
                :style="{textAlign: 'right', color: 'var(--main-turquoise)'}"
                :class="'t10 clickable'"
                >Reply</span
              >
            </div>
          </div>
          <p :style="{marginTop: '14px'}" :class="'t14 number-of-lines-2'">
            {{ review.comment }}
          </p>
        </li>
      </ul>
    </main>

    <!-- LOADING TEXT -->
    <div
      v-if="reviewsLoading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>
  </components.Screen>
</template>

<script setup>
import {components} from '../components';
import {composables} from '../composables';

const {reviewsLoading, reviews} = composables.useGetReviews();
</script>
