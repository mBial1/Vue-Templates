<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" />

    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <h1 :style="{marginBottom: '30px', textTransform: 'capitalize'}">
          Sign Up
        </h1>
        <components.InputField
          :placeholder="'Username'"
          :inputType="'username'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Email'"
          :inputType="'email'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Password'"
          :inputType="'password'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Password'"
          :inputType="'password'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '20px'}"
        />
        <components.Button
          :title="'Sign up'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.VERIFY_YOUR_PHONE_NUMBER)"
        />
        <p :class="'t14'">
          Already have an account?
          <span
            :style="{color: 'var(--main-turquoise)'}"
            :class="'clickable'"
            :onClick="() => router.push(appRoutes.SIGN_IN)"
            >Sign in.</span
          >
        </p>
      </section>
    </main>

    <!-- SOCIAL -->
    <section
      :class="'container row-c'"
      :style="{paddingTop: '10px', paddingBottom: '20px', gap: '15px'}"
    >
      <button
        :style="{
          backgroundColor: 'var(--white-color)',
          width: '100%',
          height: '50px',
          borderBottomLeftRadius: '10px',
          borderBottomRightRadius: '10px',
        }"
        :class="'flex-center clickable'"
      >
        <component :is="svg.FacebookSvg" />
      </button>
      <button
        :style="{
          backgroundColor: 'var(--white-color)',
          width: '100%',
          height: '50px',
          borderBottomLeftRadius: '10px',
          borderBottomRightRadius: '10px',
        }"
        :class="'flex-center clickable'"
      >
        <component :is="svg.GoogleSvg" />
      </button>
    </section>
  </components.Screen>
</template>

<script setup>
import {svg} from '../assets/svg';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
