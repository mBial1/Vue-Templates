<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Reset password'" />

    <!-- MAIN -->
    <main :class="'scrollable container'">
      <section
        :style="{
          marginTop: '10px',
          paddingTop: '30px',
          paddingBottom: '30px',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          Enter new password and confirm.
        </p>
        <components.InputField
          :placeholder="'Password'"
          :inputType="'password'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Confirm password'"
          :inputType="'password'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '20px'}"
        />
        <components.Button
          :title="'change password'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.FORGOT_PASSWORD_SENT_EMAIL)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
