<template>
  <components.Screen>
    <!-- MAIN -->
    <main :class="'scrollable container'" :style="{paddingTop: '10px'}">
      <section
        :style="{
          height: '100%',
          borderRadius: '10px',
          flexDirection: 'column',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container flex-center'"
      >
        <img
          :alt="'account created'"
          :class="'status-img center'"
          :style="{marginBottom: '40px'}"
          :src="'https://george-fx.github.io/dine-hub/05.jpg'"
        />
        <h1
          :style="{
            textAlign: 'center',
            marginBottom: '14px',
            textTransform: 'capitalize',
          }"
        >
          Your password has <br />
          been reset!
        </h1>
        <p :class="'t16'" :style="{textAlign: 'center'}">
          Log in with your new password to <br />
          continue your journey.
        </p>
      </section>
    </main>

    <!-- BUTTON -->
    <section :style="{padding: '20px'}">
      <components.Button
        :title="'Done'"
        :onClick="() => router.push(appRoutes.SIGN_IN)"
      />
    </section>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
