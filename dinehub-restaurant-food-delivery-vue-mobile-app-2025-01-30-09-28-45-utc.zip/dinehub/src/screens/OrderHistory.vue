<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Order history'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
      v-if="!ordersLoading"
    >
      <section :class="'accordion'">
        <div
          v-for="order in orders"
          :key="order.id"
          :style="{borderRadius: '10px'}"
        >
          <details
            :open="isOpen(order.id)"
            @toggle="handleToggle(order.id)"
            :style="{
              backgroundColor: 'var(--white-color)',
              marginBottom: '10px',
              borderRadius: '10px',
            }"
          >
            <summary
              :style="{
                padding: '20px',
                borderBottom: isOpen(order.id) ? '1px solid #DBE9F5' : 'none',
              }"
              :class="'clickable'"
            >
              <section class="row-c" :style="{marginBottom: '6px'}">
                <span
                  class="t14"
                  :style="{
                    marginRight: '4px',
                    fontWeight: '500',
                    color: 'var(--main-color)',
                  }"
                >
                  {{ order.date }}
                </span>
                <span
                  class="t10"
                  :style="{marginRight: 'auto', marginTop: '4px'}"
                >
                  at {{ order.time }}
                </span>
                <span
                  class="t14"
                  :style="{fontWeight: '500', color: 'var(--main-color)'}"
                >
                  ${{ order.total }}
                </span>
              </section>
              <section class="row-c-sb">
                <span class="t12">Order ID: {{ order.id }}</span>
                <span
                  :style="{
                    padding: '3px 8px',
                    borderRadius: '5px',
                    backgroundColor:
                      order.status === 'delivered'
                        ? '#00B0B9'
                        : order.status === 'shipping'
                        ? '#FFA462'
                        : '#FA5555',
                    color: '#fff',
                    fontWeight: '500',
                    lineHeight: '1.2',
                  }"
                  class="t10"
                >
                  {{ order.status }}
                </span>
              </section>
            </summary>
            <section :style="{padding: '20px'}">
              <ul>
                <li
                  v-for="product in order.products"
                  :key="product.id"
                  :class="'row-c-sb'"
                  :style="{marginBottom: '8px'}"
                >
                  <span class="t14">{{ product.name }}</span>
                  <span class="t14" :style="{marginLeft: 'auto'}"
                    >{{ product.quantity }} x ${{ product.price }}</span
                  >
                </li>
                <li :class="'row-c-sb'" :style="{marginBottom: '8px'}">
                  <span class="t14">Discount</span>
                  <span class="t14">- ${{ order.discount }}</span>
                </li>
                <li :class="'row-c-sb'">
                  <span class="t14">Delivery</span>
                  <span class="t14">${{ order.delivery }}</span>
                </li>
              </ul>
            </section>
          </details>
          <div
            v-if="isOpen(order.id) && order.status === 'shipping'"
            class="row-c"
            :style="{marginBottom: '20px', gap: '15px'}"
          >
            <components.Button :title="'track order'" :onClick="trackOrder" />
          </div>
          <div
            v-if="isOpen(order.id) && order.status !== 'shipping'"
            class="row-c"
            :style="{marginBottom: '20px', gap: '15px'}"
          >
            <components.Button
              :title="'repeat order'"
              :onClick="repeatOrder"
              :colorScheme="'secondary'"
            />
            <components.Button :title="'leave review'" :onClick="leaveReview" />
          </div>
        </div>
      </section>
    </main>

    <!-- LOADING TEXT -->
    <div
      v-if="ordersLoading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>
  </components.Screen>
</template>

<script setup>
import {ref} from 'vue';
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();

const {ordersLoading, orders} = composables.useGetOrders();
const openAccordions = ref(new Set());

const isOpen = (id) => {
  return openAccordions.value.has(id);
};

const handleToggle = (id) => {
  if (openAccordions.value.has(id)) {
    openAccordions.value.delete(id);
  } else {
    openAccordions.value.add(id);
  }
};

const trackOrder = () => {
  router.push(appRoutes.TRACK_YOUR_ORDER);
};

const repeatOrder = () => {
  router.push(appRoutes.TAB_NAVIGATOR);
};

const leaveReview = () => {
  router.push(appRoutes.LEAVE_A_REVIEW);
};
</script>
