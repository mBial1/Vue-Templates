<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Forgot password'" />

    <!-- MAIN -->
    <main :class="'scrollable container'">
      <section
        :style="{
          marginTop: '10px',
          paddingTop: '30px',
          borderRadius: '10px',
          paddingBottom: '30px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <p :class="'t16'" :style="{marginBottom: '30px'}">
          Please enter your email address. You will receive a link to create a
          new password via email.
        </p>
        <components.InputField
          :inputType="'email'"
          :placeholder="'Email'"
          :rightIconOnClick="(value) => console.log(value)"
          :containerStyle="{marginBottom: '20px'}"
        />
        <components.Button
          :title="'send'"
          :containerStyle="{marginBottom: '20px'}"
          :onClick="() => router.push(appRoutes.NEW_PASSWORD)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {appRoutes} from '../routes';
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
