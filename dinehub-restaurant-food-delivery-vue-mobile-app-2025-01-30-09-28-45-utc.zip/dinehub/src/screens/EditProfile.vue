<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :title="'Edit profile'" />

    <!-- MAIN -->
    <main
      :class="'scrollable container'"
      :style="{paddingTop: '10px', paddingBottom: '10px'}"
    >
      <section
        :style="{
          paddingTop: '50px',
          paddingBottom: '30px',
          borderRadius: '10px',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'container'"
      >
        <!-- USER INFO -->
        <div
          :class="'center clickable'"
          :style="{
            width: 'calc(30%)',
            height: 'auto',
            position: 'relative',
            marginBottom: '30px',
          }"
        >
          <img
            alt="User"
            :style="{width: '100%', height: 'auto'}"
            src="https://george-fx.github.io/dinehub_api/assets/users/01.jpg"
          />
          <div
            :style="{
              backgroundColor: '#0C1D2E',
              position: 'absolute',
              zIndex: 999,
              borderRadius: '50%',
              padding: '5px',
              inset: '0',
              opacity: 0.3,
            }"
          />
          <!-- <component
            :is="CameraSvg"
            :style="{
              position: 'absolute',
              zIndex: 1000,
              right: '50%',
              transform: 'translateX(50%) translateY(50%)',
              bottom: '50%',
            }"
          /> -->
        </div>

        <!-- INPUT FIELDS -->
        <components.InputField
          :placeholder="'Enter your name'"
          :inputType="'username'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Enter your email'"
          :inputType="'email'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Enter your phone number'"
          :inputType="'phone'"
          :containerStyle="{marginBottom: '14px'}"
        />
        <components.InputField
          :placeholder="'Enter your location'"
          :inputType="'location'"
          :containerStyle="{marginBottom: '20px'}"
        />

        <!-- BUTTON -->
        <components.Button
          :title="'save changes'"
          :onClick="() => router.go(-1)"
        />
      </section>
    </main>
  </components.Screen>
</template>

<script setup>
import {components} from '../components';
import {composables} from '../composables';

const {router} = composables.useRouter();
</script>
