<template>
  <components.Screen>
    <!-- HEADER -->
    <components.Header :showGoBack="true" :showBasket="true" />

    <!-- MAIN -->
    <div
      :class="'scrollable'"
      v-if="!dishLoading && dish"
      :style="{flex: 1, display: 'flex', flexDirection: 'column'}"
    >
      <!-- DISH IMAGE -->
      <section
        :style="{
          height: '100%',
          width: '100%',
          position: 'relative',
          backgroundColor: 'var(--white-color)',
        }"
        :class="'flex-center'"
      >
        <img :src="dish.image" :style="{width: '70%', height: 'auto'}" />
        <svg.HeartBigSvg
          :dish="dish"
          :containerStyle="{position: 'absolute', top: '25px', right: '23px'}"
        />
        <svg.NewBigSvg
          :style="{
            position: 'absolute',
            top: '21px',
            left: '20px',
          }"
          v-if="dish.isNew"
        />
      </section>

      <!-- DISH DETAILS -->
      <section
        :class="'container'"
        :style="{marginTop: '30px', marginBottom: '20px'}"
      >
        <div :class="'row-c-sb'" :style="{marginBottom: '14px'}">
          <h3>Vegetable salad</h3>
          <span :class="'t16'">{{ dish.kcal }} kcal - {{ dish.weight }}g </span>
        </div>
        <p :class="'t16'">
          {{ dish.description }}
        </p>
      </section>

      <!-- PRICE BLOCK -->
      <section :class="'container'">
        <div
          :style="{
            borderRadius: '10px',
            backgroundColor: 'var(--white-color)',
          }"
          :class="'row-c-sb'"
        >
          <div
            :style="{
              paddingTop: '14px',
              paddingBottom: '14px',
              paddingLeft: '20px',
            }"
          >
            <span
              :style="{
                fontSize: '20px',
                fontWeight: 'var(--fw-bold)',
                fontFamily: 'DM Sans',
              }"
              >${{ dish.price }}</span
            >
          </div>
          <div :class="'row-c'">
            <button
              :style="{padding: '20px'}"
              @click="cartStore.removeFromCart(dish)"
            >
              <svg.DishMinusSvg />
            </button>

            <span :class="'t14'">{{ qty }}</span>
            <button
              :style="{padding: '20px'}"
              @click="cartStore.addToCart(dish)"
            >
              <svg.DishPlusSvg />
            </button>
          </div>
        </div>
      </section>

      <!-- BUTTON -->
      <section
        :class="'container'"
        :style="{paddingBottom: '20px', paddingTop: '10px'}"
      >
        <components.Button
          :title="'+ Add to cart'"
          :onClick="() => cartStore.addToCart(dish)"
        />
      </section>
    </div>

    <!-- LOADING TEXT -->
    <div
      v-if="dishLoading"
      :class="'flex-center'"
      :style="{height: '100%', width: '100%'}"
    >
      <span :class="'t16'">Loading...</span>
    </div>
  </components.Screen>
</template>

<script setup>
import axios from 'axios';

import {URLS} from '../config';
import {ref, onMounted, computed} from 'vue';

import {stores} from '../stores';
import {svg} from '../assets/svg';
import {components} from '../components';
import {composables} from '../composables';

const {router, route} = composables.useRouter();

const dishId = route.params.id;
const dish = ref(null);
const dishLoading = ref(false);

const cartStore = stores.cartStore();
const qty = computed(() => {
  return dish.value ? cartStore.getItemQty(dish.value.id) : 0;
});

const getDishes = async () => {
  dishLoading.value = true;
  try {
    const response = await axios.get(URLS.GET_DISHES);
    const dishes = response.data.dishes;
    const foundDish = dishes.find((dish) => dish.id === parseInt(dishId, 10));
    dish.value = foundDish;
  } catch (error) {
    console.error('error', error);
  } finally {
    dishLoading.value = false;
  }
};

onMounted(() => {
  getDishes();
});
</script>
