import {createMemoryHistory, createRouter} from 'vue-router';

import {screens} from '../screens';
import {appRoutes} from '../routes';

import TabNavigator from '../screens/TabNavigator.vue';

const routes = [
  {
    path: appRoutes.ONBOARDING,
    name: appRoutes.ONBOARDING,
    component: screens.Onboarding,
  },
  {
    path: appRoutes.SIGN_IN,
    name: appRoutes.SIGN_IN,
    component: screens.SignIn,
  },
  {
    path: appRoutes.TAB_NAVIGATOR,
    name: appRoutes.TAB_NAVIGATOR,
    component: TabNavigator,
  },
  {
    path: appRoutes.SEARCH,
    name: appRoutes.SEARCH,
    component: screens.Search,
  },
  {
    path: appRoutes.CHECKOUT,
    name: appRoutes.CHECKOUT,
    component: screens.Checkout,
  },
  {
    path: appRoutes.REVIEWS,
    name: appRoutes.REVIEWS,
    component: screens.Reviews,
  },
  {
    path: appRoutes.FILTER,
    name: appRoutes.FILTER,
    component: screens.Filter,
  },
  {
    path: appRoutes.ORDER_HISTORY_EMPTY,
    name: appRoutes.ORDER_HISTORY_EMPTY,
    component: screens.OrderHistoryEmpty,
  },
  {
    path: appRoutes.ORDER_FAILED,
    name: appRoutes.ORDER_FAILED,
    component: screens.OrderFailed,
  },
  {
    path: appRoutes.ORDER_SUCCESSFUL,
    name: appRoutes.ORDER_SUCCESSFUL,
    component: screens.OrderSuccessful,
  },
  {
    path: appRoutes.SIGN_UP,
    name: appRoutes.SIGN_UP,
    component: screens.SignUp,
  },
  {
    path: appRoutes.LEAVE_A_REVIEW,
    name: appRoutes.LEAVE_A_REVIEW,
    component: screens.LeaveAReview,
  },
  {
    path: appRoutes.PROMOCODES_EMPTY,
    name: appRoutes.PROMOCODES_EMPTY,
    component: screens.PromocodesEmpty,
  },
  {
    path: appRoutes.PROMOCODES,
    name: appRoutes.PROMOCODES,
    component: screens.Promocodes,
  },
  {
    path: appRoutes.TRACK_YOUR_ORDER,
    name: appRoutes.TRACK_YOUR_ORDER,
    component: screens.TrackYourOrder,
  },
  {
    path: appRoutes.ORDER_HISTORY,
    name: appRoutes.ORDER_HISTORY,
    component: screens.OrderHistory,
  },
  {
    path: appRoutes.EDIT_PROFILE,
    name: appRoutes.EDIT_PROFILE,
    component: screens.EditProfile,
  },
  {
    path: appRoutes.FORGOT_PASSWORD,
    name: appRoutes.FORGOT_PASSWORD,
    component: screens.ForgotPassword,
  },
  {
    path: appRoutes.MENU_LIST,
    name: appRoutes.MENU_LIST,
    component: screens.MenuList,
  },
  {
    path: appRoutes.DISH,
    name: appRoutes.DISH,
    component: screens.Dish,
  },
  {
    path: appRoutes.NEW_PASSWORD,
    name: appRoutes.NEW_PASSWORD,
    component: screens.NewPassword,
  },
  {
    path: appRoutes.SIGN_UP_ACCOUNT_CREATED,
    name: appRoutes.SIGN_UP_ACCOUNT_CREATED,
    component: screens.SignUpAccountCreated,
  },
  {
    path: appRoutes.VERIFY_YOUR_PHONE_NUMBER,
    name: appRoutes.VERIFY_YOUR_PHONE_NUMBER,
    component: screens.VerifyYourPhoneNumber,
  },
  {
    path: appRoutes.CONFIRMATION_CODE,
    name: appRoutes.CONFIRMATION_CODE,
    component: screens.ConfirmationCode,
  },
  {
    path: appRoutes.FORGOT_PASSWORD_SENT_EMAIL,
    name: appRoutes.FORGOT_PASSWORD_SENT_EMAIL,
    component: screens.ForgotPasswordSentEmail,
  },
];

const router = createRouter({
  history: createMemoryHistory(),
  routes: routes,
});

export default router;
