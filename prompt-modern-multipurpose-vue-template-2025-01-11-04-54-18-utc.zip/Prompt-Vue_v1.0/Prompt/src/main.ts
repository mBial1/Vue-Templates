import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import { createBootstrap } from 'bootstrap-vue-next';
import AOS from 'aos';

import 'feather-icons';
import 'swiper/swiper-bundle.css';
import 'jarallax/dist/jarallax.esm.js';
import 'jarallax/dist/jarallax.min.js';
import 'glightbox/dist/css/glightbox.min.css';
import 'shufflejs';
import 'bootstrap/dist/css/bootstrap.css';
import 'aos/dist/aos.css';
import 'bootstrap-vue-next/dist/bootstrap-vue-next.css';
import '@/assets/scss/theme.scss';

AOS.init();

const app = createApp(App);
app.use(createBootstrap());
app.use(router);
app.mount('#app');