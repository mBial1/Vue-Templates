const setTitle = (pageName?: string) => {
  return pageName
    ? `${pageName} | Prompt Vue - Multipurpose Bootstrap Template`
    : 'Prompt Vue | Multipurpose Bootstrap Template';
};

const demoRoutes = [
  {
    path: '/',
    redirect: { name: 'home' },
    name: 'index'
  },
  {
    path: '/index',
    name: 'home',
    meta: {
      title: setTitle('Home')
    },
    component: () => import('@/views/home/index.vue')
  },
  {
    path: '/home/app',
    name: 'home.app',
    meta: {
      title: setTitle('Mobile App')
    },
    component: () => import('@/views/landings/mobile-app/index.vue')
  },
  {
    path: '/home/saas',
    name: 'home.saas',
    meta: {
      title: setTitle('Saas Modern')
    },
    component: () => import('@/views/landings/saas-modern/index.vue')
  },
  {
    path: '/home/saas2',
    name: 'home.saas2',
    meta: {
      title: setTitle('Saas Classic')
    },
    component: () => import('@/views/landings/saas-classic/index.vue')
  },
  {
    path: '/home/startup',
    name: 'home.startup',
    meta: {
      title: setTitle('Startup')
    },
    component: () => import('@/views/landings/startup/index.vue')
  },
  {
    path: '/home/software',
    name: 'home.software',
    meta: {
      title: setTitle('Software')
    },
    component: () => import('@/views/landings/software/index.vue')
  },
  {
    path: '/home/agency',
    name: 'home.agency',
    meta: {
      title: setTitle('Agency')
    },
    component: () => import('@/views/landings/agency/index.vue')
  },
  {
    path: '/home/coworking',
    name: 'home.coworking',
    meta: {
      title: setTitle('Co-Working')
    },
    component: () => import('@/views/landings/co-working/index.vue')
  },
  {
    path: '/home/crypto',
    name: 'home.crypto',
    meta: {
      title: setTitle('Crypto')
    },
    component: () => import('@/views/landings/crypto/index.vue')
  },
  {
    path: '/home/marketing',
    name: 'home.marketing',
    meta: {
      title: setTitle('Marketing')
    },
    component: () => import('@/views/landings/marketing/index.vue')
  },
  {
    path: '/home/portfolio',
    name: 'home.portfolio',
    meta: {
      title: setTitle('Portfolio')
    },
    component: () => import('@/views/landings/portfolio/index.vue')
  },
];

const accountRoute = [
  {
    path: '/dashboard',
    name: 'dashboard',
    meta: {
      title: setTitle('Dashboard')
    },
    component: () => import("@/views/pages/auth/dashboard/index.vue"),
  },
  {
    path: '/auth/settings',
    name: 'auth.settings',
    meta: {
      title: setTitle('Settings')
    },
    component: () => import("@/views/pages/auth/settings/index.vue")
  },
  {
    path: '/auth/login',
    name: 'auth.login',
    meta: {
      title: setTitle('Login')
    },
    component: () => import("@/views/pages/auth/login.vue")
  },
  {
    path: '/auth/register',
    name: 'auth.register',
    meta: {
      title: setTitle('Sign Up')
    },
    component: () => import("@/views/pages/auth/register.vue")
  },
  {
    path: '/auth/forget-password',
    name: 'auth.forget-password',
    meta: {
      title: setTitle('Forget Password')
    },
    component: () => import("@/views/pages/auth/forget-password.vue")
  },
  {
    path: '/auth/confirm',
    name: 'auth.confirm',
    meta: {
      title: setTitle('Confirm')
    },
    component: () => import("@/views/pages/auth/confirm.vue")
  }
];

const blogRoutes = [
  {
    path: '/blog',
    name: 'blog',
    meta: {
      title: setTitle('Blog')
    },
    component: () => import("@/views/pages/blog/blog/index.vue")
  },
  {
    path: '/blog-post',
    name: 'blog.post',
    meta: {
      title: setTitle('Blog Post')
    },
    component: () => import("@/views/pages/blog/blog-post/index.vue")
  }
];

const portfolioRoutes = [
  {
    path: '/portfolio/grid',
    name: 'portfolio.grid',
    meta: {
      title: setTitle('Portfolio Grid')
    },
    component: () => import("@/views/pages/portfolio/grid/index.vue")
  },
  {
    path: '/portfolio/masonry',
    name: 'portfolio.masonry',
    meta: {
      title: setTitle('Portfolio Masonry')
    },
    component: () => import("@/views/pages/portfolio/masonry/index.vue")
  },
  {
    path: '/portfolio/item',
    name: 'portfolio.item',
    meta: {
      title: setTitle('Portfolio Item')
    },
    component: () => import("@/views/pages/portfolio/item/index.vue")
  }
];

const pagesRoutes = [
  {
    path: '/company',
    name: 'company',
    meta: {
      title: setTitle('Company')
    },
    component: () => import("@/views/pages/pages/company/index.vue")
  },
  {
    path: '/career',
    name: 'career',
    meta: {
      title: setTitle('Career')
    },
    component: () => import("@/views/pages/pages/career/index.vue")
  },
  {
    path: '/pricing',
    name: 'pricing',
    meta: {
      title: setTitle('Pricing')
    },
    component: () => import("@/views/pages/pages/pricing/index.vue")
  },
  {
    path: '/help-desk',
    name: 'help.desk',
    meta: {
      title: setTitle('Help Desk')
    },
    component: () => import("@/views/pages/pages/help-desk/index.vue")
  },
  {
    path: '/contact',
    name: 'contact',
    meta: {
      title: setTitle('Contact')
    },
    component: () => import("@/views/pages/pages/contact/index.vue")
  }
];

const uiKitRoutes = [
  {
    path: '/ui/colors',
    name: 'ui.color',
    meta: {
      title: setTitle('Colors')
    },
    component: () => import("@/views/ui/colors/index.vue")
  },
  {
    path: '/ui/typography',
    name: 'ui.typography',
    meta: {
      title: setTitle('Typography')
    },
    component: () => import("@/views/ui/typography/index.vue")
  },
  {
    path: '/ui/bootstrap',
    name: 'ui.bootstrap',
    meta: {
      title: setTitle('Components')
    },
    component: () => import("@/views/ui/bootstrap/index.vue")
  },
  {
    path: '/ui/custom',
    name: 'ui.custom',
    meta: {
      title: setTitle('Custom')
    },
    component: () => import("@/views/ui/custom/index.vue")
  },
  {
    path: '/ui/plugins',
    name: 'ui.plugins',
    meta: {
      title: setTitle('Plugins')
    },
    component: () => import("@/views/ui/plugins/index.vue")
  },
];


export const allRoutes = [
  ...demoRoutes,
  ...accountRoute,
  ...blogRoutes,
  ...portfolioRoutes,
  ...pagesRoutes,
  ...uiKitRoutes
];
