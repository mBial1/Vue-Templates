import { createRouter, createWebHistory } from 'vue-router';
import { allRoutes } from '@/router/router';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: allRoutes
});

// Before each route evaluates...
// @ts-ignore
router.beforeEach((to, from, next) => {
  const title = to.meta.title;
  if (title) {
    document.title = title.toString();
  }        
  next();
});

export default router;
