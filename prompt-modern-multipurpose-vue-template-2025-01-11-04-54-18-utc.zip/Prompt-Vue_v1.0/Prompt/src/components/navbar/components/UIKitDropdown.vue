<template>
  <DropDown is="li" custom-class="nav-item">
    <a class="nav-link dropdown-toggle" href="#" id="navbarPages" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      UI Kit
      <i data-feather="chevron-down" class="d-inline-block icon icon-xxs ms-1 mt-lg-0 mt-1"></i>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarPages">
      <ul class="nav">
          <li class="nav-item" v-for="(menu, idx) in UIMenuItems" :key="idx">
            <router-link class="nav-link" :to="{ name: menu.link?.name }" :class="{ active: menu.link?.name === currentRouteName }" aria-labelledby="navbarPages">
              {{ menu.name }}
            </router-link>
          </li>
      </ul>
    </div>
  </DropDown>
</template>
<script setup lang="ts">
import router from '@/router';
import DropDown from '@/components/DropDown.vue';
import { UIMenuItems } from "@/components/navbar/components/data";
const currentRouteName = router.currentRoute.value.name;
</script>