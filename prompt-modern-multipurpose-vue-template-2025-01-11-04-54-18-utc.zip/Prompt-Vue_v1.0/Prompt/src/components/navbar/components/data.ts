import { RouteType } from "@/types";

type ItemType = {
  name?: string,
  link?: RouteType;
  separator?: boolean;
};

type MenuItemType = {
  title?: string,
  items?: ItemType[];
  name?: string,
  link?: RouteType;
  separator?: boolean;
};

export const pagesMenuItems: MenuItemType[] = [
  {
    title: "Account",
    items: [
      {
        name: "Login",
        link: { name: "auth.login" }
      },
      {
        name: "SignUp",
        link: { name: "auth.register" }
      },
      {
        name: "Forget Password",
        link: { name: "auth.forget-password" }
      },
      {
        name: "Confirm Account",
        link: { name: "auth.confirm" }
      },
      {
        separator: true
      },
      {
        name: "Dashboard",
        link: { name: "dashboard" }
      },
      {
        name: "Settings",
        link: { name: "auth.settings" }
      }
    ]
  },
  {
    title: "Blog",
    items: [
      {
        name: "Blog",
        link: { name: "blog" }
      },
      {
        name: "Blog Post",
        link: { name: "blog.post" }
      }
    ]
  },
  {
    separator: true
  },
  {
    name: "Company",
    link: { name: "company" }
  },
  {
    name: "Contact",
    link: { name: "contact" }
  },
  {
    name: "Career",
    link: { name: "career" }
  },
  {
    name: "Pricing",
    link: { name: "pricing" }
  },
  {
    title: "Portfolio",
    items: [
      {
        name: "Portfolio Grid",
        link: { name: "portfolio.grid" }
      },
      {
        name: "Portfolio Masonry",
        link: { name: "portfolio.masonry" }
      },
      {
        name: "Portfolio Item",
        link: { name: "portfolio.item" }
      }
    ]
  },
  {
    separator: true
  },
  {
    name: "Help",
    link: { name: "help.desk" }
  }
];

export const UIMenuItems: MenuItemType[] = [
  {
    name: "Colors",
    link: { name: "ui.color" }
  },
  {
    name: "Typography",
    link: { name: "ui.typography" }
  },
  {
    name: "Components",
    link: { name: "ui.bootstrap" }
  },
  {
    name: "Custom",
    link: { name: "ui.custom" }
  },
  {
    name: "Plugins",
    link: { name: "ui.plugins" }
  }
];