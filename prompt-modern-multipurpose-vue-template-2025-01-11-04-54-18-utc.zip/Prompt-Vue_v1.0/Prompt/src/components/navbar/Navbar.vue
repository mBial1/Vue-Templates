<template>
    <header>
        <nav class="navbar navbar-expand-lg topnav-menu z-10" id="navbar" :class="topbarColor" data-toggle="sticky">
            <b-container>
                <LogoBox />
                <button class="navbar-toggler" type="button" v-b-toggle="'topnav-menu-content'">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <b-collapse class="navbar-collapse" id="topnav-menu-content">
                    <ul class="navbar-nav align-items-lg-center d-flex me-auto" v-if="hideSearch">
                        <li>
                            <form action="#" id="search" class="form-inline d-none d-sm-flex">
                                <div class="form-control-with-hint ms-lg-2 ms-xl-4">
                                    <input type="text" class="form-control" id="search-input"
                                        placeholder="What are you looking for?" />
                                    <span class="form-control-feedback uil uil-search fs-16"></span>
                                </div>
                            </form>
                        </li>
                    </ul>

                    <ul class="navbar-nav align-items-lg-center" :class="classList">
                        <li class="nav-item">
                            <router-link class="nav-link" to="/"
                                :class="{ active: 'home' === currentRouteName }">Home</router-link>
                        </li>
                        <LandingsDropdown />
                        <PagesDropdown />
                        <UIKitDropdown />
                    </ul>

                    <ul class="navbar-nav align-items-lg-center d-flex">
                        <li class="nav-item ms-2">
                            <a class="btn" :class="ctaButtonClass" href="#">Download</a>
                        </li>
                    </ul>
                </b-collapse>
            </b-container>
        </nav>
    </header>
</template>
<script setup lang="ts">
import { onMounted } from "vue";
import feather from 'feather-icons';
import LogoBox from "@/components/LogoBox.vue";
import LandingsDropdown from "@/components/navbar/components/LandingsDropdown.vue";
import PagesDropdown from "@/components/navbar/components/PagesDropdown.vue";
import UIKitDropdown from "@/components/navbar/components/UIKitDropdown.vue";

import router from '@/router';
const currentRouteName = router.currentRoute.value.name;

type PropsType = {
    topbarColor?: string;
    hideSearch?: boolean;
    classList?: string;
    ctaButtonClass?: string;
};

defineProps<PropsType>();

const initStickyNav = () => {
    // Sticky Navbar
    function windowScroll() {
        const navbar = document.getElementById("navbar");
        if (navbar) {
            if (document.body.scrollTop >= 75 || document.documentElement.scrollTop >= 75) {
                navbar.classList.add("navbar-sticky");
            } else {
                navbar.classList.remove("navbar-sticky");
            }
        }
    }

    window.addEventListener("scroll", (ev) => {
        ev.preventDefault();
        windowScroll();
    });
};

const initTopnav = () => {
    const pageUrl = window.location.href.split(/[?#]/)[0];
    const navbarLinks = Array.from(document.querySelectorAll("#navbar .navbar-nav a"));

    navbarLinks.forEach((link) => {
        if (link instanceof HTMLAnchorElement && link.href === pageUrl) {
            link.classList.add("active");

            for (let parentMenu = link.parentElement; parentMenu; parentMenu = parentMenu.parentElement) {
                if (parentMenu.classList.contains("dropdown-menu")) {
                    parentMenu.previousElementSibling?.classList.add("active");
                }
            }
        }
    });
};

onMounted(() => {
    initStickyNav();
    initTopnav();
    feather.replace();
});
</script>