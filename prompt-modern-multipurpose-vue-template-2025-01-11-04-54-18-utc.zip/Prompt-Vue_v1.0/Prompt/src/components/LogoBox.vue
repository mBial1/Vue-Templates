<template>
  <router-link class="navbar-brand logo active" to="/">
    <img :src="logo" height="30" class="align-top logo-dark" alt="">
    <img :src="logoLight" height="30" class="align-top logo-light" alt="">
  </router-link>
</template>
<script setup lang="ts">
import logo from "@/assets/images/logo.png"
import logoLight from "@/assets/images/logo-light.png"
</script>