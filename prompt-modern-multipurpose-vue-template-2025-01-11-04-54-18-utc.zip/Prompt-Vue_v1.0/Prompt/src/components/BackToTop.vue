<template>
  <a class="btn btn-soft-primary shadow-none btn-icon btn-back-to-top" href='#' id="back-to-top" @click="topFunction">
    <i class="icon-xxs" data-feather="arrow-up"></i>
  </a>
</template>
<script setup lang="ts">
import { onMounted } from 'vue';

const topFunction = () => {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
};

const scrollFunction = () => {
  const mybutton = document.getElementById("back-to-top");
  if (mybutton != null) {
    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
      mybutton.classList.add("show");
    } else {
      mybutton.classList.remove("show");
    }
  }
};

onMounted(() => {
  window.onscroll = function () {
    scrollFunction();
  };
});
</script>