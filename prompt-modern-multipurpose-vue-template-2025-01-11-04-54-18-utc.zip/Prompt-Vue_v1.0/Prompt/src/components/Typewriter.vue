<template>
  {{ text }}
</template>

<script setup lang="ts">
import { ref, onMounted, defineProps } from 'vue';

const props = defineProps<{
  dataType: string;
  dataPeriod?: number;
}>();

const text = ref('');
const toRotate = JSON.parse(props.dataType);
let loopNum = 0;
let isDeleting = false;

const tick = () => {
  const i = loopNum % toRotate.length;
  const fullTxt = toRotate[i];

  if (isDeleting) {
    text.value = fullTxt.substring(0, text.value.length - 1);
  } else {
    text.value = fullTxt.substring(0, text.value.length + 1);
  }

  let delta = 200 - Math.random() * 100;
  if (isDeleting) {
    delta /= 2;
  }

  if (!isDeleting && text.value === fullTxt) {
    delta = props.dataPeriod || 2000; // Default to 2000 if not provided
    isDeleting = true;
  } else if (isDeleting && text.value === '') {
    isDeleting = false;
    loopNum++;
    delta = 500;
  }

  setTimeout(tick, delta);
};

onMounted(() => {
  tick();
});
</script>