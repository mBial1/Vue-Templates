import favicon from '@/assets/images/favicon.png'

type CurrencyType = '₹' | '$' | '€'

export const appName: string = 'Prompt'

export const currency: CurrencyType = '$'

export const currentYear = new Date().getFullYear()

export const developedByLink = 'https://coderthemes.com/'

export const developedBy = 'Coderthemes'

export const buyLink = ''

export const supportLink = 'mailto:support@coderthemes.com'

export {favicon}