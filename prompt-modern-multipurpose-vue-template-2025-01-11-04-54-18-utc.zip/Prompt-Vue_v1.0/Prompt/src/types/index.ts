import { RouteParamsRaw } from "vue-router";

export type RouteType = {
  name: string;
  params?: RouteParamsRaw;
  url?: string;
};

export type PriceType = {
  plan: string,
  price: number,
  features: string[],
  animationDuration: number;
  isPopular?: boolean;
};

export type FAQType = {
  ques: string,
  ans: string,
};

export type FeatureType = {
  id: number,
  features: string[];
};

export type PortfolioType = {
  categories?: string[],
  category?: string;
  title: string;
  image: string;
  description: string;
};