<template>
  <section class="section pt-lg-5 pt-3 pb-3 position-relative" data-aos="fade-up">
    <b-container>
      <b-row class="align-items-center">
        <b-col class="text-center">
          <ul class="list-inline list-with-separator">
            <li class="list-inline-item me-0"><a href="#">About</a></li>
            <li class="list-inline-item me-0"><a href="#">Privacy</a></li>
            <li class="list-inline-item me-0"><a href="#">Terms</a></li>
            <li class="list-inline-item me-0"><a href="#">Developers</a></li>
            <li class="list-inline-item me-0"><a href="#">Support</a></li>
            <li class="list-inline-item me-0">
              <a href="#">Careers
                <b-badge :variant="null" pill class="badge-soft-info align-middle fw-normal fs-11 px-2 py-1">We're hiring</b-badge>
              </a>
            </li>
          </ul>
          <p class="mt-2 fs-14">
            {{ currentYear }} © {{ appName }}. All rights reserved. Crafted by <a :href="developedByLink">
              {{ developedBy }}
            </a>
          </p>

          <img src="@/assets/images/logo.png" height="30" class="mt-2 mb-4" alt="" />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { currentYear, appName, developedBy, developedByLink } from "@/helpers/constants";
</script>