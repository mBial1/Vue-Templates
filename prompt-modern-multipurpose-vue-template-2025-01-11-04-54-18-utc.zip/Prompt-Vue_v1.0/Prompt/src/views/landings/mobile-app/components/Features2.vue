<template>
  <section class="section py-5 features-2 position-relative overflow-hidden">
    <b-container>
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">More Features</b-badge>

          <h1 class="fw-semibold">Features that showcase your app</h1>
          <p class="text-muted mx-auto">
            Start working with <span class="text-primary fw-bold">{{appName}}</span> to showcase your app to thousands of
            people.
          </p>
        </b-col>
      </b-row>
      <b-row class="my-5">
        <b-col lg="4" v-for="(item, idx) in features" :key="idx">
          <b-card no-body class="bg-gray-50 shadow-none shapes" data-aos="fade-up"
            :data-aos-duration="item.animationDuration">
            <div v-for="(shape, idx) in item.shapes" :key="idx" :class="shape"></div>
            <b-card-body class="text-center py-0">
              <h3 class="fw-semibold mt-0">{{ item.title }}</h3>
              <p class="fs-14">
                {{ item.description }}
              </p>
              <div class="px-2 mt-3">
                <img :src="item.image" alt="" class="img-fluid mt-2" />
              </div>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import { features } from "@/views/landings/mobile-app/components/data";
</script>