import type { FeatureType } from "@/views/landings/mobile-app/components/types";

import app3 from "@/assets/images/features/app3.png";
import app4 from "@/assets/images/features/app4.png";

export const features: FeatureType[] = [
  {
    title: "Quick Access to Tasks",
    description: "Save time and edit like a pro! Yes! you will be able to edit your application in an easy way.",
    image: app3,
    shapes: ["shape1", "shape2"],
    animationDuration: 100
  },
  {
    title: "Create Task Easily",
    description: "Speedy App provides instant information on thousands of hire and buy products.",
    image: app4,
    shapes: ["shape3", "shape4"],
    animationDuration: 300
  },
  {
    title: "Quick Access to Team",
    description: "Save time and edit like a pro! Yes! you will be able to edit your application in an easy way.",
    image: app4,
    shapes: ["shape5", "shape6"],
    animationDuration: 500
  }
];