<template>
  <section class="section pb-0 py-4 pt-sm-6 position-relative" id="section-download" data-aos="fade-up">
    <b-container class="text-center">
      <b-row class="align-items-center">
        <b-col>
          <h1 class="fw-medium">Start offering your users a better experience</h1>
          <p class="text-muted mx-auto">
            Start working with <span class="text-primary fw-bold">{{appName}}</span> to showcase your app to thousands of
            people.
          </p>

          <div class="text-center mt-5">
            <a href="" class="d-block d-sm-inline-flex">
              <img :src="google" alt="google play" height="52" />
            </a>{{ ' ' }}
            <a href="" class="d-block d-sm-inline-flex mt-2 mt-sm-0 ms-0 ms-sm-2">
              <img :src="store" alt="apple store" height="52" />
            </a>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import google from "@/assets/images/buttons/google.png"
import store from "@/assets/images/buttons/store.png"
import { appName } from "@/helpers";
</script>