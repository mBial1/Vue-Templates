export type FeatureType = {
  title: string,
  description: string,
  image: string,
  shapes: string[],
  animationDuration: number;
};