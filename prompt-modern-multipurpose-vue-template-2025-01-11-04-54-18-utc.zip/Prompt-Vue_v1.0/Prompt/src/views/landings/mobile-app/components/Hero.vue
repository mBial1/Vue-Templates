<template>
  <section class="position-relative hero-1 pt-7 pt-sm-6 pb-5">
    <b-container class="hero-container">
      <b-row class="text-center text-md-start">
        <b-col lg="6" class="pt-2 pt-sm-3">
          <h1 class="hero-title">
            The best way to <span class="highlight highlight-warning d-inline-block">Showcase</span> your Mobile App
          </h1>

          <p class="mt-3 fs-17 text-muted">
            To increase sales by skyrocketing communication with All messages in one simple dashboard it now takes
            seconds.
          </p>

          <div class="pt-3 pt-sm-5 d-flex align-items-center action-buttons">
            <a href='#section-download' class="btn btn-primary" data-bs-toggle="smooth-scroll">Download</a>

            <div class="ms-3">
              <a class="text-primary d-flex align-items-center" href="#">
                <span type="button" class="btn btn-soft-primary btn-rounded-circle btn-icon me-2 shadow-none">
                  <i class="icon-xxs icon-dual-primary align-self-center" data-feather="play"></i>
                </span>
                <span class="fw-semibold">Watch Video</span>
              </a>
            </div>
          </div>
        </b-col>
        <b-col lg="4" class="offset-lg-2 text-end">
          <div class="position-relative">
            <div class="hero-img mt-4 mt-sm-0">
              <img :src="app1" alt="" class="img-fluid" data-bs-aos="zoom-in-up" />
            </div>

            <div class="slider">
              <Swiper class="swiper-container" data-toggle="swiper" :modules="[Autoplay]" :slidesPerView="1"
                :loop="true" :spaceBetween="0" :autoplay="{ delay: 5000 }"
                :breakpoints="{ 576: { slidesPerView: 1.2 }, 768: { slidesPerView: 1 } }" :roundLengths="true">
                <SwiperSlide>
                  <div class="swiper-slide-content shadow bg-white rounded-sm p-3 quote">
                    <div class="d-flex text-align-start">
                      <img :src="avatar6" alt=""
                        class="img-fluid avatar-sm rounded-circle align-self-center me-3">
                      <div class="flex-grow-1 fs-14 text-muted">This app is blessing for all professionals!
                        <p class="mb-0">
                          <span class="ms-0 hstack gap-1">
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="swiper-slide-content shadow bg-white rounded-sm p-3 quote">
                    <div class="d-flex">
                      <img :src="avatar8" alt=""
                        class="img-fluid avatar-sm rounded-circle align-self-center me-3">
                      <div class="flex-grow-1 fs-14 text-muted">Very convenient to use project manager!
                        <p class="mb-0">
                          <span class="ms-0 hstack gap-1">
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                            <i data-feather="star" class="icon icon-xxs icon-fill-warning text-warning"></i>
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              </Swiper>
            </div>

          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';

import app1 from "@/assets/images/hero/app1.png"
import avatar6 from "@/assets/images/avatars/img-6.jpg"
import avatar8 from "@/assets/images/avatars/img-8.jpg"
</script>