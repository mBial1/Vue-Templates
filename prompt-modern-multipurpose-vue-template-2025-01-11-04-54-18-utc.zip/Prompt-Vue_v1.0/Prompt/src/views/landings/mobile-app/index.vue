<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto navbar-light" ctaButtonClass="btn-orange btn-sm" />
  <Hero />
  <Features />
  <Features2 />
  <Testimonials />
  <CTA />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/landings/mobile-app/components/Hero.vue";
import Features from "@/views/landings/mobile-app/components/Features.vue";
import Features2 from "@/views/landings/mobile-app/components/Features2.vue";
import Testimonials from "@/views/landings/mobile-app/components/Testimonials.vue";
import CTA from "@/views/landings/mobile-app/components/CTA.vue";
import Footer from "@/views/landings/mobile-app/components/Footer.vue";
</script>