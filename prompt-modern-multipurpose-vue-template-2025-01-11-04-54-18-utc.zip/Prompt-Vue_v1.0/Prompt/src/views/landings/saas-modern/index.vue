<template>
  <Hero />
  <Features />
  <Clients />
  <Testimonials />
  <Pricing />
  <FAQs />
  <Footer />
</template>
<script setup lang="ts">

import Hero from '@/views/landings/saas-modern/components/Hero.vue';
import Features from '@/views/landings/saas-modern/components/Features.vue';
import Clients from '@/views/landings/saas-modern/components/Clients.vue';
import Testimonials from '@/views/landings/saas-modern/components/Testimonials.vue';
import Pricing from '@/views/landings/saas-modern/components/Pricing.vue';
import FAQs from '@/views/landings/saas-modern/components/FAQs.vue';
import Footer from '@/views/landings/saas-modern/components/Footer.vue';
</script>