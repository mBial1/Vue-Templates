<template>
  <Hero />
  <Services />
  <Portfolio />
  <Clients />
  <Blog />
  <Openings />
  <Footer />
</template>
<script setup lang="ts">
import Hero from '@/views/landings/agency/components/Hero.vue';
import Services from '@/views/landings/agency/components/Services.vue';
import Portfolio from '@/views/landings/agency/components/Portfolio.vue';
import Clients from '@/views/landings/agency/components/Clients.vue';
import Blog from '@/views/landings/agency/components/Blog.vue';
import Openings from '@/views/landings/agency/components/Openings.vue';
import Footer from '@/views/landings/agency/components/Footer.vue';
</script>