export type OpeningType = {
  title: string;
  location: string;
  animationDuration: number;
};

type WorkType = {
  title: string,
  description: string,
  image: string,
};

export type PortfolioType = {
  id: number,
  work: WorkType[]
};