<template>
  <section class="section py-5 position-relative">
    <b-container>
      <b-row class="justify-content-center">
        <b-col lg="6">
          <div class="text-center">
            <h1 class="fw-semibold">We're Hiring</h1>
            <p class="mt-0 mb-4">We're a team of lifelong learners. We're equal parts left and right brained.</p>
            <a href="#" class="btn btn-secondary mb-2">Learn about our culture</a>
          </div>
        </b-col>
      </b-row>

      <b-row class="justify-content-center my-5">
        <b-col lg="8">
          <a href="javascript:void(0)" class="text-dark d-block" v-for="(item, idx) in openings" :key="idx">
            <b-card no-body class="border rounded mb-3" data-aos="fade-up" :data-aos-duration="item.animationDuration">
              <b-card-body class="p-3">
                <b-row class="align-items-center">
                  <b-col md="6">
                    <h5 class="my-0 fw-semibold">{{item.title}}</h5>
                  </b-col>
                  <b-col md="4" class="offset-md-1">
                    <p class="text-muted mb-0">{{item.location}}</p>
                  </b-col>
                  <b-col md="1" class="text-md-end mt-3 mt-md-0">
                    <i class="icon-xs" data-feather="chevron-right"></i>
                  </b-col>
                </b-row>
              </b-card-body>
            </b-card>
          </a>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { openings } from "@/views/landings/agency/components/data";
</script>