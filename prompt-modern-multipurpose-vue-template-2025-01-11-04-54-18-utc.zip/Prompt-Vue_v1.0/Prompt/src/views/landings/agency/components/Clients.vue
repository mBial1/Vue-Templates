<template>
  <section class="section py-4 py-sm-8 bg-soft-orange position-relative">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row class="py-4">
        <b-col lg="11">
          <b-row>
            <b-col lg="12">
              <b-badge :variant="null" pill class="badge-soft-orange  px-2 py-1 mb-2">Our Customers</b-badge>

            </b-col>
            <b-col lg="6">
              <h1 class="fw-semibold mb-1">We are working with fortune top 500 companies</h1>
            </b-col>
            <b-col lg="6" class="ps-6">
              <p class="mt-2 text-secondary">With our powerful set of elements, you can make beautiful and customized
                WordPress websites. Incredible amount of design combinations are possible by Drag & Drop, allowing you
                to be creative without having any design experience.</p>
            </b-col>
          </b-row>
          <b-row class="mt-5">
            <b-col v-for="(logo, idx) in companies" :key="idx">
              <img :src="logo" alt="" class="mb-2 mb-xl-0" height="32" />
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-container>
    <div class="divider bottom d-none d-sm-block"></div>
  </section>
</template>
<script setup lang="ts">
import { companies } from "@/views/landings/agency/components/data";
</script>