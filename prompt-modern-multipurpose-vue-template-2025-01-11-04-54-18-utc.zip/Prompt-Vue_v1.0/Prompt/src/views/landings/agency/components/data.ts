import type { OpeningType, PortfolioType } from "@/views/landings/agency/components/types";

import amazon from "@/assets/images/brands/amazon.svg";
import google from "@/assets/images/brands/google.svg";
import paypal from "@/assets/images/brands/paypal.svg";
import spotify from "@/assets/images/brands/spotify.svg";
import shopify from "@/assets/images/brands/shopify.svg";

import agency1 from "@/assets/images/features/agency1.jpg";
import agency2 from "@/assets/images/features/agency2.jpg";

export const companies: string[] = [amazon, google, paypal, spotify, shopify];

export const openings: OpeningType[] = [
  {
    title: "Front-End Developer",
    location: "Los Angeles / Remote",
    animationDuration: 500
  },
  {
    title: "Community Manager",
    location: "New York / Full-Time",
    animationDuration: 700
  },
  {
    title: "UX/UI Designer",
    location: "New York / Full-Time",
    animationDuration: 900
  }
];

export const portfolio: PortfolioType[] = [
  {
    id: 1,
    work: [
      {
        title: "Project",
        description: "Branding, Interaction, Web Design",
        image: agency1,
      },
      {
        title: "Project 2",
        description: "Branding, Web Design & Development",
        image: agency2,
      }
    ]
  },
  {
    id: 2,
    work: [
      {
        title: "Project 3",
        description: "Branding, Interaction, Web Design",
        image: agency2,
      },
      {
        title: "Project 4",
        description: "Branding, Web Design & Development",
        image: agency1,
      }
    ]
  }
];