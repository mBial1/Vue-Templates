<template>
  <section class="section py-lg-5 py-4 mb-5 mb-sm-0 position-relative">
    <b-container>
      <b-row class="justify-content-center">
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-success px-2 py-1">Latest</b-badge>

          <h1 class="fw-semibold">Featured Work</h1>
          <p class="text-muted">Explore some of our latest website projects</p>
        </b-col>
      </b-row>

      <b-row class="features-6" data-aos="fade-up" data-aos-duration="600" v-for="(item, idx) in portfolio"
        :key="idx">
        <b-col lg="6" v-for="(feat, idx) in item.work" :key="idx">
          <div class="bg-gray-50 ps-5 pt-5 mt-4 mt-sm-5 rounded feature-item">
            <b-row class="align-items-center">
              <div class="col-auto">
                <h3 class="text-dark my-0">{{ feat.title }}</h3>
              </div>
              <b-col class="text-end pe-5">
                {{ feat.description }}
              </b-col>
            </b-row>
            <b-row class="mt-4">
              <b-col>
                <img :src="feat.image" alt="" class="img-fluid shadow rounded" />
              </b-col>
            </b-row>
            <div class="overlay">
              <a href="#" class="btn btn-secondary btn-sm btn-view shadow-lg">
                View Project <i class="icon-xs ms-2" data-feather="arrow-right"></i>
              </a>
            </div>
          </div>
        </b-col>
      </b-row>

      <b-row class="mt-6 justify-content-center">
        <div class="col-auto">
          <a href="#" class="btn btn-outline-secondary mb-2">
            Explore All Work<i class="icon-xxs ms-2" data-feather="arrow-right"></i>
          </a>
        </div>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { portfolio } from "@/views/landings/agency/components/data";
</script>