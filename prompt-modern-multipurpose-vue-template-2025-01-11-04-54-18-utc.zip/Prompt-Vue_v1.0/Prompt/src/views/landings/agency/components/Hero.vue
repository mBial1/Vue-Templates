<template>
  <div class="header-4">
    <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />

    <div class="position-relative hero-5 pb-4 pt-7 pb-sm-0 hero-with-shapes">
      <div class="shape1"></div>
      <div class="shape2"></div>
      <div class="shape3"></div>

      <b-container class="position-relative zindex-1">
        <b-row class="align-items-center">
          <b-col lg="12">
            <div class="rounded d-inline-block mb-4 px-3 py-2 alert bg-soft-warning" data-aos="fade-right"
              data-aos-duration="1000">
              <a href="#">
                <div class="d-flex align-items-center">
                  <div class="badge rounded-pill bg-orange px-2 py-1">New!</div>
                  <div class="mx-3">Check our latest article on design</div>
                </div>
              </a>
            </div>

            <h1 class="hero-title fw-medium">
              We design user experiences that <span class="highlight highlight-warning d-inline-block">works</span>
            </h1>

            <p class="mt-4 fs-18 mb-3 mb-sm-6 w-75">
              We're a top-notch web design and development team helping business to craft the meaningful and interactive
              product experiences.
            </p>

            <a href="#" class="btn btn-secondary">
              <i class="icon-xxs me-2" data-feather="arrow-down"></i> View Our Work
            </a>{{ ' ' }}
            <a href="#" class="btn btn-outline-secondary ms-2">
              Learn More
            </a>
          </b-col>
        </b-row>
      </b-container>

      <div class="align-items-end links-social d-sm-block d-none">
        <ul class="list-inline text-muted text-uppercase fw-medium">
          <li class="list-inline-item py-2">
            <a href="">Twitter</a>
          </li>
          <li class="list-inline-item py-2">
            <a href="">Facebook</a>
          </li>
          <li class="list-inline-item py-2">
            <a href="">Instagram</a>
          </li>
        </ul>
      </div>

      <div class="shape bottom">
        <svg width="1440px" height="40px" viewBox="0 0 1440 40" version="1.1" xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="shape-b" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="curve" fill="#fff">
              <path
                d="M0,30.013 C239.659,10.004 479.143,0 718.453,0 C957.763,0 1198.28,10.004 1440,30.013 L1440,40 L0,40 L0,30.013 Z"
                id="Path"></path>
            </g>
          </g>
        </svg>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
</script>