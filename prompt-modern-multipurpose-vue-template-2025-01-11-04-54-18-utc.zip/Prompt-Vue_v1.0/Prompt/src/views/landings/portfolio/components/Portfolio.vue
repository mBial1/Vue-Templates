<template>
  <section class="py-lg-5 pb-5 pt-2 position-relative">
    <b-container>
      <b-row class="justify-content-center">
        <b-col class="text-start">
          <h1 class="fw-medium">Latest Projects</h1>
        </b-col>

        <div class="col-auto">
          <ul class="nav nav-pills pe-0 me-0 aling-items-center" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
              <a class="nav-link rounded-pill active" id="pills-design-tab" data-bs-toggle="pill" href="#pills-design"
                role="tab" aria-selected="true">UI/UX Design</a>
            </li>
            <li class="nav-item" role="presentation">
              <a class="nav-link rounded-pill" id="pills-branding-tab" data-bs-toggle="pill" href="#pills-design"
                role="tab" aria-selected="false">Branding</a>
            </li>
            <li class="nav-item" role="presentation">
              <a class="nav-link rounded-pill" id="pills-marketing-tab" data-bs-toggle="pill" href="#pills-design"
                role="tab" aria-selected="false">Marketing</a>
            </li>
            <li class="nav-item" role="presentation">
              <a class="nav-link rounded-pill" id="pills-web-tab" data-bs-toggle="pill" href="#pills-design" role="tab"
                aria-selected="false">Web Development</a>
            </li>
          </ul>
        </div>
      </b-row>

      <b-row class="mt-3">
        <b-col lg="12">
          <div class="tab-content mt-2" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-design" role="tabpanel" aria-labelledby="pills-design-tab">
              <b-row class="features-6" data-aos="fade-up" data-aos-duration="600" v-for="(item, idx) in portfolio"
                :key="idx">
                <b-col lg="6" v-for="(feat, idx) in item.work" :key="idx">
                  <div class="bg-gray-50 ps-5 pt-5 mt-4 mt-sm-5 rounded feature-item">
                    <b-row class="align-items-center">
                      <div class="col-auto">
                        <h3 class="text-dark my-0">{{ feat.title }}</h3>
                      </div>
                      <b-col class="text-end pe-5">
                        {{ feat.description }}
                      </b-col>
                    </b-row>
                    <b-row class="mt-4">
                      <b-col>
                        <img :src="feat.image" alt="" class="img-fluid shadow rounded" />
                      </b-col>
                    </b-row>
                    <div class="overlay">
                      <a href="#" class="btn btn-secondary btn-sm btn-view shadow-lg">
                        View Project <i class="icon-xs ms-2" data-feather="arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </b-col>
              </b-row>
            </div>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { portfolio } from "@/views/landings/portfolio/components/data";
</script>