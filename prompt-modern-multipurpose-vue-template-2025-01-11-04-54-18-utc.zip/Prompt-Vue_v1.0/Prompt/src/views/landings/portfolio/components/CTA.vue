<template>
    <section class="section pt-lg-8 pb-lg-4 pt-4 pb-3 position-relative" id="contact-me-form">
        <b-container class="testimonials-3">
            <b-row class="align-items-center">
                <b-col lg="6" data-aos="fade-up" data-aos-duration="600">
                    <h1 class="fw-medium">Just say hi.</h1>
                    <p>
                        I am open to discuss your next project, improve user experience of an existing one or help with
                        your UX/UI design challenges.
                    </p>

                    <div class="mt-5 text-muted">Email me at</div>
                    <div>
                        <h4 class="mt-0 fw-medium">
                            <a href="mailto:support@coderthemes.com" class="">hello@coderthemes.com</a>
                        </h4>
                    </div>

                    <div class="mt-5 text-muted">Social</div>
                    <ul class="list-inline mt-1">
                        <li class="list-inline-item me-3">
                            <a href="#" class=""><i class="icon-sm icon-dual" data-feather="dribbble"></i></a>
                        </li>
                        <li class="list-inline-item me-3">
                            <a href="#" class=""><i class="icon-sm icon-dual" data-feather="facebook"></i></a>
                        </li>
                        <li class="list-inline-item me-3">
                            <a href="#" class=""><i class="icon-sm icon-dual" data-feather="twitter"></i></a>
                        </li>
                        <li class="list-inline-item me-3">
                            <a href="#" class=""><i class="icon-sm icon-dual" data-feather="linkedin"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class=""><i class="icon-sm icon-dual" data-feather="instagram"></i></a>
                        </li>
                    </ul>
                </b-col>

                <b-col lg="6" data-aos="fade-up" data-aos-duration="900">
                    <form name="ajax-form" id="ajax-form"
                        action="https://formsubmit.io/send/9f03c2e4-7d62-4365-8862-117ed9936724" method="post"
                        class="form-main mt-5 mt-lg-0">

                        <b-row>
                            <b-col cols="12" class="mb-3">
                                <input class="form-control" id="name2" name="name" placeholder="Your name" type="text"
                                    value="">
                                <div class="error visually-hidden" id="err-name">Please enter name</div>
                            </b-col>

                            <b-col cols="12" class="mb-3">
                                <input class="form-control" id="email2" name="email" type="text"
                                    placeholder="Your email where we can reach" value="">
                                <div class="error visually-hidden" id="err-emailvld">E-mail is not a valid format
                                </div>
                            </b-col>

                            <b-col cols="12" class="mb-3">
                                <input class="form-control" id="subject1" name="subject" placeholder="Subject"
                                    type="text" value="">
                            </b-col>
                        </b-row>

                        <b-row>
                            <b-col cols="12" class="mb-3">
                                <b-form-textarea type="textarea" rows="5" id="message2" placeholder="Write your message here. Keep it simple, concise and intriguing!" />
                                <div class="error visually-hidden" id="err-message">Please enter message</div>
                            </b-col>
                        </b-row>

                        <b-row>
                            <b-col class="text-end">
                                <b-button type="submit" variant="danger" id="send">Submit</b-button>
                            </b-col>
                        </b-row>
                    </form>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
</script>