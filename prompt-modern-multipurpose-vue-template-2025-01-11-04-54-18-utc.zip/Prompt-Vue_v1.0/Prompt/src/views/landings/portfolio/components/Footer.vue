<template>
    <section class="section pt-4 pb-3 position-relative">
        <b-container>
            <b-row class="align-items-center border-top border-light pt-4">
                <b-col class="text-center">
                    <ul class="list-inline list-with-separator">
                        <li class="list-inline-item me-0"><a href="#">About</a></li>
                        <li class="list-inline-item me-0"><a href="#">Services</a></li>
                        <li class="list-inline-item me-0"><a href="#">Contact</a></li>
                    </ul>
                    <p class="mt-2">
                        {{ currentYear }} © {{ appName }}. All rights reserved. Crafted by <a :href="developedByLink">{{
                            developedBy }}</a>
                    </p>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
import { currentYear, appName, developedBy, developedByLink } from "@/helpers/constants";
</script>