type WorkType = {
  title: string,
  description: string,
  image: string,
};

export type PortfolioType = {
  id: number,
  work: WorkType[]
};