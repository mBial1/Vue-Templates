import { PortfolioType } from "@/views/landings/portfolio/components/types";

import agency1 from "@/assets/images/features/agency1.jpg";
import agency2 from "@/assets/images/features/agency2.jpg";

export const portfolio: PortfolioType[] = [
  {
    id: 1,
    work: [
      {
        title: "Project",
        description: "Branding, Interaction, Web Design",
        image: agency1,
      },
      {
        title: "Project 2",
        description: "Branding, Web Design & Development",
        image: agency2,
      }
    ]
  },
  {
    id: 2,
    work: [
      {
        title: "Project 3",
        description: "Branding, Interaction, Web Design",
        image: agency2,
      },
      {
        title: "Project 4",
        description: "Branding, Web Design & Development",
        image: agency1,
      }
    ]
  }
];