<template>
  <Hero />
  <Services />
  <Portfolio />
  <Testimonials />
  <CTA />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/landings/portfolio/components/Hero.vue";
import Services from "@/views/landings/portfolio/components/Services.vue";
import Portfolio from "@/views/landings/portfolio/components/Portfolio.vue";
import Testimonials from "@/views/landings/portfolio/components/Testimonials.vue";
import CTA from "@/views/landings/portfolio/components/CTA.vue";
import Footer from "@/views/landings/portfolio/components/Footer.vue";
</script>