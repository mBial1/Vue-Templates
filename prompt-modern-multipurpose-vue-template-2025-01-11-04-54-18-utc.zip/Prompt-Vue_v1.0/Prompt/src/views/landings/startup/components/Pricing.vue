<template>
    <section class="my-5 py-5 position-relative">
        <b-container data-aos="fade-up" data-aos-duration="1500">
            <b-row>
                <b-col class="text-center">
                    <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Pricing</b-badge>

                    <h1 class="fw-medium">Pricing Plans</h1>
                    <p class="text-muted mx-auto">
                        Pricing that <span class="text-primary fw-bold">works</span> for everyone.
                    </p>
                </b-col>
            </b-row>

            <b-row class="mt-5 align-items-center justify-content-center">
                <b-col lg="12">
                    <b-table-simple responsive class="table-responsive-lg w-lg-75 mx-lg-auto">
                        <b-thead class="text-center">
                            <tr class="border-top">
                                <th scope="col" class="w-50"></th>
                                <th scope="col">
                                    <span class="text-dark">Starter</span>
                                    <small class="d-block text-body fw-normal">{{ currency }}40/mo</small>
                                </th>
                                <th scope="col" class="border-start border-end">
                                    <span class="text-dark">Professional</span>
                                    <span class="badge bg-orange rounded-pill ms-1">Popular</span>
                                    <small class="d-block text-body fw-normal">{{ currency }}60/mo</small>
                                </th>
                                <th scope="col" class="">
                                    <span class="text-dark">Enterprise</span>
                                    <small class="d-block text-body fw-normal">{{ currency }}300/mo</small>
                                </th>
                            </tr>
                        </b-thead>
                        <b-tbody>
                            <b-tr class="border-top">
                                <b-td>Landing pages</b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Drag-and-drop editor</b-td>
                                <b-td></b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Email marketing</b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Ad retargeting</b-td>
                                <b-td class="text-center">
                                    <span class="badge bg-info rounded-pill">Add-on Available</span>
                                </b-td>
                                <b-td class="text-center border-start border-end"></b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Messenger integration</b-td>
                                <b-td class="text-center"></b-td>
                                <b-td class="text-center border-start border-end"></b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Live chat</b-td>
                                <b-td class="text-center"></b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="badge bg-info rounded-pill">Add-on Available</span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>Conversational bots</b-td>
                                <b-td class="text-center"></b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                            <b-tr class="border-top">
                                <b-td>SEO recommendations & optimizations</b-td>
                                <b-td class="text-center"></b-td>
                                <b-td class="text-center border-start border-end">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                                <b-td class="text-center">
                                    <span class="icon icon-xs text-success">
                                        <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1"
                                            xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <title>Stockholm-icons / Navigation / Check</title>
                                            <desc>Created with Sketch.</desc>
                                            <g id="Stockholm-icons-/-Navigation-/-Check" stroke="none" stroke-width="1"
                                                fill="none" fill-rule="evenodd">
                                                <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                                                <path
                                                    d="M6.26193932,17.6476484 C5.90425297,18.0684559 5.27315905,18.1196257 4.85235158,17.7619393 C4.43154411,17.404253 4.38037434,16.773159 4.73806068,16.3523516 L13.2380607,6.35235158 C13.6013618,5.92493855 14.2451015,5.87991302 14.6643638,6.25259068 L19.1643638,10.2525907 C19.5771466,10.6195087 19.6143273,11.2515811 19.2474093,11.6643638 C18.8804913,12.0771466 18.2484189,12.1143273 17.8356362,11.7474093 L14.0997854,8.42665306 L6.26193932,17.6476484 Z"
                                                    id="Path-94" fill="#335EEA"
                                                    transform="translate(11.999995, 12.000002) rotate(-180.000000) translate(-11.999995, -12.000002) ">
                                                </path>
                                            </g>
                                        </svg>
                                    </span>
                                </b-td>
                            </b-tr>
                        </b-tbody>
                    </b-table-simple>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
import { currency } from '@/helpers';
</script>