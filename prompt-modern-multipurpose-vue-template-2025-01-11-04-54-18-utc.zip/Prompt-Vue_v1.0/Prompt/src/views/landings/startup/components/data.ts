import { IntegrationType } from "@/views/landings/startup/components/types";

import slack from "@/assets/images/brands/slack.png";
import fb from "@/assets/images/brands/fb.png";
import salesforce from "@/assets/images/brands/salesforce.jpg";
import at from "@/assets/images/brands/at.png";
import gsheet from "@/assets/images/brands/gsheet.png";
import ac from "@/assets/images/brands/ac.jpeg";

import amazon from "@/assets/images/brands/amazon.svg";
import google from "@/assets/images/brands/google.svg";
import paypal from "@/assets/images/brands/paypal.svg";
import spotify from "@/assets/images/brands/spotify.svg";
import shopify from "@/assets/images/brands/shopify.svg";

export const integrations: IntegrationType[] = [
  {
    id: 1,
    tools: [
      {
        name: "Slack",
        image: slack,
        description: "Slack is a platform for team communication: everything in one place, instantly searchable, available wherever you go."
      },
      {
        name: "Facebook Lead Ads",
        image: fb,
        description: "Facebook lead ads make signing up for business information easy for people and more valuable for businesses."
      }
    ]
  },
  {
    id: 2,
    tools: [
      {
        name: "Salesforce",
        image: salesforce,
        description: "Salesforce is a leading enterprise customer relationship manager (CRM) application."
      },
      {
        name: "Airtable",
        image: at,
        description: "Organize anything with Airtable, a modern database created for everyone."
      },
    ]
  },
  {
    id: 3,
    tools: [
      {
        name: "Google Sheets",
        image: gsheet,
        description: "Create, edit, and share spreadsheets with Google Sheets, and get automated insights from data."
      },
      {
        name: "ActiveCampaign",
        image: ac,
        description: "ActiveCampaign combines all aspects of email marketing into a single and easy-to-use platform."
      }
    ]
  }
];

export const companies: string[] = [amazon, google, paypal, spotify, shopify];