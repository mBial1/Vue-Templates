
type ToolType = {
  name: string;
  image: string;
  description: string;
};


export type IntegrationType = {
  id: number,
  tools: ToolType[];
};