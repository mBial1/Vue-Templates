<template>
  <section class="py-5">
    <b-container data-aos="fade-up" data-aos-duration="1000">
      <b-row>
        <b-col lg="12" class="text-center">
          <h4 class="fw-medium pb-3 mt-0">Join 10,000+ companies who trust {{appName}}.</h4>
          <ul class="list-inline my-3">
            <li class="list-inline-item" v-for="(logo, idx) in companies"
              :class="!(idx === companies.length - 1) && 'me-4 me-lg-5'" :key="idx">
              <img :src="logo" alt="" class="mb-2 mb-xl-0" height="36" />
            </li>
          </ul>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import { companies } from "@/views/landings/startup/components/data";
</script>