<template>
  <section class="my-5 py-6 bg-gradient2 position-relative">
    <b-container data-aos="fade-up" data-aos-duration="1500">
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Integrations</b-badge>

          <h1 class="fw-medium">Sync your data anywhere</h1>
          <p class="text-muted mx-auto">
            Sync your campaigns or other marketing data <span class="text-primary fw-bold">anywhere</span>.
          </p>
        </b-col>
      </b-row>

      <b-row v-for="(item, idx) in integrations" :class="!idx && 'mt-5'" :key="idx">
        <b-col lg="6" v-for="(tool, idx) in item.tools" :key="idx">
          <b-card no-body>
            <b-card-body>
              <div class="d-flex text-align-start">
                <img class="me-4 align-self-center flex-shrink-0" :src="tool.image" alt="" height="60" />
                <div class="flex-grow-1">
                  <h5 class="mt-0">{{ tool.name }}</h5>
                  <p class="mb-0">
                    {{ tool.description }}
                  </p>
                </div>
              </div>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { integrations } from "@/views/landings/startup/components/data";
</script>