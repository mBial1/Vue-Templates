<template>
  <Hero />
  <Clients />
  <Features />
  <Integrations />
  <Pricing />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/landings/startup/components/Hero.vue";
import Clients from "@/views/landings/startup/components/Clients.vue";
import Features from "@/views/landings/startup/components/Features.vue";
import Integrations from "@/views/landings/startup/components/Integrations.vue";
import Pricing from "@/views/landings/startup/components/Pricing.vue";
import Footer from "@/views/landings/startup/components/Footer.vue";
</script>