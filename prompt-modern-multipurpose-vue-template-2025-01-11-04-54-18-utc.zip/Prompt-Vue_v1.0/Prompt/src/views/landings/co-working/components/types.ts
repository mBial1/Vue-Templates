export type OptionType = {
  title: string,
  description: string,
  image: string,
  capacity: string,
  animationDuration: number,
};

export type CounterType = {
  label: string;
  startAmount: number;
  endAmount: number;
  duration: number;
  suffix?: string;
};