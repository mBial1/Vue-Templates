<template>
  <section class="py-5 py-sm-6 bg-gradient5">
    <b-container>
      <b-row>
        <b-col lg="4">
          <a class="navbar-brand me-lg-4 me-auto pt-0" href="#">
            <img src="@/assets/images/logo.png" height="30" class="d-inline-block align-top" alt="" />
          </a>
          <div class="">
            <p class="mt-3 mb-1 text-dark">At vero eos et accusamus et iusto dignissimos ducimus odio.</p>
            <p class="mt-lg-5 pt-4 mb-lg-0 mb-4 text-dark">{{appName}} 2020. All rights reserved.</p>
          </div>
        </b-col>

        <b-col lg="7" class="offset-lg-1">
          <b-row>
            <b-col md="3" sm="6">
              <h6 class="mb-4 mt-4 mt-sm-2 text-dark fw-semibold text-uppercase">Navigations</h6>
              <ul class="list-unstyled">
                <li class="my-3"><a href="#" class="text-dark">Home</a></li>
                <li class="my-3"><a href="#" class="text-dark">Locations</a></li>
                <li class="my-3"><a href="#" class="text-dark">Plans</a></li>
                <li class="my-3"><a href="#" class="text-dark">Events</a></li>
              </ul>
            </b-col>
            <b-col md="3" sm="6">
              <h6 class="mb-4 mt-4 mt-sm-2 text-dark fw-semibold text-uppercase">Contact</h6>
              <ul class="list-unstyled">
                <li class="my-3"><a href="#" class="text-dark">Support</a></li>
                <li class="my-3"><a href="#" class="text-dark">Developers</a></li>
                <li class="my-3"><a href="#" class="text-dark">Customer Service</a></li>
                <li class="my-3"><a href="#" class="text-dark">Get Started Guide</a></li>
              </ul>
            </b-col>
            <b-col md="5" class="offset-md-1">
              <h6 class="mb-4 mt-4 mt-sm-2 text-dark fw-semibold text-uppercase">Subscribe To Newsletters</h6>
              <div class="input-group my-3">
                <input type="text" class="form-control h-auto" placeholder="Your email" aria-label="keywords" />
                <a href="#" class="btn btn-secondary input-group-text"><i class="icon-xs" data-feather="mail"></i></a>
              </div>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from '@/helpers';

</script>