<template>
  <section class="py-5 position-relative">
    <b-container>
      <b-row data-aos="fade-up">
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-orange px-2 py-1">Flexible</b-badge>
          <h1 class="fw-medium">Coworking Space Options</h1>
        </b-col>
      </b-row>

      <b-row class="mt-5">
        <b-col lg="6" xl="4" v-for="(item, idx) in options" :key="idx">
          <b-card no-body class="shadow-lg rounded" data-aos="fade-up" :data-aos-duration="item.animationDuration">
            <img :src="item.image" alt="" class="card-img-top" />
            <b-card-body>
              <div class="">
                <h4 class="mt-0"><a href="#" class="text-orange">{{ item.title }}</a></h4>
                <p class="text-muted mb-2">
                  {{ item.description }}
                </p>
              </div>
              <div class="pt-3">
                <b-row class="align-items-center">
                  <div class="col-auto">
                    <p class="mb-0">
                      <i data-feather="user" class="icon icon-dual icon-xs me-1"></i>
                      <a href="" class="fs-13 align-middle text-muted">{{ item.capacity }}</a>
                    </p>
                  </div>
                </b-row>
              </div>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { options } from "@/views/landings/co-working/components/data";
</script>