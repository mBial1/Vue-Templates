<template>
  <div class="header-5">
    <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-orange btn-sm" />

    <section class="hero-2">
      <b-container class="py-3 py-sm-6">
        <b-row class="align-items-center">
          <b-col lg="7">
            <h1 class="hero-title mt-0">Explore the best coworking space in the heart of the City</h1>
          </b-col>
          <b-col lg="5">
            <p class="fs-17 ps-0 ps-sm-4">No more conventional four-walled office. The fully comformtable seating
              solution for you.</p>
          </b-col>
        </b-row>

        <b-row>
          <b-col>
            <div class="slider pt-3 pt-sm-5 mt-5">
              <div class="form-container">
                <b-row class="align-items-top px-3 px-sm-5">
                  <b-col lg="12">
                    <b-card no-body class="mb-2">
                      <b-card-body>
                        <b-row class="align-items-center">
                          <b-col>
                            <b-row class="g-2 align-items-center">
                              <div class="col-sm-auto ">
                                <h5 class="mt-0 fw-medium my-1 my-sm-0 pe-3">Search your perfect space</h5>
                              </div>
                              <div class="col-sm-auto">
                                <label class="visually-hidden" for="location">location</label>
                                <div class="form-control-with-hint me-sm-2">
                                  <input type="text" class="form-control" id="location" placeholder="Enter location">
                                  <span class="form-control-feedback uil uil-location-pin-alt fs-18"></span>
                                </div>
                              </div>
                              <div class="col-sm-auto">
                                <b-button type="submit" :variant="null" class="btn btn-orange my-1 my-sm-0">Find
                                  Space</b-button>
                              </div>
                            </b-row>
                          </b-col>
                          <div class="col-sm-auto text-sm-end pt-2 pt-sm-0">
                            <div class="navigations">
                              <b-button variant="info" class="swiper-custom-prev">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                  fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round"
                                  stroke-linejoin="round" class="feather feather-chevron-left">
                                  <polyline points="15 18 9 12 15 6"></polyline>
                                </svg>
                              </b-button> {{ ' ' }}
                              <b-button variant="info" class="swiper-custom-next">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                  fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round"
                                  stroke-linejoin="round" class="feather feather-chevron-right">
                                  <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                              </b-button>
                            </div>
                          </div>
                        </b-row>
                      </b-card-body>
                    </b-card>
                  </b-col>
                </b-row>
              </div>


              <Swiper class="swiper-container" id="coworking-slider" data-toggle="swiper" data-aos="fade-up"
                :modules="[Autoplay, Navigation]" :slidesPerView="1" :spaceBetween="0" :loop="true" :roundLengths="true"
                :autoplay="{ delay: 5000 }" :navigation="{
                  nextEl: '.swiper-custom-next', prevEl: '.swiper-custom-prev'
                }">

                <SwiperSlide v-for="(item, idx) in demos" :key="idx">
                  <div class="slider-item" :style="`background-image: url(${item})`"></div>
                </SwiperSlide>
              </Swiper>
            </div>
          </b-col>
        </b-row>
      </b-container>
      <div class="shape bottom d-none d-sm-block">
        <svg width="1440px" height="40px" viewBox="0 0 1440 40" version="1.1" xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink">
          <g id="shape-b" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="curve" fill="#fff">
              <path
                d="M0,30.013 C239.659,10.004 479.143,0 718.453,0 C957.763,0 1198.28,10.004 1440,30.013 L1440,40 L0,40 L0,30.013 Z"
                id="Path"></path>
            </g>
          </g>
        </svg>
      </div>
    </section>
  </div>
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";

import coworking2 from "@/assets/images/hero/coworking2.jpg";
import coworking3 from "@/assets/images/hero/coworking3.jpg";
import coworking4 from "@/assets/images/hero/coworking4.jpg";

import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Navigation } from 'swiper/modules';

const demos: string[] = [coworking2, coworking3, coworking4];
</script>