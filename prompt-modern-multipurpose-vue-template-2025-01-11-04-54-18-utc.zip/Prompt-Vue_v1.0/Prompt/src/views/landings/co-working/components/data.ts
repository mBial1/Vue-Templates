import type { CounterType, OptionType } from "@/views/landings/co-working/components/types";

import photos8 from "@/assets/images/photos/8.jpg";
import photos5 from "@/assets/images/photos/5.jpg";
import photos4 from "@/assets/images/photos/4.jpg";

export const options: OptionType[] = [
  {
    title: "Shared Desk",
    description: "Access to shared workspace and conference rooms. Most suitable to looking for people's company.",
    image: photos8,
    capacity: "1-5 Shared Spaces",
    animationDuration: 600,
  },
  {
    title: "Dedicated Desk",
    description: "A dedicated desk space for you, with 24/7 access to premium amenities and conference rooms.",
    image: photos5,
    capacity: "1-5 Dedicated Spaces",
    animationDuration: 1000,
  },
  {
    title: "Event Space",
    description: "An exclusive venue designed specifically for events of all kinds, from conferences to celebrations.",
    image: photos4,
    capacity: "Up to 200 People",
    animationDuration: 1400,
  }
];

export const counters: CounterType[] = [
  {
    label: "Meeting Rooms",
    startAmount: 0,
    endAmount: 21,
    duration: 3
  },
  {
    label: "Event Spaces",
    startAmount: 5,
    endAmount: 51,
    duration: 3
  },
  {
    label: "Studio Rooms",
    startAmount: 1,
    endAmount: 11,
    duration: 3
  },
  {
    label: "Seating Spaces",
    startAmount: 100,
    endAmount: 500,
    duration: 3,
    suffix: "+"
  }];