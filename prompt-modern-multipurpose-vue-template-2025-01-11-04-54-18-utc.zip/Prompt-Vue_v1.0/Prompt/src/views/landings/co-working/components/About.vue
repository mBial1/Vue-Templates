<template>
    <section class="py-lg-6 py-4 mt-xl-10 mt-0 coworking-1">
        <b-container>
            <b-row class="align-items-center">
                <b-col>
                    <div class="text-center">
                        <b-badge :variant="null" pill class="badge-soft-info px-2 py-1">About</b-badge>
                        <h1 class="fw-semibold">More Productivity, Less Expenses</h1>
                        <p class="text-muted mx-auto w-75 mt-1">From an established enterprise or a startup, we offer
                            space that fits all.</p>

                        <b-row class="mt-5 text-center" data-aos="fade-up">
                            <b-col cols="6" md="3" class="mb-5 mb-sm-0" v-for="(item, idx) in counters" :key="idx">
                                <div class="display-3 fw-bold">
                                    <Vue3autocounter ref='counter' :startAmount='item.startAmount'
                                        :endAmount='item.endAmount' :duration='item.duration' :suffix="item.suffix" />
                                </div>
                                <p class="mt-1 mb-0">Meeting Rooms</p>
                            </b-col>
                        </b-row>
                    </div>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
import Vue3autocounter from 'vue3-autocounter';
import { counters } from "@/views/landings/co-working/components/data";
</script>