<template>
  <section class="section py-4 py-sm-7 position-relative overflow-hidden" data-aos="fade-up">
    <b-container class="testimonials-3">
      <b-row class="align-items-center">
        <b-col>
          <h1 class="fw-medium">See what our members are saying</h1>
        </b-col>
        <div class="col-auto text-sm-end pt-2 pt-sm-0">
          <div class="navigations">
            <button class="btn btn-link text-orange p-0 swiper-custom-prev">
              <svg class="bi bi-arrow-left" width="1.75em" height="1.75em" viewBox="0 0 16 16" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                  d="M5.854 4.646a.5.5 0 010 .708L3.207 8l2.647 2.646a.5.5 0 01-.708.708l-3-3a.5.5 0 010-.708l3-3a.5.5 0 01.708 0z"
                  clip-rule="evenodd"></path>
                <path fill-rule="evenodd" d="M2.5 8a.5.5 0 01.5-.5h10.5a.5.5 0 010 1H3a.5.5 0 01-.5-.5z"
                  clip-rule="evenodd"></path>
              </svg>
            </button>
            <button class="btn btn-link text-orange p-0 swiper-custom-next">
              <svg class="bi bi-arrow-right" width="1.75em" height="1.75em" viewBox="0 0 16 16" fill="currentColor"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                  d="M10.146 4.646a.5.5 0 01.708 0l3 3a.5.5 0 010 .708l-3 3a.5.5 0 01-.708-.708L12.793 8l-2.647-2.646a.5.5 0 010-.708z"
                  clip-rule="evenodd"></path>
                <path fill-rule="evenodd" d="M2 8a.5.5 0 01.5-.5H13a.5.5 0 010 1H2.5A.5.5 0 012 8z" clip-rule="evenodd">
                </path>
              </svg>
            </button>
          </div>
        </div>
      </b-row>
      <b-row class="mt-3 mt-sm-5">
        <b-col>
          <div class="slider">
          <Swiper class="swiper-container" id="coworking-slider" data-toggle="swiper" :modules="[Autoplay, Navigation]"
            :loop="true" :spaceBetween="24" :autoplay="{ delay: 5000 }" :breakpoints="{
              576: { slidesPerView: 1 },
              768: { slidesPerView: 2 }
            }" :roundLengths="true" :navigation="{ nextEl: '.swiper-custom-next', prevEl: '.swiper-custom-prev' }">
            <SwiperSlide>
              <b-card no-body class="mb-0 shadow border">
                <b-card-body class="p-md-5">
                  <h5 class="fw-normal mb-4 mt-0">
                    Great office and great location. Worth the money if it makes sense for your business.
                  </h5>
                  <div class="d-flex text-align-start">
                    <img class="me-2 rounded-circle" :src="avatar8" alt="" height="36" />
                    <div class="flex-grow-1">
                      <h6 class="m-0">Cersei Lannister</h6>
                      <p class="my-0 text-muted fs-13">Senior Project Manager</p>
                    </div>
                    <img class="" :src="google" alt="" height="32" />
                  </div>
                </b-card-body>
              </b-card>
            </SwiperSlide>
            <SwiperSlide>
              <b-card no-body class="mb-0 border">
                <b-card-body class="p-md-5">
                  <h5 class="fw-normal mb-4 mt-0">
                    Awesome vibe and great staff! Top coworking spots in the city! Loved to be here!
                  </h5>
                  <div class="d-flex text-align-start">
                    <img class="me-2 rounded-circle" :src="avatar5" alt="" height="36" />
                    <div class="flex-grow-1">
                      <h6 class="m-0">John Stark</h6>
                      <p class="my-0 text-muted fs-13">Engineering Director</p>
                    </div>
                    <img class="" :src="amazon" alt="" height="32" />
                  </div>
                </b-card-body>
              </b-card>
            </SwiperSlide>
            <SwiperSlide>
              <b-card no-body class="mb-0 shadow border">
                <b-card-body class="p-md-5">
                  <h5 class="fw-normal mb-4 mt-0">
                    Great office and great location. Worth the money if it makes sense for your business.
                  </h5>
                  <div class="d-flex text-align-start">
                    <img class="me-2 rounded-circle" :src="avatar8" alt="" height="36" />
                    <div class="flex-grow-1">
                      <h6 class="m-0">Cersei Lannister</h6>
                      <p class="my-0 text-muted fs-13">Senior Project Manager</p>
                    </div>
                    <img class="" :src="google" alt="" height="32" />
                  </div>
                </b-card-body>
              </b-card>
            </SwiperSlide>
            <SwiperSlide>
              <b-card no-body class="mb-0 border">
                <b-card-body class="p-md-5">
                  <h5 class="fw-normal mb-4 mt-0">
                    Awesome vibe and great staff! Top coworking spots in the city! Loved to be here!
                  </h5>
                  <div class="d-flex text-align-start">
                    <img class="me-2 rounded-circle" :src="avatar5" alt="" height="36" />
                    <div class="flex-grow-1">
                      <h6 class="m-0">John Stark</h6>
                      <p class="my-0 text-muted fs-13">Engineering Director</p>
                    </div>
                    <img class="" :src="amazon" alt="" height="32" />
                  </div>
                </b-card-body>
              </b-card>
            </SwiperSlide>
          </Swiper>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Navigation } from 'swiper/modules';

import avatar5 from "@/assets/images/avatars/img-5.jpg"
import avatar8 from "@/assets/images/avatars/img-8.jpg"

import amazon from "@/assets/images/brands/amazon.svg"
import google from "@/assets/images/brands/google.svg"
</script>