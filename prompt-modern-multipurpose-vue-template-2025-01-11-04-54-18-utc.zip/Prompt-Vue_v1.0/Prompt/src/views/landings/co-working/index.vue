<template>
  <Hero />
  <About />
  <Features />
  <Options />
  <Testimonials />
  <Footer />
</template>
<script setup lang="ts">
import Hero from '@/views/landings/co-working/components/Hero.vue';
import About from '@/views/landings/co-working/components/About.vue';
import Features from '@/views/landings/co-working/components/Features.vue';
import Options from '@/views/landings/co-working/components/Options.vue';
import Testimonials from '@/views/landings/co-working/components/Testimonials.vue';
import Footer from '@/views/landings/co-working/components/Footer.vue';
</script>