<template>
  <section class="section pt-8 pb-6 bg-gradient3 position-relative">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row data-aos="fade-up" data-aos-duration="200">
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Clients</b-badge>

          <h1 class="fw-medium">The smart people management you need</h1>
          <p class="text-muted mx-auto">
            21,000+ organizations trust <span class="text-primary fw-bold">{{ appName }}</span> to drive performance &
            engagement
          </p>

          <ul class="list-inline mt-5">
            <li class="list-inline-item mx-4 mx-xl-5 mb-3" v-for="(logo, idx) in companies" :key="idx">
              <img :src="logo" alt="" height="32" />
            </li>
          </ul>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import { companies } from "@/views/landings/saas-classic/components/data";
</script>