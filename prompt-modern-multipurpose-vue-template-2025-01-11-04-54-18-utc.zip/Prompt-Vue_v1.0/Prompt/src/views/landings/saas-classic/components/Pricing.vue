<template>
  <section class="section py-6 py-sm-8 bg-gradient3 position-relative">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Plans</b-badge>

          <h1 class="fw-medium">Pricing Plans</h1>
          <p class="text-muted mx-auto">
            Pricing that <span class="text-primary fw-bold">works</span> for everyone
          </p>
        </b-col>
      </b-row>

      <b-row class="align-items-center mt-0 mt-sm-5">
        <b-col lg="4" xl="4" v-for="(item, idx) in pricing" :key="idx">
          <b-card no-body class="border hoverable" data-aos="fade-up" :data-aos-duration="item.animationDuration">
            <b-card-body class="text-center">
              <h4 class="my-0 text-primary">{{ item.plan }}</h4>
              <h1 class="mb-0">
                <span class="fw-normal text-muted fs-13 align-top">{{ currency }}</span>
                <span class="fw-bolder display-4">{{ item.price }}</span>
                <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
              </h1>
              <ul class="list-unstyled border-top py-4 mt-4 text-start">
                <li class="py-2 d-flex flex-row align-items-center" v-for="(feat, idx) in item.features" :key="idx">
                  <i class="align-middle icon-dual-success me-2 icon-xs" data-feather="check"></i>
                  <span>{{ feat }}</span>
                </li>
                <li class="py-2 d-flex flex-row align-items-center" v-if="!idx">
                  &nbsp;
                </li>
              </ul>
              <a href="#" class="btn d-block" :class="item.isPopular ? 'btn-primary' : 'btn-soft-primary'">Sign Up
                Now</a>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
    <div class="divider bottom d-none d-sm-block"></div>
  </section>
</template>
<script setup lang="ts">
import { currency } from "@/helpers";
import { pricing } from "@/views/landings/saas-classic/components/data";
</script>