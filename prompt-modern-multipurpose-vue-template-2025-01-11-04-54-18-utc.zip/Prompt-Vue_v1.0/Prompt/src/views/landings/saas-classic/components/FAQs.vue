<template>
  <section class="section py-6 pt-sm-6 position-relative">
    <b-container data-aos="fade-up" data-aos-duration="2000">
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">FAQs</b-badge>

          <h1 class="fw-medium">Frequently Asked Questions</h1>
          <p class="text-muted mx-auto">Here are some of the basic types of questions for our customers</p>
        </b-col>
      </b-row>

      <b-row class="justify-content-center mt-5">
        <b-col md="10" lg="8">
          <div id="faqContent">
            <div class="accordion custom-accordionwitharrow" id="accordionExample">
              <b-card no-body class="mb-1 border rounded-sm" v-for="(item, idx) in faqs" :key="idx">
                <a href="#/" class="text-dark" @click="show = (idx + 1)">
                  <b-card-header id="headingOne">
                    <h5 class="my-1 fw-medium">{{ item.ques }}
                      <i class="icon-xs accordion-arrow" data-feather="chevron-down"></i>
                    </h5>
                  </b-card-header>
                </a>
                <b-collapse id="collapseOne" :visible="show === (idx + 1)">
                  <b-card-body class="text-muted pt-1">
                    {{ item.ans }}
                  </b-card-body>
                </b-collapse>
              </b-card>
            </div>
          </div>
        </b-col>
      </b-row>
      <b-row class="justify-content-center mt-5">
        <div class="col-auto">
          <div class="rounded d-inline-block py-2 px-3 alert bg-light">
            <div class="d-flex align-items-center">
              <div class="text-dark">
                Still have unanswered questions? <a href="">Contact Us</a>
              </div>
            </div>
          </div>
        </div>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { ref } from "vue";

import { faqs } from "@/views/landings/saas-classic/components/data";
const show = ref(1);
</script>