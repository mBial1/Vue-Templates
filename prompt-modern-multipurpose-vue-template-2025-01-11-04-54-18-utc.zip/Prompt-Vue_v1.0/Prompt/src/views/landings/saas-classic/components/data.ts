import amazon from "@/assets/images/brands/amazon.svg";
import google from "@/assets/images/brands/google.svg";
import paypal from "@/assets/images/brands/paypal.svg";
import spotify from "@/assets/images/brands/spotify.svg";
import shopify from "@/assets/images/brands/shopify.svg";
import { FAQType, FeatureType, PriceType } from "@/types";

export const companies: string[] = [amazon, google, paypal, spotify, shopify];

export const faqs: FAQType[] = [
  {
    ques: "Can I use this template for my client?",
    ans: "Yup, the marketplace license allows you to use this theme in any end products. For more information on licenses, please refere license terms on marketplace."
  },
  {
    ques: "Can this theme work with WordPress?",
    ans: "No. This is a HTML template. It won't directly with WordPress, though you can convert this into WordPress compatible theme."
  },
  {
    ques: "How do I get help with the theme?",
    ans: "Use our dedicated support email (support@coderthemes.com) to send your issues or feedback. We are here to help anytime."
  },
  {
    ques: "Will you regularly give updates of Prompt ?",
    ans: "Yes, We will update the Prompt regularly. All the future updates would be available without any cost."
  }
];

export const features: FeatureType[] = [
  {
    id: 1,
    features: [
      "Hire and Retain Top Talent",
      "Team Management"
    ]
  },
  {
    id: 2,
    features: [
      "Stay Compliant",
      "Improve Productivity",
      "Improve Experience"
    ]
  },
  {
    id: 3,
    features: [
      "Selfservice Time Tracking",
      "Performance Management",
      "Expert HR"
    ]
  },
  {
    id: 4,
    features: [
      "New Hire Checklist",
      "Tax Calculator"
    ]
  },
];

export const pricing: PriceType[] = [
  {
    plan: "Starter",
    price: 49,
    features: [
      "Up to 600 minutes usage time",
      "Use for personal only",
      "Add up to 10 attendees",
      "Technical support via email",
    ],
    animationDuration: 500
  },
  {
    plan: "Professional",
    price: 99,
    features: [
      "Up to 6000 minutes usage time",
      "Use for personal or a commercial",
      "Add up to 100 attendees",
      "Up to 5 teams",
      "Technical support via email"
    ],
    animationDuration: 700,
    isPopular: true
  },
  {
    plan: "Enterprise",
    price: 599,
    features: [
      "Unlimited usage time",
      "Use for personal or a commercial",
      "Add Unlimited attendees",
      "24x7 Technical support via phone",
      "Technical support via email"
    ],
    animationDuration: 900
  }
];