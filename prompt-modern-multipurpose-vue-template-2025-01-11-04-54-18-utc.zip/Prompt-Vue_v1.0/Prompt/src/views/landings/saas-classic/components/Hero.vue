<template>
  <section class="position-relative hero-11 py-1 pt-7 pb-sm-6">
    <b-container class="hero-content">
      <b-row class="align-items-center">
        <b-col cols="12" class="text-center">
          <h1 class="hero-title">The best way to <span
              class="highlight highlight-success d-inline-block">showcase</span> your saas</h1>

          <p class="fs-17 text-muted pt-0">
            Make your saas application stand out with high-quality landing page designed and developed by
            professional
          </p>

          <div class="mt-4 mt-sm-5 pt-0 d-flex align-items-center justify-content-center">
            <b-row class="g-2 text-start">
              <b-col sm="5">
                <label class="visually-hidden" for="name">Name</label>
                <input type="text" class="form-control mb-2 me-sm-2 shadow-sm" name="name" id="name"
                  placeholder="Your Name">
              </b-col>
              <b-col sm="5">
                <label class="visually-hidden" for="email">Email</label>
                <input type="email" class="form-control mb-2 me-sm-2 shadow-sm" name="email" id="email"
                  placeholder="Your Email">
              </b-col>
              <b-col sm="2">
                <b-button type="submit" variant="primary" class="mb-2 text-nowrap">Sign Up</b-button>
              </b-col>
            </b-row>
          </div>
          <div class="d-flex mt-2 justify-content-center">
            <div class="me-4"><i data-feather="check-circle" class="icon icon-dual-success icon-xs me-1"></i>Free 14-day
              Demo</div>
            <div class="me-4"><i data-feather="check-circle" class="icon icon-dual-success icon-xs me-1"></i>No credit
              card needed</div>
            <div><i data-feather="check-circle" class="icon icon-dual-success icon-xs me-1"></i>No Setup</div>
          </div>
        </b-col>
      </b-row>
    </b-container>

    <div class="feature-container position-relative overflow-hidden mt-5 mb-4">
      <b-container>
        <b-row class="align-items-center justify-content-center zindex-1 slider-container">
          <b-col cols="10" class="text-center zindex-1">
            <b-card no-body class="rounded-lg shadow" data-aos="fade-up" data-aos-duration="2000">
              <b-card-body class="slider-container-body">
                <div class="slider">
                  <Swiper class="swiper-container" data-toggle="swiper" :modules="[Autoplay]" :slidesPerView="1"
                    :loop="true" :spaceBetween="0" :autoplay="{ delay: 5000 }"
                    :breakpoints="{ 576: { slidesPerView: 1.2 }, 768: { slidesPerView: 1 } }" :roundLengths="true">
                    <SwiperSlide>
                      <div class="swiper-slide-content">
                        <div class="video-overlay d-flex align-items-center justify-content-center">
                          <a href="#" class="btn-play success"></a>
                        </div>
                        <img :src="saas1" alt="" class="img-fluid rounded-lg" />
                      </div>
                    </SwiperSlide>
                    <SwiperSlide>
                      <div class="swiper-slide-content">
                        <div class="video-overlay d-flex align-items-center justify-content-center">
                          <a href="#" class="btn-play success"></a>
                        </div>
                        <img :src="saas2" alt="" class="img-fluid rounded-lg" />
                      </div>
                    </SwiperSlide>
                    <SwiperSlide>
                      <div class="swiper-slide-content">
                        <div class="video-overlay d-flex align-items-center justify-content-center">
                          <a href="#" class="btn-play success"></a>
                        </div>
                        <img :src="saas3" alt="" class="img-fluid rounded-lg" />
                      </div>
                    </SwiperSlide>
                  </Swiper>
                </div>
              </b-card-body>
            </b-card>
          </b-col>
        </b-row>
      </b-container>
    </div>
  </section>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';

import saas1 from "@/assets/images/hero/saas1.jpg";
import saas2 from "@/assets/images/hero/saas2.jpg";
import saas3 from "@/assets/images/hero/saas3.jpg";
</script>