<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto navbar-light" ctaButtonClass="btn-primary btn-sm" />
  <Hero />
  <Features />
  <Clients />
  <Testimonials />
  <Pricing />
  <FAQs />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";

import Hero from "@/views/landings/saas-classic/components/Hero.vue";
import Features from "@/views/landings/saas-classic/components/Features.vue";
import Clients from "@/views/landings/saas-classic/components/Clients.vue";
import Testimonials from "@/views/landings/saas-classic/components/Testimonials.vue";
import Pricing from "@/views/landings/saas-classic/components/Pricing.vue";
import FAQs from "@/views/landings/saas-classic/components/FAQs.vue";
import Footer from "@/views/landings/saas-classic/components/Footer.vue";
</script>