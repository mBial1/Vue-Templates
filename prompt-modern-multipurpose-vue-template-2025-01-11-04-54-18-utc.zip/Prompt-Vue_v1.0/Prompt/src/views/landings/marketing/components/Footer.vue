<template>
  <section class="mt-5 py-3 marketing-6 bg-gradient3 position-relative">
    <b-container>
      <b-row class="align-items-center mt-3 mb-4 pb-1">
        <b-col lg="6">
          <h2 class="text-dark fw-medium mt-0 mb-1">Ready to get started?</h2>
          <p class="text-muted pb-0 mb-0">Create your free 14-day account now</p>
        </b-col>

        <b-col lg="6">
          <div class="text-lg-end">
            <a href="#" class="btn btn-primary rounded-pill">Try it free for 14 days</a>{{ ' ' }}
            <a href="#" class="btn btn-link rounded-pill">Chat with us</a>
          </div>
        </b-col>
      </b-row>
    </b-container>
    <hr class="my-4" />
    <b-container>
      <b-row>
        <b-col>
          <a class="navbar-brand me-lg-4 mb-4 me-auto" href="#">
            <img src="@/assets/images/logo.png" height="30" class="d-inline-block align-top" alt="" />
          </a>
          <p class="text-muted w-75">Make your marketing application stand out with high-quality landing page</p>
        </b-col>
        <div class="col-sm-auto">
          <div class="ps-md-5">
            <h6 class="mb-4 mt-5 mt-sm-2 fs-14 fw-semibold text-uppercase">Platform</h6>
            <ul class="list-unstyled">
              <li class="my-3"><a href="#" class="text-muted">Demo</a></li>
              <li class="my-3"><a href="#" class="text-muted">Pricing</a></li>
              <li class="my-3"><a href="#" class="text-muted">Integrations</a></li>
              <li class="my-3"><a href="#" class="text-muted">Status</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-auto">
          <div class="ps-md-5">
            <h6 class="mb-4 mt-5 mt-sm-2 fs-14 fw-semibold text-uppercase">Knowledge Base</h6>
            <ul class="list-unstyled">
              <li class="my-3"><a href="#" class="text-muted">Blog</a></li>
              <li class="my-3"><a href="#" class="text-muted">Help Center</a></li>
              <li class="my-3"><a href="#" class="text-muted">Sales Tools catalog</a></li>
              <li class="my-3"><a href="#" class="text-muted">API</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-auto">
          <div class="ps-md-5">
            <h6 class="mb-4 mt-5 mt-sm-2 fs-14 fw-semibold text-uppercase">Company</h6>
            <ul class="list-unstyled">
              <li class="my-3"><a href="#" class="text-muted">About Us</a></li>
              <li class="my-3"><a href="#" class="text-muted">Career</a></li>
              <li class="my-3"><a href="#" class="text-muted">Contact Us</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-auto">
          <div class="ps-md-5">
            <h6 class="mb-4 mt-5 mt-sm-2 fs-14 fw-semibold text-uppercase">Legal</h6>
            <ul class="list-unstyled">
              <li class="my-3"><a href="#" class="text-muted">Usage Policy</a></li>
              <li class="my-3"><a href="#" class="text-muted">Privacy Policy</a></li>
              <li class="my-3"><a href="#" class="text-muted">Terms of Service</a></li>
              <li class="my-3"><a href="#" class="text-muted">Trust</a></li>
            </ul>
          </div>
        </div>
      </b-row>
      <hr />
      <b-row>
        <b-col class="text-center">
          <p class="pb-0 mb-0 text-muted">
            {{ currentYear }} © {{ appName }}. All rights reserved. Crafted by <a :href="developedByLink">{{ developedBy
              }}</a>
          </p>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { currentYear, appName, developedBy, developedByLink } from "@/helpers/constants";
</script>