<template>
  <section class="section pt-lg-8 pb-lg-7 py-6 position-relative features-4" data-aos="fade-up">
    <b-container>
      <b-row class="testimonials-2">
        <b-col lg="3">
          <b-row class="align-items-center">
            <b-col>
              <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Feedback</b-badge>

              <h1 class="fw-semibold">Trusted by 2500+ customers</h1>
              <p class="text-muted mx-auto">Some valuables words from our customers.</p>
            </b-col>
          </b-row>
          <b-row class="mt-3 mb-4 mb-lg-0">
            <div class="col-auto text-sm-end pt-2 pt-sm-0">
              <div class="navigations">
                <button class="btn btn-link text-normal p-0 swiper-custom-prev">
                  <svg class="bi bi-arrow-left" width="1.75em" height="1.75em" viewBox="0 0 16 16" fill="currentColor"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                      d="M5.854 4.646a.5.5 0 010 .708L3.207 8l2.647 2.646a.5.5 0 01-.708.708l-3-3a.5.5 0 010-.708l3-3a.5.5 0 01.708 0z"
                      clip-rule="evenodd"></path>
                    <path fill-rule="evenodd" d="M2.5 8a.5.5 0 01.5-.5h10.5a.5.5 0 010 1H3a.5.5 0 01-.5-.5z"
                      clip-rule="evenodd"></path>
                  </svg>
                </button>
                <button class="btn btn-link text-normal p-0 swiper-custom-next">
                  <svg class="bi bi-arrow-right" width="1.75em" height="1.75em" viewBox="0 0 16 16" fill="currentColor"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                      d="M10.146 4.646a.5.5 0 01.708 0l3 3a.5.5 0 010 .708l-3 3a.5.5 0 01-.708-.708L12.793 8l-2.647-2.646a.5.5 0 010-.708z"
                      clip-rule="evenodd"></path>
                    <path fill-rule="evenodd" d="M2 8a.5.5 0 01.5-.5H13a.5.5 0 010 1H2.5A.5.5 0 012 8z"
                      clip-rule="evenodd"></path>
                  </svg>
                </button>
              </div>
            </div>
          </b-row>
        </b-col>
        <b-col lg="8" class="offset-lg-1">
          <div class="slider">
            <Swiper class="swiper-container" data-toggle="swiper" :modules="[Autoplay, Navigation]" :loop="true"
              :spaceBetween="24" :autoplay="{ delay: 5000 }"
              :breakpoints="{ 576: { slidesPerView: 1 }, 768: { slidesPerView: 1 } }" :roundLengths="true"
              :navigation="{ nextEl: '.swiper-custom-next', prevEl: '.swiper-custom-prev' }">
              <SwiperSlide>
                <b-card no-body class="mb-0 border rounded">
                  <b-card-body class="testimonial-body shadow">
                    <p class="quotation-mark text-muted mb-0">“</p>
                    <h4 class="fw-normal mb-3 mt-0">
                      This app is a truly blessing for all professionals! A day to day project management was never
                      easy for me. But with {{ appName }}, I can manage more than 100 projects easily.
                    </h4>
                    <hr />
                    <div class="d-flex pt-2 align-items-center">
                      <img class="me-2 rounded-circle" :src="avatar8" alt="" height="36" />
                      <div class="flex-grow-1">
                        <h6 class="m-0">Cersei Lannister</h6>
                        <p class="my-0 text-muted fs-13">Senior Project Manager</p>
                      </div>
                      <img class="" :src="amazon" alt="" height="32" />
                    </div>
                  </b-card-body>
                </b-card>
              </SwiperSlide>
              <SwiperSlide>
                <b-card no-body class="mb-0 border rounded">
                  <b-card-body class="testimonial-body shadow">
                    <p class="quotation-mark text-muted mb-0">“</p>
                    <h4 class="fw-normal mb-3 mt-0">
                      It is one of the very convenient to use project manager ever! I have tried many project
                      management apps for my daily tasks, but this one is far better than others. Simply loved it!
                    </h4>
                    <hr />
                    <div class="d-flex pt-2 align-items-center">
                      <img class="me-2 rounded-circle" :src="avatar5" alt="" height="36" />
                      <div class="flex-grow-1">
                        <h6 class="m-0">John Stark</h6>
                        <p class="my-0 text-muted fs-13">Engineering Director</p>
                      </div>
                      <img class="" :src="google" alt="" height="32" />
                    </div>
                  </b-card-body>
                </b-card>
              </SwiperSlide>
            </Swiper>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Navigation } from 'swiper/modules';
import { appName } from '@/helpers';

import avatar8 from "@/assets/images/avatars/img-8.jpg"
import avatar5 from "@/assets/images/avatars/img-5.jpg"
import amazon from "@/assets/images/brands/amazon.svg"
import google from "@/assets/images/brands/google.svg"
</script>