<template>
  <section class="section py-4 py-sm-8 bg-gradient3 position-relative" data-aos="fade-up">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row>
        <b-col lg="5">
          <h1 class="display-4 fw-semibold mb-4">Monitor what is being performed anytime</h1>
          <p class="mb-5">
            Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates
            repudiandae sint et molestiae non recusandae itaque earum rerum hic tenetur a sapiente delectus ut aut
            reiciendis voluptatibus maiores alias...
          </p>
          <a href="#" class="btn btn-primary">
            Start Free Trial <i class="icon-xs ms-2" data-feather="arrow-right"></i>
          </a>
        </b-col>
        <b-col lg="6" class="offset-lg-1">
          <img :src="marketing4" alt="" class="img-fluid d-block mx-auto mt-4 mt-lg-0" />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import marketing4 from "@/assets/images/features/marketing4.jpg"
</script>