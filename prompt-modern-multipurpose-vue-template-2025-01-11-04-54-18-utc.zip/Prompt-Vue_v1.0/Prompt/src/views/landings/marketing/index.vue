<template>
  <Hero />
  <Feature />
  <MainFeature />
  <Feature2 />
  <Feature3 />
  <Testimonials />
  <Footer />
</template>
<script setup lang="ts">
import Hero from '@/views/landings/marketing/components/Hero.vue';
import Feature from '@/views/landings/marketing/components/Feature.vue';
import MainFeature from '@/views/landings/marketing/components/MainFeature.vue';
import Feature2 from '@/views/landings/marketing/components/Feature2.vue';
import Feature3 from '@/views/landings/marketing/components/Feature3.vue';
import Testimonials from '@/views/landings/marketing/components/Testimonials.vue';
import Footer from '@/views/landings/marketing/components/Footer.vue';
</script>