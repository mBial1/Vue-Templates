<template>
  <Hero />
  <Clients />
  <Feature1 />
  <Feature2 />
  <Pricing />
  <Testimonials />
  <Footer />
</template>
<script setup lang="ts">
import Hero from '@/views/landings/software/components/Hero.vue';
import Clients from '@/views/landings/software/components/Clients.vue';
import Feature1 from '@/views/landings/software/components/Feature1.vue';
import Feature2 from '@/views/landings/software/components/Feature2.vue';
import Pricing from '@/views/landings/software/components/Pricing.vue';
import Testimonials from '@/views/landings/software/components/Testimonials.vue';
import Footer from '@/views/landings/software/components/Footer.vue';
</script>