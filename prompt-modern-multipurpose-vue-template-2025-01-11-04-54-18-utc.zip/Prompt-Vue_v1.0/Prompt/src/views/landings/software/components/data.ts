import { PriceType } from "@/types";

import amazon from "@/assets/images/brands/amazon.svg";
import google from "@/assets/images/brands/google.svg";
import paypal from "@/assets/images/brands/paypal.svg";
import spotify from "@/assets/images/brands/spotify.svg";
import shopify from "@/assets/images/brands/shopify.svg";

export const companies: string[] = [amazon, google, paypal, spotify, shopify];

export const pricing: PriceType[] = [
  {
    plan: "Starter",
    price: 49,
    features: [
      "Up to 600 minutes usage time",
      "Use for personal only",
      "Add up to 10 attendees",
      "Technical support via email"
    ],
    animationDuration: 1000
  },
  {
    plan: "Professional",
    price: 99,
    features: [
      "Up to 6000 minutes usage time",
      "Use for personal or a commercial",
      "Add up to 100 attendees",
      "Up to 5 teams",
      "Technical support via email"
    ],
    animationDuration: 1200,
    isPopular: true
  },
  {
    plan: "Enterprise",
    price: 599,
    features: [
      "Unlimited usage time",
      "Use for personal or a commercial",
      "Add Unlimited attendees",
      "24x7 Technical support via phone",
      "Technical support via email"
    ],
    animationDuration: 1400
  }
];