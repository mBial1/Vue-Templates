<template>
    <section class="pt-4 pt-sm-6 pb-5 desktop-5">
        <b-container>
            <b-row class="justify-content-center">
                <b-col>
                    <div class="text-center">
                        <h1 class="text-dark">Be the first to know!</h1>
                        <p class="">We'll inform you about new updates, features, but no spam, we promise.</p>
                    </div>

                    <div class="my-4 my-sm-5 pt-0 d-flex align-items-center justify-content-center">
                        <b-row class="g-2">
                            <b-col sm="8">
                                <label class="visually-hidden" for="email">Email</label>
                                <input type="email" class="form-control mb-2 me-sm-2 shadow-sm" name="email" id="email"
                                    placeholder="Your Email">
                            </b-col>
                            <b-col sm="4">
                                <b-button type="submit" variant="primary" class="mb-2">Sign Up</b-button>
                            </b-col>
                        </b-row>
                    </div>
                </b-col>
            </b-row>
        </b-container>
        <hr class="my-4" />
        <b-container>
            <b-row class="justify-content-center">
                <b-col lg="8">
                    <div class="text-center mt-5">
                        <h5 class="fw-normal">2020 &copy; Copyright. All rights reserved. Crafted by <a
                                href="https://coderthemes.com/">Coderthemes</a></h5>
                        <ul class="list-inline mt-4">
                            <li class="list-inline-item mx-4 mb-3"><a href="#" class="text-dark">Changelog</a></li>
                            <li class="list-inline-item mx-4 mb-3"><a href="#" class="text-dark">FAQ</a></li>
                            <li class="list-inline-item mx-4 mb-3"><a href="#" class="text-dark">Press kit</a></li>
                            <li class="list-inline-item mx-4 mb-3"><a href="#" class="text-dark">Contact us</a></li>
                            <li class="list-inline-item mx-4 mb-3"><a href="#" class="text-dark">Careers
                                    <b-badge :variant="null" pill
                                        class="badge-soft-info align-middle fw-normal fs-11 px-2 py-1">We're
                                        hiring</b-badge>
                                </a>
                            </li>
                        </ul>
                    </div>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
</script>