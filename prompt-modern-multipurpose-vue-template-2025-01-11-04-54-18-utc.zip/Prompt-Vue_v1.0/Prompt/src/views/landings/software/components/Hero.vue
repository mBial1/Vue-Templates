<template>
  <div class="header-2">
    <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-primary btn-sm" />

    <section class="position-relative overflow-hidden hero-7 pt-6 pb-4">
      <b-container>
        <b-row class="align-items-center text-center text-sm-start">
          <b-col lg="6">
            <div class="">
              <h1 class="hero-title">Speed up your <span
                  class="highlight highlight-warning d-inline-block">performance</span></h1>
              <p class="fs-16 mt-3 text-muted">
                {{appName}} makes it easier to build better website and application more quickly and with less effort
              </p>

              <div class="py-5">
                <DropDown custom-class="btn-group">
                  <b-button type="button" variant="primary">
                    <i data-feather="download" class="icon-xs me-2"></i>Download for Ubuntu 19.04
                  </b-button>
                  <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split"
                    id="dropdownMenuReference" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                    data-reference="parent">
                    <i class="icon"><span data-feather="chevron-down"></span></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuReference">
                    <a class="dropdown-item" href="#">Windows 7/8/10</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Mac OS</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Ubuntu 18.04</a>
                    <a class="dropdown-item" href="#">Ubuntu 16.04</a>
                  </div>
                </DropDown>
                <div class="rounded d-inline-block mt-3 py-1 px-3 alert bg-soft-warning">
                  <div class="d-flex align-items-center">
                    <div class="text-dark">
                      Looking for other platforms? <a href="" class="text-dark fw-medium">Click Here</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </b-col>
          <b-col lg="5" class="offset-lg-1 hero-right">
            <div class="img-container" data-aos="fade-left" data-aos-duration="600">
              <img :src="desktop" alt="" />
            </div>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>
<script setup lang="ts">
import DropDown from "@/components/DropDown.vue";
import Navbar from "@/components/navbar/Navbar.vue";

import desktop from "@/assets/images/hero/desktop.jpg"
import { appName } from "@/helpers";
</script>