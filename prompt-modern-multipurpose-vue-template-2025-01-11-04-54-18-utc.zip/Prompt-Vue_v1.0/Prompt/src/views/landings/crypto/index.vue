<template>
  <Hero />
  <Coins />
  <Features />
  <Integration />
  <Stats />
  <Blog />
  <Footer />
</template>
<script setup lang="ts">
import Hero from '@/views/landings/crypto/components/Hero.vue';
import Coins from '@/views/landings/crypto/components/Coins.vue';
import Features from '@/views/landings/crypto/components/Features.vue';
import Integration from '@/views/landings/crypto/components/Integration.vue';
import Stats from '@/views/landings/crypto/components/Stats.vue';
import Blog from '@/views/landings/crypto/components/Blog.vue';
import Footer from '@/views/landings/crypto/components/Footer.vue';
</script>