<template>
    <section class="section pt-8 pb-6 bg-gradient3 position-relative" data-aos="fade-up">
        <div class="divider top d-none d-sm-block"></div>
        <b-container>
            <b-row>
                <b-col class="text-center">
                    <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Stats</b-badge>

                    <h1 class="fw-medium">{{appName}} In Numbers</h1>
                    <p class="text-muted mx-auto"></p>
                </b-col>
            </b-row>
            <b-row class="mt-5 text-center">
                <b-col cols="6" md="3" class="mb-4 mb-sm-0">
                    <div class="display-4 fw-normal">
                        {{ currency }} <Vue3autocounter ref='counter' :startAmount='10' :endAmount='50' :duration='5' /> M+
                    </div>
                    <p class="mt-2 mb-0 fw-semibold">Value transacted</p>
                    <p>in overall sell/buy transactions</p>
                </b-col>

                <b-col cols="6" md="3" class="mb-4 mb-sm-0">
                    <div class="display-4 fw-normal">2.1M+</div>
                    <p class="mt-2 mb-0 fw-semibold">Transactions Processed</p>
                    <p>across 10+ countries</p>
                </b-col>

                <b-col cols="6" md="3" class="mb-4 mb-sm-0">
                    <div class="display-4 fw-normal">2M+</div>
                    <p class="mt-2 mb-0 fw-semibold">Satisfied Processed</p>
                    <p>across 100+ locations</p>
                </b-col>

                <b-col cols="6" md="3" class="mb-4 mb-sm-0">
                    <div class="display-4 fw-normal">4.5</div>
                    <p class="mt-2 mb-0 fw-semibold">Star App Rating</p>
                    <p>on google play & apple store</p>
                </b-col>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
import { appName, currency } from '@/helpers';
import Vue3autocounter from 'vue3-autocounter';
</script>