<template>
  <div class="header-1">
    <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-primary btn-sm" />
    <section class="position-relative overflow-hidden hero-7 py-5">
      <b-container>
        <b-row class="align-items-center text-center text-sm-start">
          <b-col lg="6">
            <div class="">
              <h1 class="mt-3 mb-4 pb-2 hero-title">
                The <span class="highlight highlight-success d-inline-block">Fastest</span> & Secure way to Buy, Sell
                and Trade
                <span data-toggle="typed">
                  <Typewriter data-type='["Cryptocurrency"]' :data-period="1000" />
                </span>
              </h1>
              <p class="fs-16 text-muted">
                A seamless, flexible and diverse platform to buy, sell and manage your cryptocurrency portfolio
              </p>

              <div class="py-5">
                <b-row class="g-2 text-start">
                  <div class="col-sm-auto">
                    <label class="visually-hidden" for="email">email</label>
                    <div class="form-control-with-hint">
                      <input type="email" class="form-control" id="email" placeholder="Enter Your Email">
                      <span class="form-control-feedback uil uil-mail fs-18"></span>
                    </div>
                  </div>
                  <div class="col-sm-auto">
                    <b-button variant="primary" class="mt-1 mt-sm-0">Get Started</b-button>
                  </div>
                </b-row>
                <p class="text-muted mb-0 pt-2 fs-14">Already using {{ appName }}? <router-link
                    :to="{ name: 'auth.login' }">Log In</router-link></p>
              </div>
            </div>
          </b-col>
          <b-col lg="5" class="offset-lg-1 hero-right">
            <div class="img-container">
              <img :src="crypto" alt="" />
            </div>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import crypto from "@/assets/images/hero/crypto.jpg";
import { appName } from "@/helpers";
</script>