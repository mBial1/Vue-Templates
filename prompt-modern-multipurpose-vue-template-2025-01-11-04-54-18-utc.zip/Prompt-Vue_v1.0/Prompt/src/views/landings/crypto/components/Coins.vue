<template>
  <section class="pt-8 pb-5 position-relative overflow-hidden" data-aos="fade-up">
    <b-container>
      <b-row class="justify-content-center">
        <b-col class="text-center">
          <h1 class="fw-semibold">Supported coins</h1>
          <p class="text-muted mx-auto">
            Fastest way to buy or sell <span class="text-dark fw-medium">popular</span> crypto coins.
          </p>
        </b-col>
      </b-row>
      <b-row class="mt-3">
        <b-col lg="3" md="6" v-for="(item, idx) in coins" :key="idx">
          <div class="d-flex align-items-center py-lg-2 my-4">
            <img :src="item.image" class="icon me-3" alt="" />
            <div class="flex-grow-1">
              <h4 class="my-0 fw-medium">{{item.name}}</h4>
            </div>
          </div>
        </b-col>
      </b-row>
      <b-row class="mt-4">
        <b-col lg="12" class="mt-4 mt-lg-2 text-center">
          <a href="#" class="btn btn-primary">
            View complete list <i class="ms-2 icon icon-xs" data-feather="arrow-right"></i>
          </a>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { coins } from "@/views/landings/crypto/components/data";
</script>