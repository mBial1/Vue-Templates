<template>
  <section class="position-relative py-xl-8 py-6 features-3">
    <b-container>
      <b-row class="justify-content-center">
        <b-col class="text-center">
          <h1 class="fw-medium">Useful Reading</h1>
          <p class="text-muted mx-auto">Few articles to read to know more about cryptocurrency</p>
        </b-col>
      </b-row>
      <b-row class="mt-5">
        <b-col lg="4" v-for="(item, idx) in blogs" :key="idx">
          <div class="mb-4" data-aos="fade-up" :data-aos-duration="item.animationDuration">
            <div class="crypto-blog-box position-relative">
              <span :class="`ribbon bg-${item.variant} fw-medium`">{{ item.category }}</span>
              <img :src="item.image" alt="crypto" class="img-fluid d-block shadow rounded" />
            </div>
            <p class="text-muted mt-3 mb-0 fs-14">{{ item.date }} <b>·</b> {{ item.readTime }}</p>
            <h4 class="mt-1"><a href="#" class="text-dark">{{ item.title }}</a></h4>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { blogs } from "@/views/landings/crypto/components/data";
</script>