export type BlogType = {
  title: string,
  date: string,
  readTime: string,
  image: string,
  category: string,
  variant: string;
  animationDuration: number;
};

export type CoinType = {
  name: string;
  image: string;
};