import type { BlogType, CoinType } from "@/views/landings/crypto/components/types";

import crypto1 from "@/assets/images/blog/crypto1.jpg";
import crypto3 from "@/assets/images/blog/crypto3.jpg";
import crypto2 from "@/assets/images/blog/crypto2.jpg";

import btc from "@/assets/images/icons/coins/btc.svg";
import eth from "@/assets/images/icons/coins/eth.svg";
import usdt from "@/assets/images/icons/coins/usdt.svg";
import link from "@/assets/images/icons/coins/link.svg";
import bat from "@/assets/images/icons/coins/bat.svg";
import dash from "@/assets/images/icons/coins/dash.svg";
import bnb from "@/assets/images/icons/coins/bnb.svg";
import xtz from "@/assets/images/icons/coins/xtz.svg";

export const blogs: BlogType[] = [
  {
    title: "Introducing blazzing fast new user interface",
    date: "May 19 2020",
    readTime: "5 min read",
    image: crypto1,
    category: "Announcement",
    variant: "orange",
    animationDuration: 300
  },
  {
    title: "What you should know before buying bitcoin",
    date: "May 18 2020",
    readTime: "8 min read",
    image: crypto3,
    category: "Bitcoin",
    variant: "danger",
    animationDuration: 600
  },
  {
    title: "A biggest crypto event to attend this month",
    date: "May 13 2020",
    readTime: "2 min read",
    image: crypto2,
    category: "Event",
    variant: "primary",
    animationDuration: 900
  }
];

export const coins: CoinType[] = [
  {
    image: btc,
    name: "Bitcoin"
  },
  {
    image: eth,
    name: "Ethereum"
  },
  {
    image: usdt,
    name: "Tether"
  },
  {
    image: link,
    name: "Chainlink"
  },
  {
    image: bat,
    name: "Basic Attention Token"
  },
  {
    image: dash,
    name: "Dash"
  },
  {
    image: bnb,
    name: "Binance Coin"
  },
  {
    image: xtz,
    name: "Tezos"
  },
];