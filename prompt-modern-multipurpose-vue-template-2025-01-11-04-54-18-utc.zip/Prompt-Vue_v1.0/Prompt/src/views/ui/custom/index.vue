<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />

  <section class="py-4 bg-light">
    <b-container>
      <b-row>
        <b-col cols="12">
          <Avatars />

          <BlogItems />

          <PricingCards />

          <Gallery />

          <Icons />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Navbar from '@/components/navbar/Navbar.vue';
import Avatars from '@/views/ui/custom/components/Avatars.vue';
import BlogItems from '@/views/ui/custom/components/BlogItems.vue';
import PricingCards from '@/views/ui/custom/components/PricingCards.vue';
import Gallery from '@/views/ui/custom/components/Gallery.vue';
import Icons from '@/views/ui/custom/components/Icons.vue';

</script>