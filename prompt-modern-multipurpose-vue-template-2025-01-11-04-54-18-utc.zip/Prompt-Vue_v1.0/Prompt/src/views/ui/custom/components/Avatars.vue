<template>
  <b-row id="avatars">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Avatars</b-card-title>
          <p class="sub-header">
            Create and group avatars of different sizes and shapes with the size modifier css classes e.g.
            <code>avatar-{xl|lg|md|sm|xs}</code>. Using Bootstrap's naming convention, you can control size of
            avatar including standard avatar, or scale it up to different sizes.
          </p>

          <div class="py-4 hstack gap-1">
            <!-- Avatar Extra Large -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-xl rounded-sm shadow-sm mb-2 mb-xl-0">

            <!-- Avatar Large -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-lg rounded-sm shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Medium -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-md rounded-sm shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Small -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-sm rounded-sm shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Extra Small -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-xs rounded-sm shadow-sm ms-5 mb-2 mb-xl-0">
          </div>

          <p class="sub-header mt-4">
            Using an additional class <code>.rounded-circle</code>, you can create the rounded avatar.
          </p>

          <div class="py-4 hstack gap-1">
            <!-- Avatar Extra Large -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-xl rounded-circle shadow-sm mb-2 mb-xl-0">

            <!-- Avatar Large -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-lg rounded-circle shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Medium -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-md rounded-circle shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Small -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-sm rounded-circle shadow-sm ms-5 mb-2 mb-xl-0">

            <!-- Avatar Extra Small -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-xs rounded-circle shadow-sm ms-5 mb-2 mb-xl-0">
          </div>

          <p class="sub-header mt-4">
            Using an additional class <code>.avatar-border</code>, you can give a nice border.
          </p>

          <div class="py-3">
            <!-- Avatar Large -->
            <img src="@/assets/images/avatars/img-7.jpg" alt="img"
              class="img-fluid avatar-lg rounded-circle avatar-border">
          </div>

          <p class="sub-header mt-4">
            Wrap the list of avatars with class <code>.avatar-group</code> to group and show multiple avatars.
          </p>
          <div class="avatar-group">
            <a href="#" class="avatar-group-item">
              <img src="@/assets/images/avatars/img-7.jpg" alt="img"
                class="img-fluid avatar-xs rounded-circle avatar-border" />
            </a>
            <a href="#" class="avatar-group-item">
              <img src="@/assets/images/avatars/img-2.jpg" alt="img"
                class="img-fluid avatar-xs rounded-circle avatar-border" />
            </a>
            <a href="#" class="avatar-group-item">
              <img src="@/assets/images/avatars/img-4.jpg" alt="img"
                class="img-fluid avatar-xs rounded-circle avatar-border" />
            </a>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>