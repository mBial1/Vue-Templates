<template>
  <b-row id="gallery">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Gallery</b-card-title>
          <p class="sub-header">
            Using <a href="https://github.com/dimsemenov/Magnific-Popup/">Magnific Popup</a> plugin, you can
            easily create a gallery of images, videos or other custom items.
            It's a fast, light and responsive lightbox plugin, for jQuery and Zepto.js.
          </p>

          <h6 class="mt-4 mb-1">Simple Example</h6>
          <p class="sub-header mb-4">Just specify data attribute <code>data-toggle="image-gallery"</code> to any
            div element containing your gallery items to enabled it.</p>

          <div data-toggle="image-gallery" data-delegate="a" data-type="image" data-enable-gallery="true">
            <b-row>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/3.jpg" data-title="A lavish inside style">
                  <b-card no-body>
                    <img src="@/assets/images/photos/3.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/4.jpg" data-title="Another inside view">
                  <b-card no-body>
                    <img src="@/assets/images/photos/4.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/1.jpg" data-title="Spacious sitting arrangement">
                  <b-card no-body>
                    <img src="@/assets/images/photos/1.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/2.jpg" data-title="A lavish outside view">
                  <b-card no-body>
                    <img src="@/assets/images/photos/2.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/10.jpg" data-title="Kitchen">
                  <b-card no-body>
                    <img src="@/assets/images/photos/10.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
              <b-col lg="4" cols="6">
                <a href="assets/images/photos/5.jpg" data-title="Lavish styled bedroom">
                  <b-card no-body>
                    <img src="@/assets/images/photos/5.jpg" alt="" class="img-fluid rounded-sm shadow">
                  </b-card>
                </a>
              </b-col>
            </b-row>
          </div>

          <div data-toggle="image-gallery" data-delegate="a" data-type="image" data-enable-gallery="true">
            <b-row>
              <b-col lg="5">
                <b-card no-body class="border-0 shadow-none overflow-hidden rounded">
                  <a href="assets/images/photos/9.jpg">
                    <img src="@/assets/images/photos/11.jpg" alt="" class="img-fluid mx-auto d-block rounded-sm">
                  </a>
                </b-card>
              </b-col>
              <b-col lg="7">
                <b-row>
                  <b-col md="6">
                    <div class="gallery-box card border-0 shadow overflow-hidden rounded-sm">
                      <a href="assets/images/photos/5.jpg">
                        <img src="@/assets/images/photos/5.jpg" alt="" class="img-fluid mx-auto d-block">
                      </a>
                    </div>
                    <div class="gallery-box card border-0 shadow overflow-hidden rounded-sm">
                      <a href="assets/images/photos/7.jpg">
                        <img src="@/assets/images/photos/7.jpg" alt="" class="img-fluid mx-auto d-block">
                      </a>
                    </div>
                  </b-col>
                  <!-- Col End -->
                  <b-col md="6">
                    <div class="gallery-box card border-0 shadow overflow-hidden rounded-sm">
                      <a href="assets/images/photos/8.jpg">
                        <img src="@/assets/images/photos/8.jpg" alt="" class="img-fluid mx-auto d-block">
                      </a>
                    </div>

                    <div class="gallery-box card border-0 shadow overflow-hidden rounded-sm">
                      <a href="assets/images/photos/10.jpg">
                        <img src="@/assets/images/photos/10.jpg" alt="" class="img-fluid mx-auto d-block">
                      </a>
                    </div>
                  </b-col>
                  <!-- Col End -->
                </b-row>
                <!-- Row End -->
              </b-col>
            </b-row>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>