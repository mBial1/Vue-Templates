<template>
  <b-row id="icons">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Icons</b-card-title>
          <p class="sub-header">
            Prompt comes with two icon libraries:
            <a href="https://feathericons.com/">Feather Icons</a>
            and premium svg based two tones icons.
          </p>

          <b-row class="mt-3">
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Compiling</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Compiling" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M2.56066017,10.6819805 L4.68198052,8.56066017 C5.26776695,7.97487373 6.21751442,7.97487373 6.80330086,8.56066017 L8.9246212,10.6819805 C9.51040764,11.267767 9.51040764,12.2175144 8.9246212,12.8033009 L6.80330086,14.9246212 C6.21751442,15.5104076 5.26776695,15.5104076 4.68198052,14.9246212 L2.56066017,12.8033009 C1.97487373,12.2175144 1.97487373,11.267767 2.56066017,10.6819805 Z M14.5606602,10.6819805 L16.6819805,8.56066017 C17.267767,7.97487373 18.2175144,7.97487373 18.8033009,8.56066017 L20.9246212,10.6819805 C21.5104076,11.267767 21.5104076,12.2175144 20.9246212,12.8033009 L18.8033009,14.9246212 C18.2175144,15.5104076 17.267767,15.5104076 16.6819805,14.9246212 L14.5606602,12.8033009 C13.9748737,12.2175144 13.9748737,11.267767 14.5606602,10.6819805 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    <path
                      d="M8.56066017,16.6819805 L10.6819805,14.5606602 C11.267767,13.9748737 12.2175144,13.9748737 12.8033009,14.5606602 L14.9246212,16.6819805 C15.5104076,17.267767 15.5104076,18.2175144 14.9246212,18.8033009 L12.8033009,20.9246212 C12.2175144,21.5104076 11.267767,21.5104076 10.6819805,20.9246212 L8.56066017,18.8033009 C7.97487373,18.2175144 7.97487373,17.267767 8.56066017,16.6819805 Z M8.56066017,4.68198052 L10.6819805,2.56066017 C11.267767,1.97487373 12.2175144,1.97487373 12.8033009,2.56066017 L14.9246212,4.68198052 C15.5104076,5.26776695 15.5104076,6.21751442 14.9246212,6.80330086 L12.8033009,8.9246212 C12.2175144,9.51040764 11.267767,9.51040764 10.6819805,8.9246212 L8.56066017,6.80330086 C7.97487373,6.21751442 7.97487373,5.26776695 8.56066017,4.68198052 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Git#4</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Git#4" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="Rectangle-5" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M6,7 C7.1045695,7 8,6.1045695 8,5 C8,3.8954305 7.1045695,3 6,3 C4.8954305,3 4,3.8954305 4,5 C4,6.1045695 4.8954305,7 6,7 Z M6,9 C3.790861,9 2,7.209139 2,5 C2,2.790861 3.790861,1 6,1 C8.209139,1 10,2.790861 10,5 C10,7.209139 8.209139,9 6,9 Z"
                      id="Oval-7" fill="#335EEA"></path>
                    <path
                      d="M7,11.4648712 L7,17 C7,18.1045695 7.8954305,19 9,19 L15,19 L15,21 L9,21 C6.790861,21 5,19.209139 5,17 L5,8 L5,7 L7,7 L7,8 C7,9.1045695 7.8954305,10 9,10 L15,10 L15,12 L9,12 C8.27142571,12 7.58834673,11.8052114 7,11.4648712 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    <path
                      d="M18,22 C19.1045695,22 20,21.1045695 20,20 C20,18.8954305 19.1045695,18 18,18 C16.8954305,18 16,18.8954305 16,20 C16,21.1045695 16.8954305,22 18,22 Z M18,24 C15.790861,24 14,22.209139 14,20 C14,17.790861 15.790861,16 18,16 C20.209139,16 22,17.790861 22,20 C22,22.209139 20.209139,24 18,24 Z"
                      id="Oval-7-Copy" fill="#335EEA"></path>
                    <path
                      d="M18,13 C19.1045695,13 20,12.1045695 20,11 C20,9.8954305 19.1045695,9 18,9 C16.8954305,9 16,9.8954305 16,11 C16,12.1045695 16.8954305,13 18,13 Z M18,15 C15.790861,15 14,13.209139 14,11 C14,8.790861 15.790861,7 18,7 C20.209139,7 22,8.790861 22,11 C22,13.209139 20.209139,15 18,15 Z"
                      id="Oval-7-Copy-3" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Github</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Github" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="Rectangle-5" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M16.5428932,17.4571068 L11,11.9142136 L11,4 C11,3.44771525 11.4477153,3 12,3 C12.5522847,3 13,3.44771525 13,4 L13,11.0857864 L17.9571068,16.0428932 L20.1464466,13.8535534 C20.3417088,13.6582912 20.6582912,13.6582912 20.8535534,13.8535534 C20.9473216,13.9473216 21,14.0744985 21,14.2071068 L21,19.5 C21,19.7761424 20.7761424,20 20.5,20 L15.2071068,20 C14.9309644,20 14.7071068,19.7761424 14.7071068,19.5 C14.7071068,19.3673918 14.7597852,19.2402148 14.8535534,19.1464466 L16.5428932,17.4571068 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                    <path
                      d="M7.24478854,17.1447885 L9.2464466,19.1464466 C9.34021479,19.2402148 9.39289321,19.3673918 9.39289321,19.5 C9.39289321,19.7761424 9.16903559,20 8.89289321,20 L3.52893218,20 C3.25278981,20 3.02893218,19.7761424 3.02893218,19.5 L3.02893218,14.136039 C3.02893218,14.0034307 3.0816106,13.8762538 3.17537879,13.7824856 C3.37064094,13.5872234 3.68722343,13.5872234 3.88248557,13.7824856 L5.82567301,15.725673 L8.85405776,13.1631936 L10.1459422,14.6899662 L7.24478854,17.1447885 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Plus</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Plus" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <circle id="Oval-5" fill="#335EEA" opacity="0.3" cx="12" cy="12" r="10"></circle>
                    <path
                      d="M11,11 L11,7 C11,6.44771525 11.4477153,6 12,6 C12.5522847,6 13,6.44771525 13,7 L13,11 L17,11 C17.5522847,11 18,11.4477153 18,12 C18,12.5522847 17.5522847,13 17,13 L13,13 L13,17 C13,17.5522847 12.5522847,18 12,18 C11.4477153,18 11,17.5522847 11,17 L11,13 L7,13 C6.44771525,13 6,12.5522847 6,12 C6,11.4477153 6.44771525,11 7,11 L11,11 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Settings#4</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Settings#4" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M18.6225,9.75 L18.75,9.75 C19.9926407,9.75 21,10.7573593 21,12 C21,13.2426407 19.9926407,14.25 18.75,14.25 L18.6854912,14.249994 C18.4911876,14.250769 18.3158978,14.366855 18.2393549,14.5454486 C18.1556809,14.7351461 18.1942911,14.948087 18.3278301,15.0846699 L18.372535,15.129375 C18.7950334,15.5514036 19.03243,16.1240792 19.03243,16.72125 C19.03243,17.3184208 18.7950334,17.8910964 18.373125,18.312535 C17.9510964,18.7350334 17.3784208,18.97243 16.78125,18.97243 C16.1840792,18.97243 15.6114036,18.7350334 15.1896699,18.3128301 L15.1505513,18.2736469 C15.008087,18.1342911 14.7951461,18.0956809 14.6054486,18.1793549 C14.426855,18.2558978 14.310769,18.4311876 14.31,18.6225 L14.31,18.75 C14.31,19.9926407 13.3026407,21 12.06,21 C10.8173593,21 9.81,19.9926407 9.81,18.75 C9.80552409,18.4999185 9.67898539,18.3229986 9.44717599,18.2361469 C9.26485393,18.1556809 9.05191298,18.1942911 8.91533009,18.3278301 L8.870625,18.372535 C8.44859642,18.7950334 7.87592081,19.03243 7.27875,19.03243 C6.68157919,19.03243 6.10890358,18.7950334 5.68746499,18.373125 C5.26496665,17.9510964 5.02757002,17.3784208 5.02757002,16.78125 C5.02757002,16.1840792 5.26496665,15.6114036 5.68716991,15.1896699 L5.72635306,15.1505513 C5.86570889,15.008087 5.90431906,14.7951461 5.82064513,14.6054486 C5.74410223,14.426855 5.56881236,14.310769 5.3775,14.31 L5.25,14.31 C4.00735931,14.31 3,13.3026407 3,12.06 C3,10.8173593 4.00735931,9.81 5.25,9.81 C5.50008154,9.80552409 5.67700139,9.67898539 5.76385306,9.44717599 C5.84431906,9.26485393 5.80570889,9.05191298 5.67216991,8.91533009 L5.62746499,8.870625 C5.20496665,8.44859642 4.96757002,7.87592081 4.96757002,7.27875 C4.96757002,6.68157919 5.20496665,6.10890358 5.626875,5.68746499 C6.04890358,5.26496665 6.62157919,5.02757002 7.21875,5.02757002 C7.81592081,5.02757002 8.38859642,5.26496665 8.81033009,5.68716991 L8.84944872,5.72635306 C8.99191298,5.86570889 9.20485393,5.90431906 9.38717599,5.82385306 L9.49484664,5.80114977 C9.65041313,5.71688974 9.7492905,5.55401473 9.75,5.3775 L9.75,5.25 C9.75,4.00735931 10.7573593,3 12,3 C13.2426407,3 14.25,4.00735931 14.25,5.25 L14.249994,5.31450877 C14.250769,5.50881236 14.366855,5.68410223 14.552824,5.76385306 C14.7351461,5.84431906 14.948087,5.80570889 15.0846699,5.67216991 L15.129375,5.62746499 C15.5514036,5.20496665 16.1240792,4.96757002 16.72125,4.96757002 C17.3184208,4.96757002 17.8910964,5.20496665 18.312535,5.626875 C18.7350334,6.04890358 18.97243,6.62157919 18.97243,7.21875 C18.97243,7.81592081 18.7350334,8.38859642 18.3128301,8.81033009 L18.2736469,8.84944872 C18.1342911,8.99191298 18.0956809,9.20485393 18.1761469,9.38717599 L18.1988502,9.49484664 C18.2831103,9.65041313 18.4459853,9.7492905 18.6225,9.75 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    <path
                      d="M12,15 C13.6568542,15 15,13.6568542 15,12 C15,10.3431458 13.6568542,9 12,9 C10.3431458,9 9,10.3431458 9,12 C9,13.6568542 10.3431458,15 12,15 Z"
                      id="Path" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Code / Terminal</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Code-/-Terminal" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                    <path
                      d="M3.70710678,15.7071068 C3.31658249,16.0976311 2.68341751,16.0976311 2.29289322,15.7071068 C1.90236893,15.3165825 1.90236893,14.6834175 2.29289322,14.2928932 L8.29289322,8.29289322 C8.67147216,7.91431428 9.28105859,7.90106866 9.67572463,8.26284586 L15.6757246,13.7628459 C16.0828436,14.1360383 16.1103465,14.7686056 15.7371541,15.1757246 C15.3639617,15.5828436 14.7313944,15.6103465 14.3242754,15.2371541 L9.03007575,10.3841378 L3.70710678,15.7071068 Z"
                      id="Path-94" fill="#335EEA"
                      transform="translate(9.000003, 11.999999) rotate(-270.000000) translate(-9.000003, -11.999999) ">
                    </path>
                    <rect id="Rectangle" fill="#335EEA" opacity="0.3" x="12" y="17" width="10" height="2" rx="1"></rect>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Address-card</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Address-card" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M6,2 L18,2 C19.6568542,2 21,3.34314575 21,5 L21,19 C21,20.6568542 19.6568542,22 18,22 L6,22 C4.34314575,22 3,20.6568542 3,19 L3,5 C3,3.34314575 4.34314575,2 6,2 Z M12,11 C13.1045695,11 14,10.1045695 14,9 C14,7.8954305 13.1045695,7 12,7 C10.8954305,7 10,7.8954305 10,9 C10,10.1045695 10.8954305,11 12,11 Z M7.00036205,16.4995035 C6.98863236,16.6619875 7.26484009,17 7.4041679,17 C11.463736,17 14.5228466,17 16.5815,17 C16.9988413,17 17.0053266,16.6221713 16.9988413,16.5 C16.8360465,13.4332455 14.6506758,12 11.9907452,12 C9.36772908,12 7.21569918,13.5165724 7.00036205,16.4995035 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Call#1</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Call#1" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M11.914857,14.1427403 L14.1188827,11.9387145 C14.7276032,11.329994 14.8785122,10.4000511 14.4935235,9.63007378 L14.3686433,9.38031323 C13.9836546,8.61033591 14.1345636,7.680393 14.7432841,7.07167248 L17.4760882,4.33886839 C17.6713503,4.14360624 17.9879328,4.14360624 18.183195,4.33886839 C18.2211956,4.37686904 18.2528214,4.42074752 18.2768552,4.46881498 L19.3808309,6.67676638 C20.2253855,8.3658756 19.8943345,10.4059034 18.5589765,11.7412615 L12.560151,17.740087 C11.1066115,19.1936265 8.95659008,19.7011777 7.00646221,19.0511351 L4.5919826,18.2463085 C4.33001094,18.1589846 4.18843095,17.8758246 4.27575484,17.613853 C4.30030124,17.5402138 4.34165566,17.4733009 4.39654309,17.4184135 L7.04781491,14.7671417 C7.65653544,14.1584211 8.58647835,14.0075122 9.35645567,14.3925008 L9.60621621,14.5173811 C10.3761935,14.9023698 11.3061364,14.7514608 11.914857,14.1427403 Z"
                      id="Path-76" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Chat#1</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Chat#1" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <polygon id="Path-75" fill="#335EEA" opacity="0.3" points="5 15 3 21.5 9.5 19.5"></polygon>
                    <path
                      d="M13.5,21 C8.25329488,21 4,16.7467051 4,11.5 C4,6.25329488 8.25329488,2 13.5,2 C18.7467051,2 23,6.25329488 23,11.5 C23,16.7467051 18.7467051,21 13.5,21 Z M8.5,13 C9.32842712,13 10,12.3284271 10,11.5 C10,10.6715729 9.32842712,10 8.5,10 C7.67157288,10 7,10.6715729 7,11.5 C7,12.3284271 7.67157288,13 8.5,13 Z M13.5,13 C14.3284271,13 15,12.3284271 15,11.5 C15,10.6715729 14.3284271,10 13.5,10 C12.6715729,10 12,10.6715729 12,11.5 C12,12.3284271 12.6715729,13 13.5,13 Z M18.5,13 C19.3284271,13 20,12.3284271 20,11.5 C20,10.6715729 19.3284271,10 18.5,10 C17.6715729,10 17,10.6715729 17,11.5 C17,12.3284271 17.6715729,13 18.5,13 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Clipboard-list</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Clipboard-list" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    <path
                      d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                    <rect id="Rectangle-152" fill="#335EEA" opacity="0.3" x="10" y="9" width="7" height="2" rx="1">
                    </rect>
                    <rect id="Rectangle-152-Copy-2" fill="#335EEA" opacity="0.3" x="7" y="9" width="2" height="2"
                      rx="1"></rect>
                    <rect id="Rectangle-152-Copy-3" fill="#335EEA" opacity="0.3" x="7" y="13" width="2" height="2"
                      rx="1"></rect>
                    <rect id="Rectangle-152-Copy" fill="#335EEA" opacity="0.3" x="10" y="13" width="7" height="2"
                      rx="1"></rect>
                    <rect id="Rectangle-152-Copy-5" fill="#335EEA" opacity="0.3" x="7" y="17" width="2" height="2"
                      rx="1"></rect>
                    <rect id="Rectangle-152-Copy-4" fill="#335EEA" opacity="0.3" x="10" y="17" width="7" height="2"
                      rx="1"></rect>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Group-chat</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Group-chat" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M16,15.6315789 L16,12 C16,10.3431458 14.6568542,9 13,9 L6.16183229,9 L6.16183229,5.52631579 C6.16183229,4.13107011 7.29290239,3 8.68814808,3 L20.4776218,3 C21.8728674,3 23.0039375,4.13107011 23.0039375,5.52631579 L23.0039375,13.1052632 L23.0206157,17.786793 C23.0215995,18.0629336 22.7985408,18.2875874 22.5224001,18.2885711 C22.3891754,18.2890457 22.2612702,18.2363324 22.1670655,18.1421277 L19.6565168,15.6315789 L16,15.6315789 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                    <path
                      d="M1.98505595,18 L1.98505595,13 C1.98505595,11.8954305 2.88048645,11 3.98505595,11 L11.9850559,11 C13.0896254,11 13.9850559,11.8954305 13.9850559,13 L13.9850559,18 C13.9850559,19.1045695 13.0896254,20 11.9850559,20 L4.10078614,20 L2.85693427,21.1905292 C2.65744295,21.3814685 2.34093638,21.3745358 2.14999706,21.1750444 C2.06092565,21.0819836 2.01120804,20.958136 2.01120804,20.8293182 L2.01120804,18.32426 C1.99400175,18.2187196 1.98505595,18.1104045 1.98505595,18 Z M6.5,14 C6.22385763,14 6,14.2238576 6,14.5 C6,14.7761424 6.22385763,15 6.5,15 L11.5,15 C11.7761424,15 12,14.7761424 12,14.5 C12,14.2238576 11.7761424,14 11.5,14 L6.5,14 Z M9.5,16 C9.22385763,16 9,16.2238576 9,16.5 C9,16.7761424 9.22385763,17 9.5,17 L11.5,17 C11.7761424,17 12,16.7761424 12,16.5 C12,16.2238576 11.7761424,16 11.5,16 L9.5,16 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                  </g>
                </svg>
              </span>
            </div>
            <div class="col-auto">
              <span class="icon icon-sm">
                <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink">
                  <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                  <title>Stockholm-icons / Communication / Mail-heart</title>
                  <desc>Created with Sketch.</desc>
                  <g id="Stockholm-icons-/-Communication-/-Mail-heart" stroke="none" stroke-width="1" fill="none"
                    fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M6,2 L18,2 C18.5522847,2 19,2.44771525 19,3 L19,13 C19,13.5522847 18.5522847,14 18,14 L6,14 C5.44771525,14 5,13.5522847 5,13 L5,3 C5,2.44771525 5.44771525,2 6,2 Z M13.8,4 C13.1562,4 12.4033,4.72985286 12,5.2 C11.5967,4.72985286 10.8438,4 10.2,4 C9.0604,4 8.4,4.88887193 8.4,6.02016349 C8.4,7.27338783 9.6,8.6 12,10 C14.4,8.6 15.6,7.3 15.6,6.1 C15.6,4.96870845 14.9396,4 13.8,4 Z"
                      id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    <path
                      d="M3.79274528,6.57253826 L12,12.5 L20.2072547,6.57253826 C20.4311176,6.4108595 20.7436609,6.46126971 20.9053396,6.68513259 C20.9668779,6.77033951 21,6.87277228 21,6.97787787 L21,17 C21,18.1045695 20.1045695,19 19,19 L5,19 C3.8954305,19 3,18.1045695 3,17 L3,6.97787787 C3,6.70173549 3.22385763,6.47787787 3.5,6.47787787 C3.60510559,6.47787787 3.70753836,6.51099993 3.79274528,6.57253826 Z"
                      id="Combined-Shape" fill="#335EEA"></path>
                  </g>
                </svg>
              </span>
            </div>
          </b-row>

          <p class="pt-4">
            You can check out all the available icons in folder
            <code class="fw-semibold">/src/assets/images/icons/duotone-icons</code> folder.
          </p>

          <!-- colors -->
          <div class="mt-5">
            <h5 class="mb-1">Colors</h5>
            <p class="">
              Use text modifier class
              <code>.text-*</code> to style the icon.
              E.g. <code>text-{primary|secondary|success|danger|info|warning}.</code>
            </p>

            <b-row>
              <div class="col-auto">
                <span class="icon icon-sm text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / Communication / Mail-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Mail-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M6,2 L18,2 C18.5522847,2 19,2.44771525 19,3 L19,13 C19,13.5522847 18.5522847,14 18,14 L6,14 C5.44771525,14 5,13.5522847 5,13 L5,3 C5,2.44771525 5.44771525,2 6,2 Z M13.8,4 C13.1562,4 12.4033,4.72985286 12,5.2 C11.5967,4.72985286 10.8438,4 10.2,4 C9.0604,4 8.4,4.88887193 8.4,6.02016349 C8.4,7.27338783 9.6,8.6 12,10 C14.4,8.6 15.6,7.3 15.6,6.1 C15.6,4.96870845 14.9396,4 13.8,4 Z"
                        id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M3.79274528,6.57253826 L12,12.5 L20.2072547,6.57253826 C20.4311176,6.4108595 20.7436609,6.46126971 20.9053396,6.68513259 C20.9668779,6.77033951 21,6.87277228 21,6.97787787 L21,17 C21,18.1045695 20.1045695,19 19,19 L5,19 C3.8954305,19 3,18.1045695 3,17 L3,6.97787787 C3,6.70173549 3.22385763,6.47787787 3.5,6.47787787 C3.60510559,6.47787787 3.70753836,6.51099993 3.79274528,6.57253826 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-sm text-secondary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / Communication / Call#1</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Call#1" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M11.914857,14.1427403 L14.1188827,11.9387145 C14.7276032,11.329994 14.8785122,10.4000511 14.4935235,9.63007378 L14.3686433,9.38031323 C13.9836546,8.61033591 14.1345636,7.680393 14.7432841,7.07167248 L17.4760882,4.33886839 C17.6713503,4.14360624 17.9879328,4.14360624 18.183195,4.33886839 C18.2211956,4.37686904 18.2528214,4.42074752 18.2768552,4.46881498 L19.3808309,6.67676638 C20.2253855,8.3658756 19.8943345,10.4059034 18.5589765,11.7412615 L12.560151,17.740087 C11.1066115,19.1936265 8.95659008,19.7011777 7.00646221,19.0511351 L4.5919826,18.2463085 C4.33001094,18.1589846 4.18843095,17.8758246 4.27575484,17.613853 C4.30030124,17.5402138 4.34165566,17.4733009 4.39654309,17.4184135 L7.04781491,14.7671417 C7.65653544,14.1584211 8.58647835,14.0075122 9.35645567,14.3925008 L9.60621621,14.5173811 C10.3761935,14.9023698 11.3061364,14.7514608 11.914857,14.1427403 Z"
                        id="Path-76" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-sm text-success">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / Communication / Chat#1</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Chat#1" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <polygon id="Path-75" fill="#335EEA" opacity="0.3" points="5 15 3 21.5 9.5 19.5"></polygon>
                      <path
                        d="M13.5,21 C8.25329488,21 4,16.7467051 4,11.5 C4,6.25329488 8.25329488,2 13.5,2 C18.7467051,2 23,6.25329488 23,11.5 C23,16.7467051 18.7467051,21 13.5,21 Z M8.5,13 C9.32842712,13 10,12.3284271 10,11.5 C10,10.6715729 9.32842712,10 8.5,10 C7.67157288,10 7,10.6715729 7,11.5 C7,12.3284271 7.67157288,13 8.5,13 Z M13.5,13 C14.3284271,13 15,12.3284271 15,11.5 C15,10.6715729 14.3284271,10 13.5,10 C12.6715729,10 12,10.6715729 12,11.5 C12,12.3284271 12.6715729,13 13.5,13 Z M18.5,13 C19.3284271,13 20,12.3284271 20,11.5 C20,10.6715729 19.3284271,10 18.5,10 C17.6715729,10 17,10.6715729 17,11.5 C17,12.3284271 17.6715729,13 18.5,13 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-sm text-danger">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / Communication / Clipboard-list</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Clipboard-list" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z"
                        id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                      <rect id="Rectangle-152" fill="#335EEA" opacity="0.3" x="10" y="9" width="7" height="2" rx="1">
                      </rect>
                      <rect id="Rectangle-152-Copy-2" fill="#335EEA" opacity="0.3" x="7" y="9" width="2" height="2"
                        rx="1"></rect>
                      <rect id="Rectangle-152-Copy-3" fill="#335EEA" opacity="0.3" x="7" y="13" width="2" height="2"
                        rx="1"></rect>
                      <rect id="Rectangle-152-Copy" fill="#335EEA" opacity="0.3" x="10" y="13" width="7" height="2"
                        rx="1"></rect>
                      <rect id="Rectangle-152-Copy-5" fill="#335EEA" opacity="0.3" x="7" y="17" width="2" height="2"
                        rx="1"></rect>
                      <rect id="Rectangle-152-Copy-4" fill="#335EEA" opacity="0.3" x="10" y="17" width="7" height="2"
                        rx="1"></rect>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-sm text-info">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / Communication / Group-chat</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Group-chat" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M16,15.6315789 L16,12 C16,10.3431458 14.6568542,9 13,9 L6.16183229,9 L6.16183229,5.52631579 C6.16183229,4.13107011 7.29290239,3 8.68814808,3 L20.4776218,3 C21.8728674,3 23.0039375,4.13107011 23.0039375,5.52631579 L23.0039375,13.1052632 L23.0206157,17.786793 C23.0215995,18.0629336 22.7985408,18.2875874 22.5224001,18.2885711 C22.3891754,18.2890457 22.2612702,18.2363324 22.1670655,18.1421277 L19.6565168,15.6315789 L16,15.6315789 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                      <path
                        d="M1.98505595,18 L1.98505595,13 C1.98505595,11.8954305 2.88048645,11 3.98505595,11 L11.9850559,11 C13.0896254,11 13.9850559,11.8954305 13.9850559,13 L13.9850559,18 C13.9850559,19.1045695 13.0896254,20 11.9850559,20 L4.10078614,20 L2.85693427,21.1905292 C2.65744295,21.3814685 2.34093638,21.3745358 2.14999706,21.1750444 C2.06092565,21.0819836 2.01120804,20.958136 2.01120804,20.8293182 L2.01120804,18.32426 C1.99400175,18.2187196 1.98505595,18.1104045 1.98505595,18 Z M6.5,14 C6.22385763,14 6,14.2238576 6,14.5 C6,14.7761424 6.22385763,15 6.5,15 L11.5,15 C11.7761424,15 12,14.7761424 12,14.5 C12,14.2238576 11.7761424,14 11.5,14 L6.5,14 Z M9.5,16 C9.22385763,16 9,16.2238576 9,16.5 C9,16.7761424 9.22385763,17 9.5,17 L11.5,17 C11.7761424,17 12,16.7761424 12,16.5 C12,16.2238576 11.7761424,16 11.5,16 L9.5,16 Z"
                        id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                    </g>
                  </svg>
                </span>
              </div>
            </b-row>
          </div>
          <!-- colors end -->

          <!-- sizes start -->
          <div class="mt-5">
            <h5 class="mb-1">Sizes</h5>
            <p class="">
              Use size modifier class
              <code>.icon-{xxs|xs|sm|md|lg|xl|xxl}</code> to change the size.
            </p>

            <b-row>
              <div class="col-auto">
                <span class="icon icon-xxl text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-xl text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-lg text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-md text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-sm text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-xs text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
              <div class="col-auto">
                <span class="icon icon-xxs text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <!-- Generator: Sketch 52.2 (67145) - http://www.bohemiancoding.com/sketch -->
                    <title>Stockholm-icons / General / Half-heart</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-General-/-Half-heart" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M16.5,4.5 C14.8905,4.5 13.00825,6.32463215 12,7.5 C10.99175,6.32463215 9.1095,4.5 7.5,4.5 C4.651,4.5 3,6.72217984 3,9.55040872 C3,12.6834696 6,16 12,19.5 C18,16 21,12.75 21,9.75 C21,6.92177112 19.349,4.5 16.5,4.5 Z"
                        id="Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M12,19.5 C6,16 3,12.6834696 3,9.55040872 C3,6.72217984 4.651,4.5 7.5,4.5 C9.1095,4.5 10.99175,6.32463215 12,7.5 L12,19.5 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
              </div>
            </b-row>
          </div>
          <!-- sizes end -->


          <div class="my-5"></div>
          <h5>Feather Icons</h5>
          <p class="sub-header">
            Feather is a collection of simply beautiful svg based open source icons. Each icon is designed with
            an emphasis on simplicity, consistency, and flexibility.
            To use an icon on your page, add a <code>data-feather</code> attribute with the icon name to an
            element.
          </p>

          <b-row class="pt-3">
            <div class="col-md-auto hstack gap-1">
              <i data-feather="activity" class="me-2"></i>
              <i data-feather="shopping-bag" class="me-2"></i>
              <i data-feather="credit-card" class="me-2"></i>
              <i data-feather="message-square" class="me-2"></i>
              <i data-feather="map-pin" class="me-2"></i>
              <i data-feather="bell" class="me-2"></i>
              <i data-feather="calendar" class="me-2"></i>
              <i data-feather="map"></i>
            </div>
          </b-row>
          <p class="sub-header mt-4">
            For a complete list of icons, check
            <a href="https://feathericons.com/" class="text-primary">here</a>.
          </p>

          <p class="sub-header mt-4">
            Use modifier class <code>.icon-dual</code> to convert it into two-tone. All the color variations are
            available as well. E.g. <code>icon-dual-{primary|secondary|success|danger|info|warning}.</code>
          </p>

          <b-row>
            <div class="col-auto hstack gap-1">
              <i data-feather="activity" class="icon-dual me-2"></i>
              <i data-feather="shopping-bag" class="icon-dual-primary me-2"></i>
              <i data-feather="credit-card" class="icon-dual-secondary me-2"></i>
              <i data-feather="message-square" class="icon-dual-success me-2"></i>
              <i data-feather="map-pin" class="icon-dual-danger me-2"></i>
              <i data-feather="bell" class="icon-dual-info me-2"></i>
              <i data-feather="calendar" class="icon-dual-warning"></i>
            </div>
          </b-row>

          <p class="sub-header mt-4">
            Use size modifier class <code>.icon-{xxs|xs|sm|md|lg|xl|xxl}</code> to change the size.
          </p>

          <b-row>
            <div class="col-auto hstack gap-1">
              <i data-feather="message-circle" class="icon-xxl me-2"></i>
              <i data-feather="message-circle" class="icon-xl me-2"></i>
              <i data-feather="message-circle" class="icon-lg me-2"></i>
              <i data-feather="message-circle" class="icon-md me-2"></i>
              <i data-feather="message-circle" class="icon-sm me-2"></i>
              <i data-feather="message-circle" class="icon-xs me-2"></i>
              <i data-feather="message-circle" class="icon-xxs me-2"></i>
            </div>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>