<template>
  <b-row id="blog-cards">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="b-card-title mb-0">Blog Items</b-card-title>
          <p class="sub-header">
            Using bootstrap's <code>.card</code>, you can create a card holding blog post.
          </p>

          <b-row>
            <b-col lg="6" xl="4">
              <b-card no-body class="card-listing-item">
                <div class="card-img-top-overlay">
                  <div class="overlay"></div>
                  <span class="card-badge top-right bg-danger text-white">Travel</span>

                  <div class="position-relative">
                    <img src="@/assets/images/photos/2.jpg" alt="" class="card-img-top" />

                    <div class="shape text-white bottom">
                      <svg width="528px" height="40px" viewBox="0 0 528 40" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g id="shape" transform="matrix(-1.138336E-07 -1 1 -1.138336E-07 0 39.92764)"><path d="M0 0L40.5467 0C40.5467 0 -31.8215 230.87 38.7134 528.217C39.8794 533.133 31.7549 527.502 31.0925 528.75C28.7914 533.084 26.1543 528.191 24.4327 529.178C59.2372 539.206 14.0091 521.981 12.9329 530.001L1.02722 528.284L0 0Z" transform="translate(7.629395E-06 6.103516E-05)" fill="currentColor" stroke="none" /></g></svg>
                    </div>
                  </div>
                </div>
                <b-card-body>
                  <div class="">
                    <h4><a href="#" class="card-title-link">Top 10 must visit best beaches of Goa</a></h4>
                    <p class="text-muted mb-2">
                      Goa and its beaches do not need an introduction! The state is well known for its
                      spectacular beaches and it is very difficult...<a href="#">read more</a>
                    </p>
                  </div>
                  <div class="pt-3">
                    <b-row class="align-items-center">
                      <div class="col-auto">
                        <p class="mb-0">
                          <i data-feather="user" class="icon icon-dual icon-xs"></i>
                          <a href="#" class="fs-14 align-middle">Emily Blunt</a>
                        </p>
                      </div>
                      <div class="col text-end">
                        <p class="mb-0">
                          <i data-feather="calendar" class="icon icon-dual icon-xs"></i>
                          <span class="fs-14 align-middle">11 March, 2020</span>
                        </p>
                      </div>
                    </b-row>
                  </div>
                </b-card-body>
              </b-card>
            </b-col>

            <b-col lg="6" xl="4" class="offset-xl-2">
              <b-card no-body class="card-listing-item">
                <div class="card-img-top-overlay">
                  <div class="overlay"></div>
                  <span class="card-badge top-right bg-primary text-white">Travel</span>
                  <img src="@/assets/images/photos/2.jpg" alt="" class="card-img-top" />

                  <div class="card-overlay-bottom">
                    <a href="#" class="shadow-lg">
                      <img src="@/assets/images/avatars/img-7.jpg" alt="img"
                        class="img-fluid avatar-xs rounded-circle avatar-border me-1" />
                      <h6 class="d-inline text-white">Emily Blunt</h6>
                    </a>
                  </div>
                </div>
                <b-card-body>
                  <div class="">
                    <h4><a href="#" class="card-title-link">Top 10 must visit best beaches of Goa</a></h4>
                    <p class="text-muted mb-2">
                      Goa and its beaches do not need an introduction! The state is well known for its
                      spectacular beaches and it is very difficult...<a href="#">read more</a>
                    </p>
                  </div>
                  <div class="pt-3">
                    <b-row class="align-items-center">
                      <div class="col-auto">
                        <p class="mb-0">
                          <i data-feather="calendar" class="icon icon-dual icon-xs"></i>
                          <span class="fs-14 align-middle">11 March, 2020</span>
                        </p>
                      </div>
                      <div class="col text-end">
                        <p class="mb-0">
                          <i data-feather="tag" class="icon icon-dual icon-xs align-bottom"></i>
                          <span class="fs-14">#travel-diary</span>
                        </p>
                      </div>
                    </b-row>
                  </div>
                </b-card-body>
              </b-card>
            </b-col>
          </b-row>

          <p class="sub-header mt-4">An example showing minimal details</p>
          <b-row>
            <b-col lg="8" xl="5">
              <b-card no-body class="card-listing-item">
                <div class="card-img-top-overlay">
                  <div class="overlay-dark"></div>
                  <span class="card-badge top-right bg-success text-white">Travel</span>
                  <img src="@/assets/images/photos/4.jpg" alt="" class="card-img-top" />

                  <div class="card-overlay-bottom">
                    <h2><a href="#" class="text-white">Top 10 must visit best beaches of Goa</a></h2>

                    <div class="avatar-group">
                      <a href="#" class="avatar-group-item shadow-lg">
                        <img src="@/assets/images/avatars/img-7.jpg" alt="img"
                          class="img-fluid avatar-xs rounded-circle avatar-border" />
                      </a>
                      <a href="#" class="avatar-group-item shadow-lg">
                        <img src="@/assets/images/avatars/img-2.jpg" alt="img"
                          class="img-fluid avatar-xs rounded-circle avatar-border" />
                      </a>
                      <a href="#" class="avatar-group-item shadow-lg">
                        <img src="@/assets/images/avatars/img-4.jpg" alt="img"
                          class="img-fluid avatar-xs rounded-circle avatar-border" />
                      </a>
                    </div>
                  </div>
                </div>
              </b-card>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>