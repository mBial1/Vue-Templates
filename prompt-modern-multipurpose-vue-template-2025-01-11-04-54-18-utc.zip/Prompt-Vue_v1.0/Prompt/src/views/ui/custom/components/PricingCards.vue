<template>
  <b-row id="pricing-cards">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Pricing cards</b-card-title>
          <p class="sub-header">
            Using bootstrap's <code>.card</code>, you can create a pricing card.
          </p>

          <b-row class="mt-5">
            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <b-card-body class="text-center">
                  <h4 class="my-0 text-primary">Starter</h4>
                  <h1 class="mb-0">
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">49</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>

                  <ul class="list-unstyled border-top py-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 600 minutes usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal only</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add up to 10 attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                  <a href="#" class="btn btn-soft-primary d-block">Purchase Now</a>
                </b-card-body>
              </b-card>
            </b-col>

            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <b-card-body class="text-center">
                  <h4 class="my-0 text-primary">Professional</h4>
                  <h1 class="mb-0">
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">99</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>

                  <ul class="list-unstyled border-top py-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 6000 minutes usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal or a commercial client</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add up to 100 attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 5 teams</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                  <a href="#" class="btn btn-primary d-block">Purchase Now</a>
                </b-card-body>
              </b-card>
            </b-col>

            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <b-card-body class="text-center">
                  <h4 class="my-0 text-primary">Enterprise</h4>
                  <h1 class="mb-0">
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">599</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>

                  <ul class="list-unstyled border-top py-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Unlimited usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal or a commercial client</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add Unlimited attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>24x7 Technical support via phone</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                  <a href="#" class="btn btn-soft-primary d-block">Purchase Now</a>
                </b-card-body>
              </b-card>
            </b-col>
          </b-row>

          <b-row class="mt-5">
            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <b-card-body>
                  <h4 class="my-0 text-primary">Starter</h4>
                  <h1>
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">49</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>
                  <a href="#" class="btn btn-soft-success d-block mt-3">Purchase Now</a>

                  <ul class="list-unstyled border-top pt-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 600 minutes usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal only</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add up to 10 attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                </b-card-body>
              </b-card>
            </b-col>

            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <div class="card-img-top-overlay d-none d-lg-block">
                  <span class="card-badge top-right bg-warning text-white shadow-sm">
                    Recommended
                  </span>
                </div>
                <b-card-body>
                  <h4 class="my-0 text-primary">Professional</h4>
                  <h1>
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">99</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>
                  <a href="#" class="btn btn-primary d-block mt-3">Purchase Now</a>

                  <ul class="list-unstyled border-top pt-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 6000 minutes usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal or a commercial client</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add up to 100 attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Up to 5 teams</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                </b-card-body>
              </b-card>
            </b-col>

            <b-col lg="4" xl="4">
              <b-card no-body class="border hoverable">
                <b-card-body>
                  <h4 class="my-0 text-primary">Enterprise</h4>
                  <h1>
                    <span class="fw-normal text-muted fs-13 align-top">$</span>
                    <span class="fw-bolder display-5">599</span>
                    <span class="fw-normal text-muted fs-13 align-middle"> / month</span>
                  </h1>
                  <a href="#" class="btn btn-soft-success d-block mt-3">Purchase Now</a>

                  <ul class="list-unstyled border-top pt-4 mt-4 text-start">
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Unlimited usage time</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Use for personal or a commercial client</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Add Unlimited attendees</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>24x7 Technical support via phone</span>
                    </li>
                    <li class="py-2 d-flex align-items-center">
                      <i class="icon icon-xs text-success align-middle me-2" data-feather="check"></i>
                      <span>Technical support via email</span>
                    </li>
                  </ul>
                </b-card-body>
              </b-card>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>