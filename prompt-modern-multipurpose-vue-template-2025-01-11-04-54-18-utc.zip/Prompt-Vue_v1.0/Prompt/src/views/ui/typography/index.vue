<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />

  <section class="py-4 bg-light">
    <b-container>
      <b-row>
        <b-col cols="12">
          <RegularHeadings />
          <DisplayHeadings />
          <InlineTextElements />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Navbar from '@/components/navbar/Navbar.vue';
import RegularHeadings from '@/views/ui/typography/components/RegularHeadings.vue';
import DisplayHeadings from '@/views/ui/typography/components/DisplayHeadings.vue';
import InlineTextElements from '@/views/ui/typography/components/InlineTextElements.vue';
</script>