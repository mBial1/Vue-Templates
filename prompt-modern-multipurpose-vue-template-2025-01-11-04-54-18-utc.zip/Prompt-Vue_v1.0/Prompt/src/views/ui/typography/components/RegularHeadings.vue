<template>
  <b-card no-body>
    <b-card-body>
      <h4 class="mt-0">Regular Headings</h4>
      <p class="sub-header">
        All HTML headings, <code>&lt;h1&gt;</code> through <code>&lt;h6&gt;</code>, are
        available.
      </p>
      <b-row>
        <b-col>
          <h1>h1. Bootstrap heading</h1>
          <h2>h2. Bootstrap heading</h2>
          <h3>h3. Bootstrap heading</h3>
          <h4>h4. Bootstrap heading</h4>
          <h5>h5. Bootstrap heading</h5>
          <h6>h6. Bootstrap heading</h6>
        </b-col>
      </b-row>
    </b-card-body>
  </b-card>
</template>
<script setup lang="ts">
</script>