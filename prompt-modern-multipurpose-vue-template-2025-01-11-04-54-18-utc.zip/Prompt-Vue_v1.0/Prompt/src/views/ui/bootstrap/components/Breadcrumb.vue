<template>
  <b-row id="breadcrumb">
    <b-col lg="12">
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Breadcrumb</b-card-title>
          <p class="sub-header">
            Indicate the current page's location within a navigational hierarchy that
            automatically adds separators via CSS.
          </p>

          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active" aria-current="page">Home</li>
            </ol>
          </nav>

          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Library</li>
            </ol>
          </nav>

          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="#"><i data-feather="home" class="icon-xs"></i></a>
              </li>
              <li class="breadcrumb-item"><a href="#">Library</a></li>
              <li class="breadcrumb-item active" aria-current="page">Data</li>
            </ol>
          </nav>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>