<template>
  <b-row>
    <b-col lg="12">
      <b-card no-body id="popovers">
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Popovers</b-card-title>
          <p class="sub-header">
            Add small overlays of content, like those on the iPad, to any element for housing secondary information.
          </p>

          <div class="button-list" id="popover-container">
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-popover.click.top="`Vivamus sagittis lacus vel augue laoreet rutrum faucibus.`">
              Popover on top
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-popover.click.bottom="`Vivamus sagittis lacus vel augue laoreet rutrum faucibus.`">
              Popover on bottom
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-popover.click.left="`Vivamus sagittis lacus vel augue laoreet rutrum faucibus.`">
              Popover on left
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-popover.click.right="`Vivamus sagittis lacus vel augue laoreet rutrum faucibus.`">
              Popover on right
            </b-button>

            <b-button variant="primary" id="dismiss-1" class="me-1"> Dismissible popover </b-button>
            <b-popover target="dismiss-1" placement="right" trigger="focus">
              And here's some amazing content. It's very engaging. Right?
            </b-popover>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>