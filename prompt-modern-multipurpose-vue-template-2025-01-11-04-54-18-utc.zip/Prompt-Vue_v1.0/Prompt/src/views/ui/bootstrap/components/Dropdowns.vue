<template>
  <b-row id="dropdowns">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Dropdowns</b-card-title>
          <p class="sub-header">
            Toggle contextual overlays for displaying lists of links and more with the Bootstrap dropdown
            plugin.
          </p>

          <b-dropdown variant="primary" class="me-2 d-sm-inline-flex mb-2 mb-sm-0">
            <template #button-content>
              Dropdown button <i class="icon"><span data-feather="chevron-down"></span></i>
            </template>
            <b-dropdown-item>Action</b-dropdown-item>
            <b-dropdown-item>Another action</b-dropdown-item>
            <b-dropdown-item>Something else here</b-dropdown-item>
            <b-dropdown-divider />
            <b-dropdown-item>Separated link</b-dropdown-item>
          </b-dropdown>

          <DropDown custom-class="btn-group">
            <button type="button" class="btn btn-secondary">Split Button Dropdown</button>
            <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split"
              id="dropdownMenuReference" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
              data-reference="parent">
              <i class="icon"><span data-feather="chevron-down"></span></i>
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuReference">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Separated link</a>
            </div>
          </DropDown>

          <p class="sub-header mt-4">Dropdown menu position variations</p>

          <b-dropdown variant="success" class="d-sm-inline-flex me-1 mb-2 mb-sm-0">
            <template #button-content>
              Right Align <i class="icon"><span data-feather="chevron-down"></span></i>
            </template>
            <b-dropdown-item>Action</b-dropdown-item>
            <b-dropdown-item>Another action</b-dropdown-item>
            <b-dropdown-item>Something else here</b-dropdown-item>
          </b-dropdown>

          <DropDown custom-class="btn-group me-1 dropend mb-2 mb-sm-0">
            <button type="button" class="btn btn-info dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
              Drop Right <i class="icon"><span data-feather="chevron-right"></span></i>
            </button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Separated link</a>
            </div>
          </DropDown>
          <DropDown custom-class="btn-group dropstart me-1">
            <button type="button" class="btn btn-danger dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
              <i class="icon"><span data-feather="chevron-left"></span></i> Drop Left
            </button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Separated link</a>
            </div>
          </DropDown>

          <b-dropdown variant="primary" class="hovered me-2 d-inline-flex">
            <template #button-content>
              On Hover <i class="icon"><span data-feather="chevron-down"></span></i>
            </template>
            <b-dropdown-item>Action</b-dropdown-item>
            <b-dropdown-item>Another action</b-dropdown-item>
            <b-dropdown-item>Something else here</b-dropdown-item>
            <b-dropdown-divider />
            <b-dropdown-item>Separated link</b-dropdown-item>
          </b-dropdown>

          <p class="sub-header mt-4">
            You can put a form or simple text within a dropdown menu or set the different position
          </p>

          <b-dropdown variant="primary" class="btn-group me-1 mb-2 mb-sm-0" menu-class="dropdown-menu-lg p-3">
            <template #button-content>
              Simple text <i class="icon"><span data-feather="chevron-down"></span></i>
            </template>
            <div class="text-muted">
              <p>Some example text that's free-flowing within the dropdown menu.</p>
              <p class="mb-0">And this is more example text.</p>
            </div>
          </b-dropdown>

          <b-dropdown variant="secondary" class="btn-group me-1" menu-class="dropdown-menu-lg p-3">
            <template #button-content>
              Dropdown menu Forms <i class="icon"><span data-feather="chevron-down"></span></i>
            </template>
            <form>
              <b-form-group label="Email address" label-for="exampleDropdownFormEmail" class="mb-3">
                <b-form-input type="email" id="exampleDropdownFormEmail" placeholder="email@example.com" />
              </b-form-group>
              <b-form-group label="Password" label-for="exampleDropdownFormPassword" class="mb-3">
                <b-form-input type="password" id="exampleDropdownFormPassword" placeholder="Password" />
              </b-form-group>
              <div class="mb-3">
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="dropdownCheck2">
                  <label class="form-check-label" for="dropdownCheck2">Remember me</label>
                </div>
              </div>
              <b-button type="submit" variant="primary">Sign in</b-button>
            </form>
          </b-dropdown>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import DropDown from '@/components/DropDown.vue';

</script>