<template>
  <b-row>
    <b-col lg="12">
      <b-card no-body id="tooltips">
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Tooltips</b-card-title>
          <p class="sub-header">Examples for adding custom Bootstrap tooltips with CSS and JavaScript using CSS3
            for animations and data-attributes for local title storage.</p>

          <div class="button-list">
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-tooltip.hover.top="'Tooltip on top'">
              Tooltip on top
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-tooltip.hover.bottom="'Tooltip on bottom'">
              Tooltip on bottom
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-tooltip.hover.left="'Tooltip on left'">
              Tooltip on left
            </b-button>
            <b-button type="button" :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" v-b-tooltip.hover.right="'Tooltip on right'">
              Tooltip on right
            </b-button>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>