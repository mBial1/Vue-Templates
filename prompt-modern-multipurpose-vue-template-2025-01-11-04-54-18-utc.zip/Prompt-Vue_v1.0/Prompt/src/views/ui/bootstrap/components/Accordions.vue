<template>
  <b-row>
    <b-col>
      <b-card no-body id="accordions">
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Accordions</b-card-title>
          <p class="sub-header">
            Toggle the visibility of content across your project with a few classes and our
            JavaScript plugins.
          </p>

          <div class="accordion custom-accordionwitharrow mt-3" id="accordionExample">
            <b-card no-body class="mb-1 shadow-none border">
              <a href="#" class="text-dark" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne" @click="show = 1">
                <b-card-header id="headingOne">
                  <h5 class="my-1">What is Lorem Ipsum?
                    <i class="icon-xs accordion-arrow" data-feather="chevron-down"></i>
                  </h5>
                </b-card-header>
              </a>
              <div id="collapseOne" class="collapse" :class="{show: show === 1}" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <b-card-body class="text-muted pt-1">
                  Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
                  terry richardson ad squid. 3 wolf moon officia aute, non cupidatat
                  skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
                  Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid
                  single-origin coffee nulla assumenda shoreditch et. Nihil anim
                  keffiyeh helvetica, craft beer labore wes anderson cred nesciunt
                  sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings
                  occaecat craft beer farm-to-table, raw denim aesthetic synth
                  nesciunt you probably haven't heard of them accusamus labore
                  sustainable VHS.
                </b-card-body>
              </div>
            </b-card>
            <b-card no-body class="mb-1 shadow-none border">
              <a href="#" class="text-dark collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" @click="show = 2">
                <b-card-header id="headingTwo">
                  <h5 class="my-1">Why do we use it?
                    <i class="icon-xs accordion-arrow" data-feather="chevron-down"></i>
                  </h5>
                </b-card-header>
              </a>
              <div id="collapseTwo" class="collapse" :class="{show: show === 2}" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                <b-card-body class="text-muted pt-1">
                  Anim pariatur cliche reprehenderit,
                  enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                  moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                  quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                  aliqua put a bird on it squid single-origin coffee nulla assumenda
                  shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes
                  anderson cred nesciunt sapiente ea proident. Ad vegan excepteur
                  butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw
                  denim aesthetic synth nesciunt you probably haven't heard of them
                  accusamus labore sustainable VHS.
                </b-card-body>
              </div>
            </b-card>
            <b-card no-body class="mb-0 shadow-none border">
              <a href="#" class="text-dark collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" @click="show = 3">
                <b-card-header id="headingThree">
                  <h5 class="my-1">Where does it come from?
                    <i class="icon-xs accordion-arrow" data-feather="chevron-down"></i>
                  </h5>
                </b-card-header>
              </a>
              <div id="collapseThree" class="collapse" :class="{show: show === 3}" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                <b-card-body class="text-muted pt-1">
                  Anim pariatur cliche reprehenderit,
                  enim eiusmod high life accusamus terry richardson ad squid. 3 wolf
                  moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                  quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                  aliqua put a bird on it squid single-origin coffee nulla assumenda
                  shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes
                  anderson cred nesciunt sapiente ea proident. Ad vegan excepteur
                  butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw
                  denim aesthetic synth nesciunt you probably haven't heard of them
                  accusamus labore sustainable VHS.
                </b-card-body>
              </div>
            </b-card>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { ref } from 'vue';

const show = ref(1)
</script>