<template>
  <b-row id="cards">
    <b-col lg="12">
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Cards</b-card-title>
          <p class="sub-header">
            Bootstrap's cards provide a flexible and extensible content container with
            multiple variants and options. Check out
            <a href="https://getbootstrap.com/docs/4.4/components/card/">Bootstrap's Doc</a>
            for more examples.
          </p>
          <b-row>
            <b-col lg="5" xl="3">
              <b-card no-body class="border">
                <img class="card-img-top img-fluid" src="@/assets/images/photos/1.jpg" alt="Card img cap">
                <b-card-body>
                  <b-card-title tag="h5">Card title</b-card-title>
                  <p class="card-text text-muted">
                    Some quick example text to build on the card title and make up the bulk of the card's
                    content.
                  </p>
                  <a href="javascript:void(0);" class="btn btn-primary">Button</a>
                </b-card-body>
              </b-card>
            </b-col>
          </b-row>
          <b-row>
            <b-col lg="6">
              <b-card no-body class="border">
                <b-row class="g-0 align-items-center">
                  <b-col md="5">
                    <img src="@/assets/images/photos/1.jpg" class="card-img" alt="...">
                  </b-col>
                  <b-col md="7">
                    <b-card-body>
                      <b-card-title tag="h5" class="mb-0">Card title</b-card-title>
                      <p class="card-text text-muted">
                        This is a wider card with supporting text lead-in to additional content.
                      </p>
                      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    </b-card-body>
                  </b-col>
                </b-row>
              </b-card>

              <b-card no-body class="border">
                <b-row class="g-0 align-items-center">
                  <b-col md="7">
                    <b-card-body>
                      <b-card-title tag="h5" class="fs-16">Card title</b-card-title>
                      <p class="card-text text-muted">This is a wider card with supporting text lead-in to
                        additional content.</p>
                      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    </b-card-body>
                  </b-col>
                  <b-col md="5">
                    <img src="@/assets/images/photos/1.jpg" class="card-img" alt="...">
                  </b-col>
                </b-row>
              </b-card>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>