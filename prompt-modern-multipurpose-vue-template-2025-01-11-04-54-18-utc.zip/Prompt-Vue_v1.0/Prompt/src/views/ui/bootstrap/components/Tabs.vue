<template>
  <b-row id="nav-tabs">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Nav Tabs</b-card-title>
          <p class="sub-header">
            Takes the basic nav and adds the <code>.nav-tabs</code> class to generate a
            tabbed interface.
          </p>

          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a href="#home" data-bs-toggle="tab" aria-expanded="false" class="nav-link"
                :class="{ active: show === 1 }" @click="show = 1">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="home"></i></span>
                <span class="d-none d-sm-block">Home</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#profile" data-bs-toggle="tab" aria-expanded="true" class="nav-link"
                :class="{ active: show === 2 }" @click="show = 2">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="user"></i></span>
                <span class="d-none d-sm-block">Profile</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#messages" data-bs-toggle="tab" aria-expanded="false" class="nav-link"
                :class="{ active: show === 3 }" @click="show = 3">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="mail"></i></span>
                <span class="d-none d-sm-block">Messages</span>
              </a>
            </li>
          </ul>
          <div class="tab-content p-3 text-muted">
            <div class="tab-pane" id="home" :class="{ 'show active': show === 1 }">
              <p>Vakal text here dolor sit amet, consectetuer adipiscing elit. Aenean
                commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
                magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,
                ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                quis enim.</p>
              <p class="mb-0">Donec pede justo, fringilla vel, aliquet nec, vulputate
                eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
                justo. Nullam dictum felis eu pede mollis pretium. Integer
                tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate
                eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,
                eleifend ac, enim.</p>
            </div>
            <div class="tab-pane" id="profile" :class="{ 'show active': show === 2 }">
              <p>Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In
                enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam
                dictum felis eu pede mollis pretium. Integer tincidunt.Cras dapibus.
                Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean
                leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>
              <p class="mb-0">Vakal text here dolor sit amet, consectetuer adipiscing
                elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
                penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec
                quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla
                consequat massa quis enim.</p>
            </div>
            <div class="tab-pane" id="messages" :class="{ 'show active': show === 3 }">
              <p>Vakal text here dolor sit amet, consectetuer adipiscing elit. Aenean
                commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
                magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,
                ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                quis enim.</p>
              <p class="mb-0">Donec pede justo, fringilla vel, aliquet nec, vulputate
                eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
                justo. Nullam dictum felis eu pede mollis pretium. Integer
                tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate
                eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,
                eleifend ac, enim.</p>
            </div>
          </div>

          <ul class="nav nav-pills navtab-bg nav-justified p-1">
            <li class="nav-item">
              <a href="#home1" data-bs-toggle="tab" aria-expanded="false" class="nav-link" :class="{ active: show1 === 1 }" @click="show1 = 1">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="home"></i></span>
                <span class="d-none d-sm-block">Home</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#profile1" data-bs-toggle="tab" aria-expanded="true" class="nav-link" :class="{ active: show1 === 2 }" @click="show1 = 2">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="user"></i></span>
                <span class="d-none d-sm-block">Profile</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="#messages1" data-bs-toggle="tab" aria-expanded="false" class="nav-link" :class="{ active: show1 === 3 }" @click="show1 = 3">
                <span class="d-block d-sm-none"><i class="icon icon-xxs" data-feather="mail"></i></span>
                <span class="d-none d-sm-block">Messages</span>
              </a>
            </li>
          </ul>
          <div class="tab-content text-muted">
            <div class="tab-pane" id="home1" :class="{ 'show active': show1 === 1 }">
              <p>Vakal text here dolor sit amet, consectetuer adipiscing elit. Aenean
                commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
                magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,
                ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                quis enim.</p>
              <p class="mb-0">Donec pede justo, fringilla vel, aliquet nec, vulputate
                eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
                justo. Nullam dictum felis eu pede mollis pretium. Integer
                tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate
                eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,
                eleifend ac, enim.</p>
            </div>
            <div class="tab-pane" id="profile1" :class="{ 'show active': show1 === 2 }">
              <p>Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In
                enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam
                dictum felis eu pede mollis pretium. Integer tincidunt.Cras dapibus.
                Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean
                leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.</p>
              <p class="mb-0">Vakal text here dolor sit amet, consectetuer adipiscing
                elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
                penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec
                quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla
                consequat massa quis enim.</p>
            </div>
            <div class="tab-pane" id="messages1" :class="{ 'show active': show1 === 3 }">
              <p>Vakal text here dolor sit amet, consectetuer adipiscing elit. Aenean
                commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
                magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,
                ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa
                quis enim.</p>
              <p class="mb-0">Donec pede justo, fringilla vel, aliquet nec, vulputate
                eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
                justo. Nullam dictum felis eu pede mollis pretium. Integer
                tincidunt.Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate
                eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae,
                eleifend ac, enim.</p>
            </div>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { ref } from 'vue';

const show = ref(2);
const show1 = ref(1);
</script>