<template>
  <b-row id="alerts">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Alerts</b-card-title>
          <p class="sub-header">
            Provide contextual feedback messages for typical user actions with the handful of available and flexible alert messages.
          </p>

          <b-alert class="text-primary bg-white border" :model-value="true" dismissible>
            <div class="d-flex align-items-start">
              <b-badge :variant="null" class="badge-soft-primary align-self-center me-3">Info</b-badge>
              <div class="w-100">You should select the desired categories while creating listing</div>
            </div>
          </b-alert>
          <b-alert class="text-success bg-white border" :model-value="true" dismissible>
            <div class="d-flex align-items-start">
              <b-badge :variant="null" class="badge-soft-success align-self-center me-3">Success</b-badge>
              <div class="w-100">Your booking is confirmed by <a href="#" class="text-success alert-link">Mr. Shreyan</a></div>
            </div>
          </b-alert>
          <b-alert class="text-danger bg-white border" :model-value="true" dismissible>
            <div class="d-flex align-items-start">
              <b-badge :variant="null" class="badge-soft-danger align-self-center me-3">Ohh no!</b-badge>
              <div class="w-100">Please check the input you have specified</div>
            </div>
          </b-alert>
          <b-alert class="text-warning bg-white border" :model-value="true" dismissible>
            <div class="d-flex align-items-start">
              <b-badge :variant="null" class="badge-soft-warning align-self-center me-3">Warning!</b-badge>
              <div class="w-100">The number of tickets you have selected might not get confirmed</div>
            </div>
          </b-alert>
          <b-alert class="text-info bg-white border" :model-value="true" dismissible>
            <div class="d-flex align-items-start">
              <b-badge :variant="null" class="badge-soft-info align-self-center me-3">Info</b-badge>
              <div class="w-100">You might want to book return flight to save 25% on overall booking amount
              </div>
            </div>
          </b-alert>

          <b-alert variant="primary" :model-value="true"> This is a primary alert—check it out! </b-alert>
          <b-alert variant="secondary" :model-value="true"> This is a secondary alert—check it out! </b-alert>
          <b-alert variant="success" :model-value="true"> This is a success alert—check it out! </b-alert>
          <b-alert variant="danger" :model-value="true" dismissible> This is a danger alert—check it out! </b-alert>
          <b-alert variant="warning" :model-value="true" dismissible> This is a warning alert—check it out! </b-alert>
          <b-alert variant="info" :model-value="true" dismissible> This is a info alert—check it out! </b-alert>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>