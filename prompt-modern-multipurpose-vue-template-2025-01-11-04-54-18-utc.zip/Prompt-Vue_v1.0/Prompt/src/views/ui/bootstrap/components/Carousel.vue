<template>
  <b-row id="carousel">
    <b-col lg="12">
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Carousel</b-card-title>
          <p class="sub-header">
            A slideshow component for cycling through elements—images or slides of text—like a carousel.
          </p>

          <b-carousel controls indicators>
            <b-carousel-slide :img-src="photo1" />
            <b-carousel-slide :img-src="photo2" />
            <b-carousel-slide :img-src="photo3" />
          </b-carousel>

          <p class="sub-header pt-2">
            Add captions to your slides easily with the <code class="highlighter-rouge">.carousel-caption</code>
            element within any <code class="highlighter-rouge">.carousel-item</code>. They can be
            easily hidden on smaller viewports, as shown below, with optional
            <a href="4.3/utilities/display/">display utilities</a>.
            We hide them initially with <code class="highlighter-rouge">.d-none</code>
            and bring them back on medium-sized devices with <code class="highlighter-rouge">.d-md-block</code>.
          </p>

          <b-carousel controls indicators>
            <b-carousel-slide :img-src="photo1" text="Nulla vitae elit libero, a pharetra augue mollis interdum." caption-html="<h3 class='text-white'>First slide label</h3>" />
            <b-carousel-slide :img-src="photo2" text="Lorem ipsum dolor sit amet, consectetur adipiscing elit." caption-html="<h3 class='text-white'>Second slide label</h3>" />
            <b-carousel-slide :img-src="photo3" text="Praesent commodo cursus magna, vel scelerisque nisl consectetur." caption-html="<h3 class='text-white'>Third slide label</h3>" />
          </b-carousel>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">

import photo1 from "@/assets/images/photos/1.jpg";
import photo2 from "@/assets/images/photos/2.jpg";
import photo3 from "@/assets/images/photos/3.jpg";
</script>