<template>
  <b-row id="buttons">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <div>
            <b-card-title tag="h5" class="mb-0">Buttons</b-card-title>
            <p class="sub-header">
              Use the button classes on an <code>&lt;a&gt;</code>,
              <code>&lt;button&gt;</code>, or <code>&lt;input&gt;</code> element.
            </p>

            <div class="button-list">
              <b-button type="button" variant="primary" class="me-2 mb-2 mb-xl-0">Primary</b-button>
              <b-button type="button" variant="secondary" class="me-2 mb-2 mb-xl-0">Secondary</b-button>
              <b-button type="button" variant="success" class="me-2 mb-2 mb-xl-0">Success</b-button>
              <b-button type="button" variant="danger" class="me-2 mb-2 mb-xl-0">Danger</b-button>
              <b-button type="button" variant="warning" class="me-2 mb-2 mb-xl-0">Warning</b-button>
              <b-button type="button" variant="info" class="me-2 mb-2 mb-xl-0">Info</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-orange">Orange</b-button>
              <b-button type="button" variant="dark" class="me-2 mb-2 mb-xl-0">Dark</b-button>
              <b-button type="button" variant="link" class="me-2 mb-2 mb-xl-0">Link</b-button>
            </div>


            <p class="sub-header pt-2">
              In need of a button, but not the hefty background colors they bring? Replace the
              default modifier classes with the <code>.btn-outline-*</code> ones to remove all
              background images and colors on any button.
            </p>

            <div class="button-list">
              <b-button type="button" variant="outline-primary" class="me-2 mb-2 mb-xl-0">Primary</b-button>
              <b-button type="button" variant="outline-secondary" class="me-2 mb-2 mb-xl-0">Secondary</b-button>
              <b-button type="button" variant="outline-success" class="me-2 mb-2 mb-xl-0">Success</b-button>
              <b-button type="button" variant="outline-danger" class="me-2 mb-2 mb-xl-0">Danger</b-button>
              <b-button type="button" variant="outline-warning" class="me-2 mb-2 mb-xl-0">Warning</b-button>
              <b-button type="button" variant="outline-info" class="me-2 mb-2 mb-xl-0">Info</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn btn-outline-orange">Orange</b-button>
              <b-button type="button" variant="outline-dark" class="me-2 mb-2 mb-xl-0">Dark</b-button>
              <b-button type="button" variant="outline-link" class="me-2 mb-2 mb-xl-0">Link</b-button>
              <b-button type="button" variant="white" class="me-2 mb-2 mb-xl-0">White</b-button>
            </div>

            <p class="sub-header pt-2">
              Replace the default modifier classes with the <code>.btn-soft-*</code>
              ones to have a softer background color on any button.
            </p>

            <div class="button-list">
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-primary">Primary</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-secondary">Secondary</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-success">Success</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-danger">Danger</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-warning">Warning</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-info">Info</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-orange">Orange</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-dark">Dark</b-button>
              <b-button type="button" :variant="null" class="me-2 mb-2 mb-xl-0 btn-soft-link">Link</b-button>
            </div>

            <p class="sub-header pt-2">
              Add a class <code>.btn-rounded</code> with the default modifier classes to have rounded edges.
            </p>

            <div class="button-list mt-2">
              <b-button type="button" variant="primary" pill class="me-2 mb-2 mb-xl-0">Primary</b-button>
              <b-button type="button" variant="secondary" pill class="me-2 mb-2 mb-xl-0">Secondary</b-button>
              <b-button type="button" variant="success" pill class="me-2 mb-2 mb-xl-0">Success</b-button>
              <b-button type="button" variant="danger" pill class="me-2 mb-2 mb-xl-0">Danger</b-button>
              <b-button type="button" variant="warning" pill class="me-2 mb-2 mb-xl-0">Warning</b-button>
              <b-button type="button" variant="info" pill class="me-2 mb-2 mb-xl-0">Info</b-button>
              <b-button type="button" :variant="null" pill class="me-2 mb-2 mb-xl-0 btn-orange">Orange</b-button>
              <b-button type="button" variant="dark" pill class="me-2 mb-2 mb-xl-0">Dark</b-button>
              <b-button type="button" variant="link" pill class="me-2 mb-2 mb-xl-0">Link</b-button>
            </div>

            <p class="sub-header pt-2">
              Fancy larger or smaller buttons? Add <code>.btn-lg</code> or
              <code>.btn-sm</code> for additional sizes.
            </p>
            <div class="button-list">
              <b-button type="button" variant="primary" size="lg" class="btn mb-2 mb-sm-0 me-2">Button Large</b-button>
              <b-button type="button" variant="primary" class="mb-2 mb-sm-0 me-2">Button Regular</b-button>
              <b-button type="button" variant="primary" size="sm" class="btn mb-2 mb-sm-0">Button Small</b-button>
            </div>

            <p class="sub-header pt-2">Buttons with icon - variations</p>
            <div class="button-list">
              <b-button type="button" variant="primary" class="me-2 mb-2 mb-sm-0 ">
                <i class="icon-xs me-1" data-feather="play"></i> Button with icon on left
              </b-button>
              <b-button type="button" variant="primary" class="me-2 mb-2 mb-sm-0">
                Button with icon on right <i class="icon-xs ms-1" data-feather="play"></i>
              </b-button>

              <b-button type="button" variant="primary" class="me-2 mb-2 mb-sm-0 btn-icon d-inline-flex">
                <i class="icon-xs" data-feather="play"></i>
              </b-button>

              <b-button type="button" variant="primary" class="btn-rounded-circle btn-icon d-inline-flex">
                <i class="icon-xs" data-feather="play"></i>
              </b-button>
            </div>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>