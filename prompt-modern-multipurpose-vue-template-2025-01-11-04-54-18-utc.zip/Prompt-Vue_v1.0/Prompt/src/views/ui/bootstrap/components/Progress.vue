<template>
  <b-row id="progressbars">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Progress</b-card-title>
          <p class="sub-header">
            Bootstrap custom progress bars featuring support for stacked bars, animated backgrounds, and text
            labels
          </p>
          <div>
            <b-progress :value="0" class="mb-3" />
            <b-progress :value="33" class="mb-3" />
            <b-progress variant="success" :value="66" class="mb-3" />
            <b-progress variant="danger" :value="100" class="mb-3" />
            <b-progress variant="info" :value="25" :max="100" show-value />
          </div>

          <div class="mt-5">
            <p class="sub-header">
              Add <code>.progress-bar-striped</code> to any <code>.progress-bar</code> to apply a stripe via CSS
              gradient over the progress bar's background color.
              Additionally you can add <code>.progress-bar-animated</code> to make it animated as well.
            </p>

            <div>
              <b-progress :value="10" striped class="mb-3" />
              <b-progress :value="75" striped animated />
            </div>
          </div>

          <div class="mt-5">
            <p class="sub-header">
              Set a height value on the <code>.progress</code>. The inner <code>.progress-bar</code> will
              automatically resize accordingly.
            </p>

            <div>
              <b-progress :value="25" style="height: 2px;" class="mb-3" />
              <b-progress :value="25" style="height: 16px;" />
            </div>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>