<template>
  <b-row>
    <b-col lg="12">
      <b-card no-body id="spinners">
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Spinners</b-card-title>
          <p class="sub-header">
            Indicate the loading state of a component or page with Bootstrap spinners, built entirely with HTML,
            CSS, and no JavaScript.
          </p>

          <div>
            <b-spinner variant="primary" class="m-2" />
            <b-spinner variant="secondary" class="m-2" />
            <b-spinner variant="success" class="m-2" />
            <b-spinner variant="danger" class="m-2" />
            <b-spinner variant="warning" class="m-2" />
            <b-spinner variant="info" class="m-2" />
          </div>

          <p class="sub-header mt-4">
            If you don't fancy a border spinner, switch to the grow spinner. While it doesn't technically spin,
            it does repeatedly grow!
          </p>

          <div>
            <b-spinner variant="primary" type="grow" class="m-2" />
            <b-spinner variant="secondary" type="grow" class="m-2" />
            <b-spinner variant="success" type="grow" class="m-2" />
            <b-spinner variant="danger" type="grow" class="m-2" />
            <b-spinner variant="warning" type="grow" class="m-2" />
            <b-spinner variant="info" type="grow" class="m-2" />
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>