<template>
  <b-row id="forms">
    <b-col col xl="12">
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Form Elements</b-card-title>
          <p class="sub-header">
            Examples and usage guidelines for form control styles, layout options, and
            custom components for creating a wide variety of forms.
          </p>

          <b-row>
            <b-col sm="6">
              <b-form-group label="Text Input" label-for="default-1" class="mb-3">
                <b-form-input type="text" id="default-1" placeholder="A text input" />
              </b-form-group>
              <b-form-group label="Password Input" label-for="default-5" class="mb-3">
                <b-form-input type="password" id="default-5" :model-value="12345678" />
              </b-form-group>
            </b-col>
            <b-col sm="6">
              <b-form-group label="Textarea" label-for="default-textarea" class="mb-3">
                <b-form-textarea type="text" id="example-textarea" rows="5"
                  model-value="text are content goes here..." />
              </b-form-group>
            </b-col>
            <b-col sm="6">
              <b-form-group label="Default Select" label-for="default-3" class="mb-3">
                <b-form-select id="default-3">
                  <b-form-select-option value="default_option">Default Option</b-form-select-option>
                  <b-form-select-option value="option_select_name">Option select name</b-form-select-option>
                  <b-form-select-option value="option_select_name">Option select name</b-form-select-option>
                </b-form-select>
              </b-form-group>

              <b-form-group label="File Upload" label-for="default-3" class="mb-3">
                <BFormFile v-model="file" label="Choose file" />
              </b-form-group>
            </b-col>
            <b-col sm="6">
              <b-form-group label="Default Select Multiple" label-for="default-4" class="mb-3">
                <b-form-select id="default-4" v-model="selected" :options="options" multiple />
              </b-form-group>
            </b-col>
            <b-col sm="6">
              <div class="mb-3">
                <label class="form-label" for="default7">Input with icon</label>
                <div class="form-control-with-hint">
                  <input type="text" class="form-control" id="default7" placeholder="Input placeholder" />
                  <span class="form-control-feedback"><i data-feather="search" class="icon-xs"></i></span>
                </div>
              </div>
            </b-col>
            <b-col sm="6">
              <div class="mb-3">
                <label class="form-label" for="default-8">Input with hint text</label>
                <div class="form-control-with-hint">
                  <input type="text" class="form-control" id="default-8" placeholder="Input placeholder" />
                  <span class="form-control-feedback">USD</span>
                </div>
              </div>
            </b-col>
          </b-row>

          <p class="sub-header pt-2">
            Set heights using classes like <code>.form-control-lg</code> and
            <code>.form-control-sm</code>.
          </p>
          <b-row>
            <b-col md="4" class="mb-2 mb-md-0">
              <b-form-input id="input-small" size="lg" placeholder=".form-control-lg" />
            </b-col>
            <b-col md="4" class="mb-2 mb-md-0">
              <b-form-input id="input-small" placeholder="Default input" />
            </b-col>
            <b-col md="4" class="mb-2 mb-md-0">
              <b-form-input id="input-small" size="sm" placeholder=".form-control-sm" />
            </b-col>
          </b-row>

          <p class="sub-header pt-4">
            Custom controls including Checkboxes, Radios, Select, Range, etc.
          </p>

          <b-row>
            <b-col md="6" class="mb-2 mb-md-0">
              <div class="form-check">
                <input type="checkbox" id="customcheck1" name="customRadioInline1" class="form-check-input">
                <label class="form-check-label" for="customcheck1">Check this custom checkbox</label>
              </div>
              <div class="form-check">
                <input type="checkbox" id="customcheck2" name="customRadioInline1" class="form-check-input">
                <label class="form-check-label" for="customcheck2">Check this custom checkbox 2</label>
              </div>
            </b-col>
            <b-col md="6">
              <div class="form-check">
                <input type="radio" id="customRadioInline1" name="customRadioInline1" class="form-check-input">
                <label class="form-check-label" for="customRadioInline1">Toggle this custom radio</label>
              </div>
              <div class="form-check">
                <input type="radio" id="customRadioInline2" name="customRadioInline1" class="form-check-input">
                <label class="form-check-label" for="customRadioInline2">Or toggle
                  this other custom radio</label>
              </div>
            </b-col>
          </b-row>

          <b-row class="mt-3 align-items-center">
            <b-col md="6" class="mb-2 mb-md-0">
              <b-form-select id="default-3">
                <b-form-select-option value="default_option" selected>Open this select menu</b-form-select-option>
                <b-form-select-option value="1">One</b-form-select-option>
                <b-form-select-option value="2">Two</b-form-select-option>
                <b-form-select-option value="3">Three</b-form-select-option>
              </b-form-select>
            </b-col>
            <b-col md="6">
              <b-form-input id="customRange1" type="range" />
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { ref } from 'vue';

const selected = ref('1');

const options = [
  { value: '1', text: "Default Option" },
  { value: '2', text: "Option select name" },
  { value: '3', text: "Option select name" },
  { value: '4', text: "Option select name" },
  { value: '5', text: "Option select name" }
];

const file = ref<null | File>(null);
</script>