<template>
  <b-row>
    <b-col lg="12">
      <b-card no-body id="offcanvas">
        <b-card-body>
          <b-card-title tag="h5" class=" mb-0">Offcanvas</b-card-title>
          <p class="sub-header">
            Use the buttons below to show and hide an offcanvas element via JavaScript that toggles the
            <code>.show</code> class on an element with the <code>.offcanvas</code> class.
          </p>

          <b-button :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" type="button" @click="() => offPosition('top')">Top Offcanvas</b-button>
          <b-button :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" type="button" @click="() => offPosition('bottom')">Bottom Offcanvas</b-button>
          <b-button :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" type="button" @click="() => offPosition('start')">Left Offcanvas</b-button>
          <b-button :variant="null" class="btn-soft-primary me-1 mb-2 mb-xl-0" type="button" @click="() => offPosition('end')">Right Offcanvas</b-button>

          <b-offcanvas v-model="offcanvas" :placement="position" title="Offcanvas" title-class="mt-0" id="offcanvasExample">
            <p>Some text as placeholder. In real life you can have the elements you have chosen. Like, text, images,
              lists, etc.</p>
            <b-dropdown variant="secondary" class="mt-3" text="Dropdown button">
              <b-dropdown-item>Action</b-dropdown-item>
              <b-dropdown-item>Another action</b-dropdown-item>
              <b-dropdown-item>Something else here</b-dropdown-item>
            </b-dropdown>
          </b-offcanvas>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { ref } from 'vue';

const offcanvas = ref(false);
const position = ref('');

const offPosition = (value: string) => {
  offcanvas.value = !offcanvas.value;
  position.value = value;
};
</script>