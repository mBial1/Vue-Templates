<template>
  <b-row id="badges">
    <b-col lg="12">
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Badges</b-card-title>
          <p class="sub-header">
            Badges scale to match the size of the immediate parent element by
            using relative font sizing and <code>em</code> units.
          </p>
          <h1>Example heading <b-badge>New</b-badge></h1>
          <h2>Example heading <b-badge>New</b-badge></h2>
          <h3>Example heading <b-badge>New</b-badge></h3>
          <h4>Example heading <b-badge>New</b-badge></h4>
          <h5>Example heading <b-badge>New</b-badge></h5>
          <h6>Example heading <b-badge>New</b-badge></h6>

          <p class="mt-4">Badges can be used as part of links or buttons to provide a counter.</p>
          <b-button type="button" variant="primary">
            Notifications <b-badge variant="light" class="text-dark">4</b-badge>
          </b-button>

          <p class="mt-4">
            Add any of the below mentioned modifier classes to change the appearance of a badge.
          </p>
          <div class="hstack gap-1">
            <b-badge variant="primary">Primary</b-badge>
            <b-badge variant="secondary">Secondary</b-badge>
            <b-badge variant="success">Success</b-badge>
            <b-badge variant="danger">Danger</b-badge>
            <b-badge variant="warning">Warning</b-badge>
            <b-badge variant="info">Info</b-badge>
            <b-badge variant="orange" class="bg-orange">Orange</b-badge>
            <b-badge variant="light" class="text-dark">Light</b-badge>
            <b-badge variant="dark">Dark</b-badge>
          </div>

          <p class="mt-4">
            Use the <code>.rounded-pill</code> modifier class to make badges more
            rounded (with a larger border-radius and additional horizontal padding).
          </p>
          <div class="hstack gap-1">
            <b-badge variant="primary" pill>Pill</b-badge>
            <b-badge variant="primary" pill class="badge-md">Badge-md</b-badge>
            <b-badge variant="primary" pill class="badge-lg">Badge-lg</b-badge>
          </div>

          <p class="mt-4">
            Use the <code>.badge-soft-*</code> modifier class to make badges soft</p>
          <div class="hstack gap-1">
            <b-badge :variant="null" class="badge-soft-primary">Primary</b-badge>
            <b-badge :variant="null" class="badge-soft-secondary">Secondary</b-badge>
            <b-badge :variant="null" class="badge-soft-success">Success</b-badge>
            <b-badge :variant="null" class="badge-soft-danger">Danger</b-badge>
            <b-badge :variant="null" class="badge-soft-warning">Warning</b-badge>
            <b-badge :variant="null" class="badge-soft-info">Info</b-badge>
            <b-badge :variant="null" class="badge-soft-orange">Orange</b-badge>
            <b-badge :variant="null" class="badge-soft-dark">Dark</b-badge>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
</script>