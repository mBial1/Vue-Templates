<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />

  <section class="py-4 bg-light">
    <b-container>
      <b-row>
        <b-col cols="12">
          <Alerts />
          <Accordions />
          <Badges />
          <Breadcrumb />
          <Buttons />
          <Cards />
          <Tabs />
          <Carousel />
          <Dropdowns />
          <FormElements />
          <Modals />
          <Progress />
          <Pagination />
          <Spinners />
          <Offcanvas />
          <Popovers />
          <Tooltips />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Navbar from '@/components/navbar/Navbar.vue';
import Alerts from '@/views/ui/bootstrap/components/Alerts.vue';
import Accordions from '@/views/ui/bootstrap/components/Accordions.vue';
import Badges from '@/views/ui/bootstrap/components/Badges.vue';
import Breadcrumb from '@/views/ui/bootstrap/components/Breadcrumb.vue';
import Buttons from '@/views/ui/bootstrap/components/Buttons.vue';
import Cards from '@/views/ui/bootstrap/components/Cards.vue';
import Tabs from '@/views/ui/bootstrap/components/Tabs.vue';
import Carousel from '@/views/ui/bootstrap/components/Carousel.vue';
import Dropdowns from '@/views/ui/bootstrap/components/Dropdowns.vue';
import FormElements from '@/views/ui/bootstrap/components/FormElements.vue';
import Modals from '@/views/ui/bootstrap/components/Modals.vue';
import Progress from '@/views/ui/bootstrap/components/Progress.vue';
import Pagination from '@/views/ui/bootstrap/components/Pagination.vue';
import Spinners from '@/views/ui/bootstrap/components/Spinners.vue';
import Offcanvas from '@/views/ui/bootstrap/components/Offcanvas.vue';
import Popovers from '@/views/ui/bootstrap/components/Popovers.vue';
import Tooltips from '@/views/ui/bootstrap/components/Tooltips.vue';
</script>