<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />

  <section class="py-4 bg-light">
    <b-container>
      <AoS />
      <CountUp />
      <Parallax />
      <Swiper />
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Navbar from '@/components/navbar/Navbar.vue';
import AoS from '@/views/ui/plugins/components/AoS.vue';
import CountUp from '@/views/ui/plugins/components/CountUp.vue';
import Parallax from '@/views/ui/plugins/components/Parallax.vue';
import Swiper from '@/views/ui/plugins/components/Swiper.vue';
</script>