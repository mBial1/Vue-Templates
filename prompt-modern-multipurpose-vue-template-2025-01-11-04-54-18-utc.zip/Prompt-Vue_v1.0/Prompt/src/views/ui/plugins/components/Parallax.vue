<template>
  <b-row id="jarallax">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Just Another Parallax</b-card-title>
          <p class="sub-header">
            Smooth parallax scrolling effect for background images, videos. Code in pure JavaScript with NO
            dependencies + jQuery supported. YouTube, Vimeo and Self-Hosted Videos parallax supported.
          </p>

          <div class="py-3">
            <b-row class="text-center">
              <b-col lg="12">
                <div class="position-relative">
                  <div class="jarallax" data-jarallax data-speed=".2" :style="`background-image: url(${coworking2})`"
                    style="height: 320px;"></div>
                </div>
              </b-col>
            </b-row>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { onMounted } from 'vue';
import { jarallax } from 'jarallax';
import 'jarallax/dist/jarallax';
import 'jarallax/dist/jarallax.cjs';
import 'jarallax/dist/jarallax.min.js';

import coworking2 from "@/assets/images/hero/coworking2.jpg";

onMounted(() => {
  // @ts-ignore
  jarallax(document.querySelectorAll(".jarallax"));
});
</script>