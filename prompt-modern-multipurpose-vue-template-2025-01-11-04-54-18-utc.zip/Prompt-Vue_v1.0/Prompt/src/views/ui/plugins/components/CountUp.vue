<template>
  <b-row id="countup">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Count Up</b-card-title>
          <p class="sub-header">
            CountUp.js is a dependency-free, lightweight JavaScript class that can be used to quickly create
            animations that display numerical data in a more interesting way.
          </p>

          <div class="py-3">
            <b-row class="text-center">
              <b-col xl="3" md="6" class="mb-4 mb-sm-0">
                <div class="display-4 fw-light">
                  <Vue3autocounter ref='counter' :startAmount='10' :endAmount='100' :duration='5' suffix="+" />
                </div>
                <p class="mt-2 mb-0 fw-semibold">
                  Products Built
                </p>
                <p>helped clients across the globe</p>
              </b-col>

              <b-col xl="3" md="6" class="mb-4 mb-sm-0">
                <div class="display-4 fw-light">
                  <Vue3autocounter ref='counter' :startAmount='5' :endAmount='21' :duration='5' prefix="$"
                    suffix="M+" />
                </div>
                <p class="mt-2 mb-0 fw-semibold">
                  Revenue Generated
                </p>
                <p>across 10+ countries</p>
              </b-col>

              <b-col xl="3" md="6" class="mb-4 mb-sm-0">
                <div class="display-4 fw-light">
                  <Vue3autocounter ref='counter' :startAmount='10' :endAmount='100' :duration='5' suffix="+" />
                </div>
                <p class="mt-2 mb-0 fw-semibold">
                  Satisfied Clients
                </p>
                <p>across 100+ locations</p>
              </b-col>

              <b-col xl="3" md="6" class="mb-4 mb-sm-0">
                <div class="display-4 fw-light">
                  <Vue3autocounter ref='counter' :startAmount='1' :endAmount='10' :duration='5' suffix="+" />
                </div>
                <p class="mt-2 mb-0 fw-semibold">
                  Awards Won
                </p>
                <p>on Awwwards, CSS Design Awards</p>
              </b-col>
            </b-row>
          </div>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import Vue3autocounter from 'vue3-autocounter';
</script>