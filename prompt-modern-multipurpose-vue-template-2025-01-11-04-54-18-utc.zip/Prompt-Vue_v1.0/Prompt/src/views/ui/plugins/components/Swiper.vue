<template>
  <b-row id="swiper">
    <b-col>
      <b-card no-body>
        <b-card-body>
          <b-card-title tag="h5" class="mb-0">Swiper</b-card-title>
          <p class="sub-header">
            Using <a href="https://swiperjs.com/">Swipper</a> plugin, you can easily create carousels. It's being
            used in almost all the pages where we are having slider in hero element.
          </p>

          <h6 class="mt-4 mb-1">Simple Example</h6>
          <p class="sub-header mb-4">Just specify data attribute <code>data-toggle="swiper"</code> to any
            div element containing your items to enabled it. Optionally you can pass all options mentioned in the
            plugin's official
            documentation via data attribute <code>swiper</code> E.g. <code>data-swiper="{}"</code>.</p>

          <b-row>
            <b-col lg="12">
              <!-- Swiper -->
              <div class="slider">
                <Swiper :modules="[Autoplay, Pagination]" :slidesPerView="1" :loop="true" :spaceBetween="0"
                  :autoplay="{ delay: 5000 }" :roundLengths="true"
                  :pagination="{ el: '.swiper-pagination', dynamicBullets: true }">
                  <SwiperSlide>
                    <div class="swiper-slide-content">
                      <b-row class="text-center">
                        <b-col>
                          <img src="@/assets/images/hero/saas1.jpg" alt="" class="w-75" />
                        </b-col>
                      </b-row>
                      <b-row class="text-center my-4 pb-5">
                        <b-col>
                          <h5 class="fw-medium fs-16">Manage your saas business with ease</h5>
                          <p class="text-muted">Make your saas application
                            stand out with high-quality landing page
                            designed and developed by
                            professional.</p>
                        </b-col>
                      </b-row>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div class="swiper-slide-content">
                      <b-row class="text-center">
                        <b-col>
                          <img src="@/assets/images/hero/saas2.jpg" alt="" class="w-75" />
                        </b-col>
                      </b-row>
                      <b-row class="text-center my-4 pb-5">
                        <b-col>
                          <h5 class="fw-medium fs-16">The best way to showcase your mobile app</h5>
                          <p class="text-muted">
                            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium.
                          </p>
                        </b-col>
                      </b-row>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div class="swiper-slide-content">
                      <b-row class="text-center">
                        <b-col>
                          <img src="@/assets/images/hero/saas3.jpg" alt="" class="w-75" />
                        </b-col>
                      </b-row>
                      <b-row class="text-center my-4 pb-5">
                        <b-col>
                          <h5 class="fw-medium fs-16">Smart Solution that convert Lead to Customer</h5>
                          <p class="text-muted">
                            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium.
                          </p>
                        </b-col>
                      </b-row>
                    </div>
                  </SwiperSlide>
                  <div class="swiper-pagination"></div>
                </Swiper>
              </div>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Pagination } from 'swiper/modules';
</script>