<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />
  <section class="py-4 bg-light">
    <b-container>
      <b-row>
        <b-col cols="12">
          <Colors />
          <Background />
          <TextColors />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Navbar from '@/components/navbar/Navbar.vue';
import Colors from '@/views/ui/colors/components/Colors.vue';
import Background from '@/views/ui/colors/components/Background.vue';
import TextColors from '@/views/ui/colors/components/TextColors.vue';
</script>