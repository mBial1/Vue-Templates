<template>
  <b-card no-body>
    <b-card-body>
      <h4 class="my-0">Text Colors</h4>
      <p class="sub-header">
        Even your text can have the contexual color.
        E.g. <code>.text-{primary|secondary|success|danger|info|warning}</code>
      </p>
      <b-row>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-primary">.text-primary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-secondary">.text-secondary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-success">.text-success</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-danger">.text-danger</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-warning">.text-warning</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-white p-2 rounded">
            <h5 class="text-info">.text-info</h5>
          </div>
        </b-col>
      </b-row>
    </b-card-body>
  </b-card>
</template>
<script setup lang="ts">
</script>