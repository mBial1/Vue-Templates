<template>
  <b-card no-body>
    <b-card-body>
      <h4 class="my-0">Background</h4>
      <p class="sub-header">
        Use the contextual class to have background with different shades.
        E.g. <code>.bg-{primary|secondary|success|danger|info|warning}</code>
      </p>

      <b-row>
        <b-col md="2" class="text-center">
          <div class="bg-primary p-3 rounded mb-2 mb-md-0">
            <h5 class="text-white">.bg-primary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center mb-2 mb-md-0">
          <div class="bg-secondary p-3 rounded">
            <h5 class="text-white">.bg-secondary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center mb-2 mb-md-0">
          <div class="bg-success p-3 rounded">
            <h5 class="text-white">.bg-success</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center mb-2 mb-md-0">
          <div class="bg-danger p-3 rounded">
            <h5 class="text-white">.bg-danger</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center mb-2 mb-md-0">
          <div class="bg-warning p-3 rounded">
            <h5 class="text-white">.bg-warning</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center mb-2 mb-md-0">
          <div class="bg-info p-3 rounded">
            <h5 class="text-white">.bg-info</h5>
          </div>
        </b-col>
      </b-row>

      <p class="sub-header mt-4">
        Each color has a translucent shade too. It adds a little transparency.
        E.g. <code>.bg-soft-{primary|secondary|success|danger|info|warning}</code>
      </p>
      <b-row>
        <b-col md="2" class="text-center">
          <div class="bg-soft-primary p-2 rounded mb-2 mb-md-0">
            <h5 class="text-primary">.bg-soft-primary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-soft-secondary p-2 rounded mb-2 mb-md-0">
            <h5 class="text-secondary">.bg-soft-secondary</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-soft-success p-2 rounded mb-2 mb-md-0">
            <h5 class="text-success">.bg-soft-success</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-soft-danger p-2 rounded mb-2 mb-md-0">
            <h5 class="text-danger">.bg-soft-danger</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-soft-warning p-2 rounded mb-2 mb-md-0">
            <h5 class="text-warning">.bg-soft-warning</h5>
          </div>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-soft-info p-2 rounded mb-2 mb-md-0">
            <h5 class="text-info">.bg-soft-info</h5>
          </div>
        </b-col>
      </b-row>
    </b-card-body>
  </b-card>
</template>
<script setup lang="ts">
</script>