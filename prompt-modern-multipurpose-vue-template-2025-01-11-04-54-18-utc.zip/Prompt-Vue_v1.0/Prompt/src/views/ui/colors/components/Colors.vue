<template>
  <b-card no-body>
    <b-card-body>
      <h4 class="my-0">Colors</h4>
      <p class="sub-header">
        These are primary theme colors. They are used for all the elements
        including buttons, alerts, background, etc.
      </p>

      <b-row>
        <b-col md="2" class="text-center">
          <div class="bg-primary p-5 rounded"></div>
          <h6>Primary</h6>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-secondary p-5 rounded"></div>
          <h6>Secondary</h6>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-success p-5 rounded"></div>
          <h6>Success</h6>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-danger p-5 rounded"></div>
          <h6>Error</h6>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-warning p-5 rounded"></div>
          <h6>Warning</h6>
        </b-col>
        <b-col md="2" class="text-center">
          <div class="bg-info p-5 rounded"></div>
          <h6>Info</h6>
        </b-col>
      </b-row>
    </b-card-body>
  </b-card>
</template>
<script setup lang="ts">
</script>