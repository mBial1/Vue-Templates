import { RouteType } from "@/types";

export type PageType = {
  title: string;
  link: RouteType;
  image: string;
};