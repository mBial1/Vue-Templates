<template>
  <div class="bg-gradient3">
    <Navbar topbarColor="navbar-light" classList="mx-auto" ctaButtonClass="btn-outline-primary btn-sm" />

    <section class="position-relative hero-13 overflow-hidden pt-7 pt-lg-6 pb-5">
      <b-container>
        <b-row class="align-items-center text-center text-sm-start">
          <b-col lg="6">
            <div class="mb-lg-0">
              <h1 class="hero-title">A modern look and feel for your
                <span class="highlight highlight-success d-inline-block" data-toggle="typed">
                  <Typewriter
                    data-type='["saas", "mobile app", "software", "startup", "agency","portfolio", "coworking", "crypto", "marketing"]'
                    :data-period="500" />
                </span>
              </h1>

              <p class="fs-18 text-muted pt-3">
                Make your website or web application stand out with high-quality landing pages designed and developed by
                professionals.
              </p>

              <div class="pt-3 pt-sm-5 mb-4 mb-lg-0">
                <a href="#demos" class="btn btn-primary" data-toggle="smooth-scroll">
                  View Demos
                  <span class="ms-2 icon icon-xxs" data-feather="arrow-down"></span>
                </a>{{ ' ' }}
                <!-- <a href="docs-introducation.html" class="btn btn-link text-primary fw-semibold ms-2">Documentation</a> -->
              </div>
            </div>
          </b-col>
          <b-col lg="5" class="offset-lg-1 hero-right">
            <div class="img-container">
              <div class="slider">
                <Swiper :modules="[Autoplay]" :autoplay="{ delay: 2000 }" :loop="true" :slidesPerView="1"
                  :spaceBetween="0" :roundLengths="true" :breakpoints="{
                    576: { slidesPerView: 1.2 },
                    768: { slidesPerView: 1 }
                  }">
                  <SwiperSlide v-for="(item, idx) in demos" :key="idx">
                    <div class="swiper-slide-content">
                      <img :src="item" alt="" class="img-fluid rounded-lg" />
                    </div>
                  </SwiperSlide>
                </Swiper>
              </div>
            </div>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';

import Navbar from "@/components/navbar/Navbar.vue";
import { demos } from '@/views/home/components/data';
</script>