<template>
  <section class="section py-4 pt-sm-6 pb-sm-0 position-relative" id="section-download" data-aos="fade-up">
    <b-container class="text-center">
      <b-row class="align-items-center">
        <b-col>
          <h1 class="display-4 fw-medium">Start creating delightful user experience</h1>
          <p class="text-muted mx-auto">
            Start working with
            <span class="text-dark fw-bold">{{ appName }}</span> to create awesome landing pages & websites
          </p>

          <div class="text-center mt-5">
            <a href="" class="btn btn-primary">
              <i class="icon icon-xxs ms-1" data-feather="shopping-bag"></i> Purchase Now
            </a>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from '@/helpers';
</script>