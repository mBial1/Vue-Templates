import type { PageType } from "@/views/home/components/types";

import app from "@/assets/images/demo/landing/home-app.jpg";
import saas from "@/assets/images/demo/landing/home-saas.jpg";
import saas2 from "@/assets/images/demo/landing/home-saas2.jpg";
import startup from "@/assets/images/demo/landing/home-startup.jpg";
import software from "@/assets/images/demo/landing/home-software.jpg";
import agency from "@/assets/images/demo/landing/home-agency.jpg";
import coworking from "@/assets/images/demo/landing/home-coworking.jpg";
import crypto from "@/assets/images/demo/landing/home-crypto.jpg";
import marketing from "@/assets/images/demo/landing/home-marketing.jpg";
import portfolio from "@/assets/images/demo/landing/home-portfolio.jpg";

import company from "@/assets/images/demo/pages/company.jpg";
import contact from "@/assets/images/demo/pages/contact.jpg";
import career from "@/assets/images/demo/pages/career.jpg";
import blog from "@/assets/images/demo/pages/blog.jpg";
import blogPost from "@/assets/images/demo/pages/blog-post.jpg";
import dashboard from "@/assets/images/demo/pages/dashboard.jpg";
import settings from "@/assets/images/demo/pages/settings.jpg";
import portfolioGrid from "@/assets/images/demo/pages/portfolio-grid.jpg";
import portfolioMasonry from "@/assets/images/demo/pages/portfolio-masonry.jpg";
import portfolioItem from "@/assets/images/demo/pages/portfolio-item.jpg";
import pricing from "@/assets/images/demo/pages/pricing.jpg";
import help from "@/assets/images/demo/pages/help.jpg";

import login from "@/assets/images/demo/pages/auth-login.jpg";
import signup from "@/assets/images/demo/pages/auth-signup.jpg";
import password from "@/assets/images/demo/pages/auth-password.jpg";
import confirm from "@/assets/images/demo/pages/auth-confirm.jpg";

import saas1Img from "@/assets/images/hero/saas1.jpg";
import saas2Img from "@/assets/images/hero/saas2.jpg";
import saas3Img from "@/assets/images/hero/saas3.jpg";

export const landingPages: PageType[] = [
  {
    title: "Mobile App",
    link: { name: "home.app" },
    image: app
  },
  {
    title: "Saas Modern",
    link: { name: "home.saas" },
    image: saas
  },
  {
    title: "Saas Classic",
    link: { name: "home.saas2" },
    image: saas2
  },
  {
    title: "Startup",
    link: { name: "home.startup" },
    image: startup
  },
  {
    title: "Software",
    link: { name: "home.software" },
    image: software
  },
  {
    title: "Agency",
    link: { name: "home.agency" },
    image: agency
  },
  {
    title: "Co-Working",
    link: { name: "home.coworking" },
    image: coworking
  },
  {
    title: "Crypto",
    link: { name: "home.crypto" },
    image: crypto
  },
  {
    title: "Marketing",
    link: { name: "home.marketing" },
    image: marketing
  },
  {
    title: "Portfolio",
    link: { name: "home.portfolio" },
    image: portfolio
  }
];

export const secondaryPages: PageType[] = [
  {
    title: "Company",
    link: { name: "company" },
    image: company,
  },
  {
    title: "Contact",
    link: { name: "contact" },
    image: contact,
  },
  {
    title: "Career",
    link: { name: "career" },
    image: career,
  },
  {
    title: "Blog",
    link: { name: "blog" },
    image: blog,
  },
  {
    title: "Blog-Post",
    link: { name: "blog.post" },
    image: blogPost,
  },
  {
    title: "Dashboard",
    link: { name: "dashboard" },
    image: dashboard,
  },
  {
    title: "Settings",
    link: { name: "auth.settings" },
    image: settings,
  },
  {
    title: "Portfolio Grid",
    link: { name: "portfolio.grid" },
    image: portfolioGrid,
  },
  {
    title: "Portfolio Masonry",
    link: { name: "portfolio.masonry" },
    image: portfolioMasonry,
  },
  {
    title: "Portfolio-item",
    link: { name: "portfolio.item" },
    image: portfolioItem,
  },
  {
    title: "Pricing",
    link: { name: "pricing" },
    image: pricing,
  },
  {
    title: "Help",
    link: { name: "help.desk" },
    image: help,
  }
];

export const authPages: PageType[] = [
  {
    title: "Login",
    link: { name: "auth.login" },
    image: login,
  },
  {
    title: "Signup",
    link: { name: "auth.register" },
    image: signup,
  },
  {
    title: "Forget Password",
    link: { name: "auth.forget-password" },
    image: password,
  },
  {
    title: "Confirm Account",
    link: { name: "auth.confirm" },
    image: confirm,
  }
];

export const demos: string[] = [saas1Img, saas2Img, saas3Img];