<template>
  <section class="position-relative overflow-hidden features-1 py-5" id="auth-pages">
    <b-container>
      <b-row>
        <b-col class="text-center" data-aos="fade-up">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Account Pages</b-badge>
          <h1 class="display-4 fw-semibold">Inner Pages</h1>
        </b-col>
      </b-row>

      <b-row class="mt-2" data-aos="fade-up" data-duration="600">
        <b-col lg="6" v-for="(item, idx) in authPages" :key="idx">
          <PageCard :item="item" />
          <!-- <a :href="item.link" target="_blank" class="mt-4">
            <div class="shadow p-2 rounded-sm border">
              <img :src="item.image" class="img-fluid" alt="demo-img" />
            </div>
            <h4 class="text-center">{{item.title}}</h4>
          </a> -->
        </b-col>

      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { authPages } from '@/views/home/components/data';
import PageCard from '@/views/home/components/PageCard.vue';
</script>