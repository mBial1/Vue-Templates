<template>
  <section class="mt-5 position-relative overflow-hidden features-1 py-5" id="demos">
    <b-container>
      <b-row>
        <b-col class="text-center" data-aos="fade-up">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Demos</b-badge>
          <h1 class="display-4 fw-semibold">Landing Pages</h1>
          <p class="text-muted mx-auto">Modern landing pages available for every need</p>
        </b-col>
      </b-row>

      <b-row class="mt-2" data-aos="fade-up" data-duration="600">
        <b-col lg="6" v-for="(item, idx) in landingPages" :key="idx">
          <PageCard :item="item" />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { landingPages } from '@/views/home/components/data';
import PageCard from '@/views/home/components/PageCard.vue';
</script>