<template>
  <router-link :to="{ name: item.link.name }" target="_blank" class="mt-4">
    <div class="shadow p-2 rounded-sm border">
      <img :src="item.image" class="img-fluid" alt="demo-img" />
    </div>
    <h4 class="text-center mt-3">{{ item.title }}</h4>
  </router-link>
</template>

<script setup lang="ts">
import type { PropType } from "vue";
import type { PageType } from "@/views/home/components/types";

defineProps({
  item: {
    type: Object as PropType<PageType>,
    required: true
  }
});
</script>