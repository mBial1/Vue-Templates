<template>
  <Hero />
  <Demos />
  <SecondaryPages />
  <AuthPages />
  <Features />
  <CTA />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/home/components/Hero.vue";
import Demos from "@/views/home/components/Demos.vue";
import SecondaryPages from "@/views/home/components/SecondaryPages.vue";
import AuthPages from "@/views/home/components/AuthPages.vue";
import Features from "@/views/home/components/Features.vue";
import CTA from "@/views/home/components/CTA.vue";
import Footer from "@/views/home/components/Footer.vue";
</script>