<template>
  <section class="section pt-5 pb-7 position-relative features-4">
    <b-container>
      <b-row>
        <b-col>
          <h3>Feedback From Client</h3>
        </b-col>
      </b-row>
      <b-row class="testimonials-2 mt-5">
        <b-col lg="10" class="offset-lg-1">
          <div class="slider">
            <Swiper :modules="[Autoplay]" :loop="true" :spaceBetween="24" :autoplay="{delay: 5000}"
              :breakpoints="{576: {slidesPerView: 1 }, 768: { slidesPerView: 1 } }" :roundLengths="true"
              :navigation="{nextEl: '.swiper-custom-next',prevEl: '.swiper-custom-prev'}">
              <SwiperSlide>
                <b-card no-body class="mb-0 border rounded">
                  <b-card-body class="testimonial-body shadow">
                    <p class="quotation-mark text-muted">“</p>
                    <h4 class="fw-normal mb-3 mt-0">
                      It is one of the very convenient to use project manager ever! I have tried many project
                      management apps for my daily tasks, but this one is far better than others. Simply loved it!
                    </h4>
                    <hr />
                    <div class="d-flex pt-2">
                      <img class="me-2 rounded-circle" :src="avatar5" alt="" height="36" />
                      <div class="flex-grow-1">
                        <h6 class="m-0">John Stark</h6>
                        <p class="my-0 text-muted fs-13">Engineering Director</p>
                      </div>
                    </div>
                  </b-card-body>
                </b-card>
              </SwiperSlide>
            </Swiper>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';

import avatar5 from "@/assets/images/avatars/img-5.jpg"
</script>