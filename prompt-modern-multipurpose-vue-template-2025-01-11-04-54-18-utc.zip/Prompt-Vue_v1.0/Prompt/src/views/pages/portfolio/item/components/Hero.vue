<template>
    <section class="hero-4 pb-5 pt-7 py-sm-7">
        <b-container>
            <b-row class="justify-content-center">
                <b-col lg="7" class="text-center">
                    <h1 class="hero-title">Awesome Mobile App</h1>
                </b-col>
            </b-row>
            <b-row class="border-top border-bottom py-4 align-items-center mt-5">
                <b-col>
                    <span class="fs-14">Client</span>
                    <h4 class="mt-1 fw-medium">Scarlet Johnson</h4>
                </b-col>
                <b-col>
                    <span class="fs-14">Category</span>
                    <h4 class="mt-1 fw-medium">Mobile App</h4>
                </b-col>
                <b-col>
                    <span class="fs-14">Crafted Date</span>
                    <h4 class="mt-1 fw-medium">Oct 12, 2019</h4>
                </b-col>
                <div class="col-auto">
                    <ul class="list-inline mb-0 me-3 hstack gap-1">
                        <li class="list-inline-item text-muted align-middle me-2 text-uppercase fs-13 fw-medium">Share:
                        </li>
                        <li class="list-inline-item me-2 align-middle">
                            <a href="#">
                                <i class="icon-xs icon-dual-primary" data-feather="facebook"></i>
                            </a>
                        </li>
                        <li class="list-inline-item me-2 align-middle">
                            <a href="#">
                                <i class="icon-xs icon-dual-info" data-feather="twitter"></i>
                            </a>
                        </li>
                        <li class="list-inline-item align-middle">
                            <a href="#">
                                <i class="icon-xs icon-dual-danger" data-feather="instagram"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <a class="btn btn-outline-primary" href="#">Project Link</a>
                </div>
            </b-row>
        </b-container>
    </section>
</template>
<script setup lang="ts">
</script>