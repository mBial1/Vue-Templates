<template>
<section class="position-relative pb-5">
    <b-container>
        <b-row class="border-top border-bottom py-4 align-items-center">
            <b-col md="4" sm="6" class="text-md-start text-center">
                <a class="btn btn-white me-3" href="javascript:void(0)" data-bs-toggle="popover" data-bs-placement="top" data-bs-trigger="hover" data-bs-html="true" data-bs-content="<div class='d-flex align-items-center'>
                                            <img src='/assets/images/blog/post1.jpg' width='60' class='me-3 rounded-sm' alt='thumb'>
                                            <div class='flex-grow-1'>
                                                <h6 class='fs-14 fw-semibold mt-0 mb-1'>Introducing new blazzing fast user interface</h6>
                                                <span class='d-block fs-13 text-muted'>by Emily Blunt</span>
                                            </div>
                                        </div>" title="">
                    <i class="icon-xs icon-left-arrow me-2"></i>
                    <span class="d-none d-sm-inline ms-1">Awesome Saas App</span>
                </a>
            </b-col>
            <b-col md="4" class="text-md-center">
                <a class="btn btn-white my-md-0 my-3" href="#">
                    View All
                </a>
            </b-col>
            <b-col md="4" sm="6" class="text-md-end">
                <a class="btn btn-white" href="javascript:void(0)" data-bs-toggle="popover" data-bs-placement="top" data-bs-trigger="hover" data-bs-html="true" data-bs-content="<div class='d-flex align-items-center'>
                                        <img src='/assets/images/blog/post2.jpg' width='60' class='me-3 rounded-sm' alt='thumb'>
                                        <div class='flex-grow-1'>
                                            <h6 class='fs-14 fw-semibold mt-0 mb-1'>Awesome Desktop App</h6>
                                            <span class='d-block fs-13 text-muted'>Desktop App</span>
                                        </div>
                                </div>" title="">
                    <span class="d-none d-sm-inline me-1">Desktop App</span>
                    <i class="icon-xs icon-right-arrow ms-2"></i>
                </a>
            </b-col>
        </b-row>
    </b-container>
</section>
</template>
<script setup lang="ts">
</script>