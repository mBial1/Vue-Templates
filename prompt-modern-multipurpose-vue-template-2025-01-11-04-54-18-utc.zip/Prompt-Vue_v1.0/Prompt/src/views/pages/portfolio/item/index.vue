<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <Portfolio />
  <Testimonials />
  <Navigation />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/portfolio/item/components/Hero.vue";
import Portfolio from "@/views/pages/portfolio/item/components/Portfolio.vue";
import Testimonials from "@/views/pages/portfolio/item/components/Testimonials.vue";
import Navigation from "@/views/pages/portfolio/item/components/Navigation.vue";
import Footer from "@/views/pages/portfolio/item/components/Footer.vue";
</script>