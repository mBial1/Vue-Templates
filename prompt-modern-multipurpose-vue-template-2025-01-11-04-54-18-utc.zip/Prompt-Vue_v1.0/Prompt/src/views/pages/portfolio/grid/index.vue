<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <Content />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/portfolio/grid/components/Hero.vue";
import Content from "@/views/pages/portfolio/grid/components/Content.vue";
import Footer from "@/views/pages/portfolio/grid/components/Footer.vue";
</script>