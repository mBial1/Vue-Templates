import { PortfolioType } from "@/types";

import photos1 from "@/assets/images/photos/1.jpg";
import photos7 from "@/assets/images/photos/7.jpg";
import photos3 from "@/assets/images/photos/3.jpg";
import photos4 from "@/assets/images/photos/4.jpg";
import photos5 from "@/assets/images/photos/5.jpg";
import photos6 from "@/assets/images/photos/6.jpg";

export const portfolio: PortfolioType[] = [
  {
    categories: ["all", "web", "illustrator"],
    title: "Smart Desk v2.0",
    image: photos1,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    categories: ["all", "graphic"],
    title: "Task Manager",
    image: photos7,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    categories: ["all", "web", "photography"],
    title: "Portfolio Manager",
    image: photos3,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    categories: ["all", "illustrator"],
    title: "Smart Office v2.0",
    image: photos4,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    categories: ["all", "web", "photography"],
    title: "Online Conference",
    image: photos5,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    categories: ["all", "graphic"],
    title: "Virtual Receptionist",
    image: photos6,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  }
];