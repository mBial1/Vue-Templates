<template>
  <section class="overflow-hidden py-5 py-md-6 py-lg-7">
    <b-container>
      <b-row>
        <b-col cols="12">
          <div class="text-center filter-menu">
            <a href="javascript: void(0);" class="filter-menu-item" :class="{ active: selectedCategory === 'all' }" @click="selectCategory('all')">All</a>
            <a href="javascript: void(0);" class="filter-menu-item" :class="{ active: selectedCategory === 'web' }" @click="selectCategory('web')">Web Design</a>
            <a href="javascript: void(0);" class="filter-menu-item" :class="{ active: selectedCategory === 'graphic' }" @click="selectCategory('graphic')">Graphic Design</a>
            <a href="javascript: void(0);" class="filter-menu-item" :class="{ active: selectedCategory === 'illustrator' }" @click="selectCategory('illustrator')">Illustrator</a>
            <a href="javascript: void(0);" class="filter-menu-item" :class="{ active: selectedCategory === 'photography' }" @click="selectCategory('photography')">Photography</a>
          </div>
        </b-col>
      </b-row>

      <div class="mt-5">
        <b-row class="grid-portfolio" id="filterable-content">
          <b-col sm="6" xl="4" class="filter-item all web illustrator" v-for="(item, idx) in filteredPortfolio"
            :key="idx">
            <b-card no-body class="card-portfolio-item shadow border filter-item all web graphic">
              <div class="p-2">
                <div class="card-zoom">
                  <a :href="item.image" class="image-popup" :data-title="item.title">
                    <img :src="item.image" class="card-img-top" alt="work-thumbnail">
                  </a>
                </div>
              </div>
              <b-card-body class="p-2">
                <div class="mt-2">
                  <h5 class="mt-0">{{ item.title }}</h5>
                  <p class="text-muted mb-1">{{ item.description }}</p>
                </div>
              </b-card-body>
            </b-card>
          </b-col>
        </b-row>
      </div>

      <div class="text-center mt-5 pb-md-0">
        <a class="btn btn-primary" href="#"><i data-feather="refresh-ccw" class="icon-xxs me-2"></i>Load More</a>
      </div>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import GLightbox from 'glightbox';
import { portfolio } from "@/views/pages/portfolio/grid/components/data";

const selectedCategory = ref('all');

const filteredPortfolio = computed(() => {
  if (selectedCategory.value === 'all') {
    return portfolio;
  }
  return portfolio.filter(item =>
    item.categories?.includes(selectedCategory.value)
  );
});

const selectCategory = (category: string) => {
  selectedCategory.value = category;
};

onMounted(() => {
  GLightbox({
    selector: '.image-popup'
  });
});
</script>