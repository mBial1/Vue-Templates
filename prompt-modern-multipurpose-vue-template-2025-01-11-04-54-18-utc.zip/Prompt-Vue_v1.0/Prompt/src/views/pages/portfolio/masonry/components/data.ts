import photos3 from "@/assets/images/photos/3.jpg";
import photos4 from "@/assets/images/photos/4.jpg";
import photos5 from "@/assets/images/photos/5.jpg";
import photos6 from "@/assets/images/photos/6.jpg";
import photos9 from "@/assets/images/photos/9.jpg";
import photos12 from "@/assets/images/photos/12.jpg";
import photos13 from "@/assets/images/photos/13.jpg";
import photos14 from "@/assets/images/photos/14.jpg";
import photos15 from "@/assets/images/photos/15.jpg";
import { PortfolioType } from "@/types";

export const portfolio: PortfolioType[] = [
  {
    category: "graphic",
    title: "Smart Desk v2.0",
    image: photos9,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "graphic",
    title: "Iphone App",
    image: photos14,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "photography",
    title: "Iphone App2",
    image: photos15,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "graphic",
    title: "Virtual Receptionist",
    image: photos6,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "web",
    title: "Task Manager",
    image: photos5,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "illustrator",
    title: "Task Manager2",
    image: photos12,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "photography",
    title: "Portfolio Manager",
    image: photos3,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "web",
    title: "Online Conference",
    image: photos15,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "illustrator",
    title: "Smart Office v2.0",
    image: photos4,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  },
  {
    category: "illustrator",
    title: "Virtual Receptionist 2",
    image: photos13,
    description: "Nemo enim ipsam voluptatem quia voluptas sit aspernatur"
  }
];