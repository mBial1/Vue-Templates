<template>
  <Hero />
  <Content />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/pages/portfolio/masonry/components/Hero.vue";
import Content from "@/views/pages/portfolio/masonry/components/Content.vue";
import Footer from "@/views/pages/portfolio/masonry/components/Footer.vue";
</script>