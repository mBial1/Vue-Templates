<template>
  <section class="overflow-hidden py-5 py-md-6 py-lg-7">
    <b-container>
      <b-row>
        <b-col cols="12">
          <div class="filter-options text-center filter-menu" data-menu-item=".filter-menu-item"
            data-target-container="#filterable-content">
            <a href="javascript:void(0);" class="filter-menu-item active" data-group='all'>All</a>
            <a href="javascript:void(0);" class="filter-menu-item" data-group='web'>Web Design</a>
            <a href="javascript:void(0);" class="filter-menu-item" data-group='graphic'>Graphic Design</a>
            <a href="javascript:void(0);" class="filter-menu-item" data-group='illustrator'>Illustrator</a>
            <a href="javascript:void(0);" class="filter-menu-item" data-group='photography'>Photography</a>
          </div>
        </b-col>
      </b-row>
      <div data-toggle="image-gallery" data-delegate="a" data-type="image" data-enable-gallery="true" class="mt-5">
        <div class="masonry-grid position-relative masonry" id="filterable-content">
          <div class="masonry-item picture-item" v-for="(item, idx) in portfolio" :key="idx"
            :data-groups="JSON.stringify([item.category])">
            <b-card no-body class="card-portfolio-item mb-0 shadow border filter-item">
              <div class="p-2">
                <div class="card-zoom">
                  <a :href="item.image" class="image-popup" :data-title="item.title">
                    <img :src="item.image" class="card-img-top" alt="work-thumbnail" />
                  </a>
                </div>
              </div>
              <b-card-body class="p-2">
                <h5 class="mt-2">{{ item.title }}</h5>
                <p class="text-muted mb-1">{{ item.description }}</p>
              </b-card-body>
            </b-card>
          </div>
        </div>
      </div>

      <div class="text-center mt-5 pb-md-0">
        <a class="btn btn-primary" href="#"><i data-feather="refresh-ccw" class="icon-xxs me-2"></i>Load More</a>
      </div>
    </b-container>
  </section>
</template>

<script setup lang="ts">
import { onMounted } from "vue";
import { portfolio } from "@/views/pages/portfolio/masonry/components/data";
import GLightbox  from 'glightbox';
import Shuffle from "shufflejs";

onMounted(() => {
  const filterableContent = document.getElementById("filterable-content");
  if (filterableContent) {
    const demo = new Demo(filterableContent);


    setInterval(() => {
      demo.shuffle.filter('all');
    }, 100);
  }


  GLightbox({
    selector: '.image-popup'
  });
});

class Demo {
  element: HTMLElement;
  shuffle: any;

  constructor(element: HTMLElement) {
    this.element = element;
    this.shuffle = new Shuffle(element, {
      itemSelector: ".picture-item",
    });

    this.addFilterButtons();
  }

  addFilterButtons() {
    const options = document.querySelector(".filter-options");
    if (!options) {
      return;
    }

    const filterButtons = Array.from(options.children);
    filterButtons.forEach(button => {
      button.addEventListener("click", (evt) => this.handleFilterClick(evt as MouseEvent), false);
    });
  }

  handleFilterClick(evt: MouseEvent) {
    const button = evt.currentTarget as HTMLElement;
    const buttonGroup = button.getAttribute("data-group");

    if (buttonGroup) {
      this.removeActiveClassFromChildren(button.parentNode as HTMLElement);
      button.classList.add("active");
      this.shuffle.filter(buttonGroup === 'all' ? () => true : buttonGroup);
    }
  }

  removeActiveClassFromChildren(parent: HTMLElement) {
    const { children } = parent;
    Array.from(children).forEach(child => child.classList.remove("active"));
  }
}
</script>