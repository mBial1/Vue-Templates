<template>
  <section class="py-6 position-relative">
    <b-container>
      <b-row class="justify-content-lg-between">
        <b-col lg="12">
          <div class="d-flex align-items-center mb-5">
            <h5 class="me-2 fw-medium">Tags:</h5>
            <div>
              <a class="btn btn-sm btn-white mb-1" href="#">Business</a>{{ ' ' }}
              <a class="btn btn-sm btn-white mb-1" href="#">Community</a>{{ ' ' }}
              <a class="btn btn-sm btn-white mb-1" href="#">Announcement</a>{{ ' ' }}
              <a class="btn btn-sm btn-white mb-1" href="#">Tutorials</a>{{ ' ' }}
              <a class="btn btn-sm btn-white mb-1" href="#">Resources</a>{{ ' ' }}
              <a class="btn btn-sm btn-white mb-1" href="#">Interview</a>
            </div>
          </div>
        </b-col>

        <b-col lg="12">
          <b-row data-aos="fade-up" data-aos-duration="300">
            <b-col lg="8">
              <b-card no-body class="shadow-none">
                <b-row>
                  <b-col md="5">
                    <img class="img-fluid rounded-sm" :src="post1" alt="post img">
                  </b-col>
                  <b-col md="7">
                    <b-card-body class="d-flex flex-column h-100 py-0 ps-2 pe-3">
                      <a class="" href="#">
                    <b-badge :variant="null" class="badge-soft-orange mb-1">Announcement</b-badge>
                      </a>

                      <h3 class="mt-1 fw-semibold">
                        <router-link class="" :to="{ name: 'blog.post' }">
                          Announcing the free upgrade for the subscribed plans
                        </router-link>
                      </h3>

                      <p class="text-muted">
                        We are glad to announce that, we are going to upgrade all the subscribed
                        accounts with the premium features this week...
                        <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                      </p>

                      <div class="mt-auto">
                        <div class="d-flex">
                          <img class="me-2 rounded-sm" :src="img4" alt="" height="36">
                          <div class="flex-grow-1">
                            <h6 class="m-0 fs-13"><a href="">Emily Blunt</a></h6>
                            <p class="text-muted mb-0 fs-13">11 Mar, 2020 · 3 min read</p>
                          </div>
                        </div>
                      </div>
                    </b-card-body>
                  </b-col>
                </b-row>
              </b-card>
            </b-col>
            <b-col lg="4">
              <div class="border rounded px-4 py-3">
                <div class="mb-4">
                  <h4 class="mt-0">
                    Get the latest on product development from {{ appName }}
                  </h4>
                  <p class="text-muted">We send a weekly newsletter containing latest updates in product development</p>
                </div>

                <form novalidate>
                  <label class="visually-hidden form-label" for="email">Subscribe</label>
                  <div class="mb-2">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter Your Email"
                      aria-label="Enter Your Email" required>
                  </div>
                  <a href="javascript:void(0);" type="submit" class="btn btn-primary d-block mb-1">Subscribe</a>
                  <p><small>*No spam ever.</small></p>
                </form>
              </div>
            </b-col>
          </b-row>

          <b-row class="mt-6" data-aos="fade-up">
            <b-col lg="4">
              <div>
                <img :src="crypto1" alt="crypto" class="img-fluid d-block shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-orange mb-1">Announcement</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    Introducing new blazzing fast user interface
                  </router-link>
                </h4>

                <p class="text-muted">
                  Introducing the blazzing fast user interface. The new UI is fast, secure and most
                  user friendly...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>

            <b-col lg="4">
              <div>
                <img :src="crypto2" alt="app img" class="img-fluid shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-success mb-1">Tutorial</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    What you should know before considering the {{ appName }}
                  </router-link>
                </h4>

                <p class="text-muted">
                  We are giving a pretty extensive guideline and context before you make your decision
                  to consider {{ appName }}...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>

            <b-col lg="4">
              <div>
                <img :src="crypto1" alt="crypto" class="img-fluid d-block shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-info mb-1">Community</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    Your Way to a Successful Sales Campaigns
                  </router-link>
                </h4>

                <p class="text-muted">
                  Explore a latest guideline for creating a successful online sales campaign using google adwords or
                  facebook ads...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>
          </b-row>

          <b-row class="mt-6" data-aos="fade-up">
            <b-col lg="8" class="h-100">
              <b-card no-body class="shadow-none">
                <b-row class="h-100">
                  <b-col md="5">
                    <img class="img-fluid rounded-sm" :src="post1" alt="post img">
                  </b-col>
                  <b-col md="7">
                    <b-card-body class="d-flex flex-column h-100 p-0 px-2">
                      <a class="" href="#">
                        <b-badge :variant="null" class="badge-soft-info mb-1">Community</b-badge>
                      </a>

                      <h3 class="mt-1 fw-semibold">
                        <router-link class="" :to="{ name: 'blog.post' }">
                          Will Web Design Ever Rule the World?
                        </router-link>
                      </h3>

                      <p class="text-muted">
                        The web is changed in the current era a lot. Many new trends are being
                        used in the market at the moment...
                        <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                      </p>

                      <div class="mt-auto">
                        <div class="d-flex">
                          <img class="me-2 rounded-sm" :src="img2" alt="" height="36">
                          <div class="flex-grow-1">
                            <h6 class="m-0 fs-13"><a href="">Greeva N</a></h6>
                            <p class="text-muted mb-0 fs-13">9 Mar, 2020 · 5 min read
                            </p>
                          </div>
                        </div>
                      </div>
                    </b-card-body>
                  </b-col>
                </b-row>
              </b-card>
            </b-col>

            <b-col lg="4">
              <b-card no-body class="card-listing-item">
                <div class="card-img-top-overlay">
                  <div class="overlay"></div>
                  <span class="card-badge top-right bg-danger text-white">Resource</span>
                  <img :src="post3" alt="" class="card-img-top" />

                  <div class="card-overlay-bottom">
                    <h2 class="fw-semibold">
                      <router-link :to="{ name: 'blog.post' }" class="text-white">Top 10 ideas to improve the team
                        productivity</router-link>
                    </h2>

                    <div class="avatar-group mt-auto">
                      <a href="" class="avatar-group-item shadow-lg">
                        <img :src="img7" alt="img" class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                      </a>
                      <a href="" class="avatar-group-item shadow-lg">
                        <img :src="img2" alt="img" class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                      </a>
                      <a href="" class="avatar-group-item shadow-lg">
                        <img :src="img4" alt="img" class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                      </a>
                    </div>
                  </div>
                </div>
              </b-card>
            </b-col>
          </b-row>

          <b-row class="mt-6" data-aos="fade-up">
            <b-col lg="4">
              <div>
                <img :src="crypto1" alt="crypto" class="img-fluid shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-orange mb-1">Announcement</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    Introducing new blazzing fast user interface
                  </router-link>
                </h4>

                <p class="text-muted">
                  Introducing the blazzing fast user interface. The new UI is fast, secure and most
                  user friendly...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>

            <b-col lg="4">
              <div>
                <img :src="crypto2" alt="app img" class="img-fluid shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-success mb-1">Tutorial</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    What you should know before considering the {{ appName }}
                  </router-link>
                </h4>

                <p class="text-muted">
                  We are giving a pretty extensive guideline and context before you make your decision
                  to consider {{ appName }}...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>

            <b-col lg="4">
              <div>
                <img :src="crypto1" alt="crypto" class="img-fluid shadow rounded" />

                <div class="mt-3">
                  <a href="#">
                    <b-badge :variant="null" class="badge-soft-info mb-1">Community</b-badge>
                  </a>
                </div>

                <h4 class="fw-semibold mt-1">
                  <router-link class="" :to="{ name: 'blog.post' }">
                    Your Way to a Successful Sales Campaigns
                  </router-link>
                </h4>

                <p class="text-muted">
                  Explore a latest guideline for creating a successful online sales campaign using google adwords or
                  facebook ads...
                  <router-link :to="{ name: 'blog.post' }" class="text-primary">read more</router-link>
                </p>
              </div>
            </b-col>
          </b-row>


          <b-row class="mt-5">
            <b-col lg="12">
              <div class="d-flex align-items-center justify-content-center">
                <a class="btn btn-sm btn-white" href="javascript:void(0)"><i
                    class="icon icon-xxs icon-left-arrow me-2"></i>Previous</a>
                <a class="btn btn-sm btn-white ms-2" href="javascript:void(0)">Next<i
                    class="icon-xxs icon-right-arrow ms-2"></i></a>
              </div>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import post1 from "@/assets/images/blog/post1.jpg";
import post3 from "@/assets/images/blog/post3.jpg";
import crypto1 from "@/assets/images/blog/crypto1.jpg";
import crypto2 from "@/assets/images/blog/crypto2.jpg";

import img7 from "@/assets/images/avatars/img-7.jpg";
import img2 from "@/assets/images/avatars/img-2.jpg";
import img4 from "@/assets/images/avatars/img-4.jpg";
</script>