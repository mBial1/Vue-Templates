<template>
  <div class="header-7" :style="`background: url(${hero}) no-repeat`">
    <div class="overlay"></div>
    <Navbar topbarColor="navbar-dark" classList="ms-auto" ctaButtonClass="btn-white text-white btn-sm" />
    <section class="hero-4 pb-5 pt-8 pt-lg-6 pb-lg-8">
      <b-container>
        <b-row class="justify-content-center">
          <b-col lg="7" class="text-center position-relative">
            <h1 class="hero-title text-white">Blog</h1>
            <p class="mt-4 fs-17 text-white">Nemo enim ipsam voluptatem quia voluptas sit aspernatur
              aut odit aut fugit sed consequuntur ratione voluptatem sequi nesciunt.</p>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import hero from "@/assets/images/blog/hero.jpg";
</script>