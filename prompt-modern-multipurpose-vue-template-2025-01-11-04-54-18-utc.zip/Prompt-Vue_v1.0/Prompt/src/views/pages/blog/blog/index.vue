<template>
  <Hero />
  <Listing />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/pages/blog/blog/components/Hero.vue";
import Listing from "@/views/pages/blog/blog/components/Listing.vue";
import Footer from "@/views/pages/blog/blog/components/Footer.vue";
</script>