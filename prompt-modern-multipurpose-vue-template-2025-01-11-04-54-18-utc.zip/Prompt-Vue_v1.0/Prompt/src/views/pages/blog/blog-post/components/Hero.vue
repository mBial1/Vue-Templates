<template>
  <section class="hero-4 pb-5 pt-8 pt-lg-6 pb-sm-4">
    <b-container>
      <b-row class="justify-content-center">
        <b-col lg="12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Blog</a></li>
              <li class="breadcrumb-item active" aria-current="page">Announcing-the-free-upgrade</li>
            </ol>
          </nav>

          <div class="mt-4">
            <a href="#">
              <b-badge :variant="null" class="badge-soft-orange mb-1">Announcement</b-badge>
            </a>
          </div>
          <h1 class="hero-title mt-0">Announcing the free upgrade for the subscribed plans</h1>
        </b-col>
      </b-row>

      <b-row class="mt-4 align-items-center">
        <div class="col-auto">
          <div class="d-flex align-items-center">
            <img class="me-2 avatar avatar-sm rounded-circle avatar-border" :src="avatar4" alt="" />

            <div>
              <h5 class="m-0"><a href="">Emily Blunt</a></h5>
              <p class="text-muted mb-0 fs-13">11 Mar, 2020 · 3 min read</p>
            </div>
          </div>
        </div>
        <b-col>
          <div class="text-md-end">
            <ul class="list-inline mb-0 hstack gap-1">
              <li class="list-inline-item text-muted align-middle me-2 text-uppercase fs-13 fw-medium">Share:</li>
              <li class="list-inline-item me-2 align-middle">
                <a href="#">
                  <i class="icon-xs icon-dual-primary" data-feather="facebook"></i>
                </a>
              </li>
              <li class="list-inline-item me-2 align-middle">
                <a href="#">
                  <i class="icon-xs icon-dual-info" data-feather="twitter"></i>
                </a>
              </li>
              <li class="list-inline-item align-middle">
                <a href="#">
                  <i class="icon-xs icon-dual-danger" data-feather="instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import avatar4 from "@/assets/images/avatars/img-4.jpg"
</script>