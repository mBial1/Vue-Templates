<template>
  <Navbar topbarColor="navbar-light" classList="mx-auto shadow" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <Content />
  <Navigation />
  <Comments />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/blog/blog-post/components/Hero.vue";
import Content from "@/views/pages/blog/blog-post/components/Content.vue";
import Navigation from "@/views/pages/blog/blog-post/components/Navigation.vue";
import Comments from "@/views/pages/blog/blog-post/components/Comments.vue";
import Footer from "@/views/pages/blog/blog-post/components/Footer.vue";
</script>