<template>
  <section class="position-relative pb-5">
    <b-container>
      <b-row>
        <b-col lg="12">
          <div>
            <h4 class="mb-3">Comments
              <b-badge :variant="null" class="badge-soft-secondary fs-14 align-middle ms-1">3</b-badge>
            </h4>

            <div class="d-flex align-items-top mt-4">
              <img class="me-2 rounded-sm" :src="avatar2" alt="" height="36">
              <div class="flex-grow-1">
                <h6 class="m-0">Sansa Stark </h6>
                <p class="text-muted mb-0"><small>2 days ago</small></p>

                <p class="my-1">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                  voluptatum deleniti atque.</p>

                <div>
                  <a href="javascript: void(0);" class="btn btn-sm btn-link text-primary fw-medium p-0">
                    <i class="icon-xxs icon me-1" data-feather="message-circle"></i>Reply
                  </a>
                </div>

                <div class="d-flex align-items-top mt-4">
                  <img class="me-2 rounded-sm" :src="avatar6" alt="" height="36">
                  <div class="flex-grow-1">
                    <h6 class="m-0">Cersei Lannister </h6>
                    <p class="text-muted mb-0"><small>1 day ago</small></p>

                    <p class="my-1">Itaque earum rerum hic tenetur sapiente delectus aut reiciendis voluptatibus maiores
                      alias consequatur aut perferendis</p>
                    <div>
                      <a href="javascript: void(0);" class="btn btn-sm btn-link text-primary fw-medium p-0">
                        <i class="icon-xxs icon me-1" data-feather="message-circle"></i>Reply
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <hr class="my-4" />

            <div class="d-flex align-items-top mt-4">
              <img class="me-2 rounded-sm" :src="avatar2" alt="" height="36">
              <div class="flex-grow-1">
                <h6 class="m-0">Sansa Stark </h6>
                <p class="text-muted mb-0"><small>2 days ago</small></p>

                <p class="my-1">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                  voluptatum deleniti atque.</p>

                <div>
                  <a href="javascript: void(0);" class="btn btn-sm btn-link text-primary fw-medium p-0">
                    <i class="icon-xxs icon me-1" data-feather="message-circle"></i>Reply
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-5 mb-lg-0 mb-5">
            <b-card no-body class="border">
              <b-card-body class="p-4">
                <h4 class="mb-3 mt-0">Post a comment</h4>

                <form>
                  <b-row>
                    <b-col md="6">
                      <div class="mb-3">
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" />
                      </div>
                    </b-col>
                    <b-col md="6">
                      <div class="mb-3">
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" />
                      </div>
                    </b-col>
                    <b-col md="12">
                      <div class="mb-3">
                        <input type="text" class="form-control" id="exampleInputSubject1" placeholder="Subject" />
                      </div>
                    </b-col>
                    <b-col md="12">
                      <div class="mb-3">
                        <b-form-textarea type="textarea" rows="3" id="exampleFormControlTextarea1" placeholder="Message" />
                      </div>
                      <b-button type="submit" variant="secondary">Submit</b-button>
                    </b-col>
                  </b-row>
                </form>
              </b-card-body>
            </b-card>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import avatar2 from "@/assets/images/avatars/img-2.jpg"
import avatar6 from "@/assets/images/avatars/img-6.jpg"
</script>