<template>
  <section class="position-relative pb-5">
    <b-container>
      <b-row class="border-top border-bottom py-4 align-items-center">
        <b-col lg="2" cols="6">
          <a class="btn btn-white" href="#" data-bs-toggle="popover" data-bs-placement="top" data-bs-trigger="hover"
            data-bs-html="true" data-bs-content="<div class='d-flex align-items-center'>
                                            <img src='/assets/images/blog/post1.jpg' width='60' class='me-3 rounded-sm' alt='thumb'>
                                            <div class='flex-grow-1'>
                                                <h6 class='fs-14 fw-semibold mt-0 mb-1'>Introducing new blazzing fast user interface</h6>
                                                <span class='d-block fs-13 text-muted'>by Emily Blunt</span>
                                            </div>
                                        </div>" title="">
            <i class="icon-xs icon-left-arrow me-2"></i>
            <span class="d-none d-sm-inline-flex ms-1">Prev Post</span>
          </a>
        </b-col>
        <b-col lg="6" class="offset-lg-1">
          <div class="d-flex justify-content-lg-center py-lg-0 py-4">
            <div class="d-flex align-items-center">
              <img class="me-3 avatar avatar-sm rounded-circle align-self-center" :src="avatar4" alt="" />

              <div class="flex-grow-1">
                <h5 class="m-0">
                  <a href="">Emily Blunt</a>
                </h5>
                <p class="text-muted mb-0 fs-14">
                  I write about the latest trend in web design and development.
                </p>
              </div>
            </div>
          </div>
        </b-col>
        <b-col lg="2" cols="6" class="offset-lg-1 text-lg-end text-start">
          <a class="btn btn-white" href="#" data-bs-toggle="popover" data-bs-placement="top" data-bs-trigger="hover"
            data-bs-html="true" data-bs-content="<div class='d-flex align-items-center'>
                                            <img src='/assets/images/blog/post2.jpg' width='60' class='me-3 rounded-sm' alt='thumb'>
                                            <div class='flex-grow-1>
                                                <h6 class='fs-14 fw-semibold mt-0 mb-1'>What you should know before...</h6>
                                                <span class='d-block fs-13 text-muted'>by Emily Blunt</span>
                                            </div>
                                        </div>" title="">
            <span class="d-none d-sm-inline-flex me-1">Next Post</span>
            <i class="icon-xs icon-right-arrow ms-2"></i>
          </a>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import avatar4 from "@/assets/images/avatars/img-4.jpg";
</script>