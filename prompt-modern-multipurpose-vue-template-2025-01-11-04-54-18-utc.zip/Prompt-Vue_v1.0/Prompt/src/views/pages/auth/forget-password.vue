<template>
  <div class="bg-gradient2 min-vh-100 align-items-center d-flex justify-content-center pt-2 pt-sm-5 pb-4 pb-sm-5">
    <b-container>
      <b-row class="justify-content-center">
        <b-col md="10" lg="8" xl="6">
          <b-card no-body>
            <b-card-body class="p-0">
              <div class="p-xl-5 p-3">
                <div class="mx-auto mb-5">
                  <router-link to="/" class="d-flex">
                    <img src="@/assets/images/logo.png" class="align-self-center" alt="logo-img" height="30" />
                  </router-link>
                </div>

                <h6 class="h5 mb-0 mt-3">Reset Password</h6>
                <p class="text-muted mt-1 mb-4">Enter your email address and we'll send you an email with instructions
                  to reset your password.</p>

                <form action="#" class="authentication-form">
                  <b-form-group label="Email *" label-for="exampleInputEmail1" class="mb-3">
                    <b-form-input type="email" id="exampleInputEmail1" placeholder="Email" />
                  </b-form-group>

                  <div class="mb-0 text-center pt-3 d-grid">
                    <b-button variant="primary" type="submit">Submit</b-button>
                  </div>
                </form>
              </div>
            </b-card-body>
          </b-card>

          <b-row class="mt-3">
            <b-col cols="12" class="text-center">
              <p class="text-muted">Back to
                <router-link :to="{ name: 'auth.login' }" class="text-primary fw-semibold ms-1">Log In</router-link>
              </p>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>
<script setup lang="ts">
</script>