<template>
    <h4 class="mt-0">Account Information</h4>

    <form action="#" class="account-form">

        <h6 class="mt-4">Your Avatar</h6>
        <b-row class="align-items-center">
            <div class="col-auto">
                <img :src="avatar8" class="img-fluid avatar-md rounded-circle shadow" alt="..." />
            </div>
            <b-col>
                <a href="#" class="btn btn-outline-primary btn-sm me-1">Upload</a>
                <a href="#" class="btn btn-outline-danger btn-sm ms-2">Remove</a>
            </b-col>
        </b-row>

        <hr class="my-4" />

        <b-row class="align-items-center">
            <b-col lg="6">
                <b-form-group label="Name*" label-for="name" class="mb-3">
                    <b-form-input type="text" placeholder="Your Name" id="name" model-value="Greeva Navadiya" />
                </b-form-group>
                <b-form-group label="Email*" label-for="email" class="mb-3">
                    <b-form-input type="text" placeholder="Email" id="email" model-value="greeva@coderthemes.com" />
                </b-form-group>
            </b-col>

            <b-col lg="6">
                <b-form-group label="Display name" label-for="display_name" class="mb-3">
                    <b-form-input type="text" placeholder="Display Name" id="display_name" model-value="Greeva N" />
                </b-form-group>
                <b-form-group label="Phone*" label-for="phone" class="mb-3">
                    <b-form-input type="text" placeholder="Phone number" id="phone" model-value="+1 254 024 5400" />
                </b-form-group>
            </b-col>
        </b-row>

        <hr class="my-2" />

        <b-row class="my-3">
            <b-col lg="12">
                <div class="mb-3">
                    <label class="form-label">Profile Visibility</label>

                    <div class="mt-1">
                        <div class="form-check form-check-inline">
                            <input type="radio" class="form-check-input" id="visibilityPublic" name="visibility" checked>
                            <label class="form-check-label" for="visibilityPublic">Public</label>
                        </div>

                        <div class="form-check form-check-inline ms-3">
                            <input type="radio" class="form-check-input" name="visibility" id="visibilityPrivate">
                            <label class="form-check-label" for="visibilityPrivate">Private</label>
                        </div>
                    </div>

                    <small class="form-text text-muted mt-2">
                        Making your profile public means anyone can see your information
                    </small>
                </div>
            </b-col>
            <b-col lg="12" class="mt-2">
                <div class="mb-3 mb-0">
                    <label class="form-label">Contact Info
                        Visibility</label>

                    <div class="mt-1">
                        <div class="form-check form-check-inline">
                            <input type="radio" class="form-check-input" id="visibilityPublic1" name="visibility1"
                                checked>
                            <label class="form-check-label" for="visibilityPublic1">Public</label>
                        </div>

                        <div class="form-check form-check-inline ms-3">
                            <input type="radio" class="form-check-input" name="visibility1" id="visibilityPrivate1">
                            <label class="form-check-label" for="visibilityPrivate1">Private</label>
                        </div>
                    </div>

                    <small class="form-text text-muted mt-2">
                        Making your contact info public means anyone can see your email and phone number
                    </small>
                </div>
            </b-col>
        </b-row>

        <hr class="mb-2" />

        <b-row>
            <b-col lg="12">
                <b-row class="align-items-center my-2">
                    <b-col>
                        <label class="form-label mb-0">
                            Remove account
                        </label>
                        <small class="form-text text-muted">
                            By removing your account you will lose all your data
                        </small>
                    </b-col>
                    <div class="col-lg-auto text-end">
                        <b-button type="button" size="sm" variant="outline-danger">Remove Account</b-button>
                    </div>
                </b-row>
            </b-col>
        </b-row>

        <hr class="my-4" />

        <b-row class="mt-2">
            <b-col lg="12">
                <b-button type="submit" variant="primary">Save Changes</b-button>
            </b-col>
        </b-row>
    </form>
</template>
<script setup lang="ts">
import avatar8 from "@/assets/images/avatars/img-8.jpg"
</script>