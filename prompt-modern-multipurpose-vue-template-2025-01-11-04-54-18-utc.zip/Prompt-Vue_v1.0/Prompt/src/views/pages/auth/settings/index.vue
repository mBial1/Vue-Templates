<template>
  <DashboardNavbar topbarColor="navbar-light" classList="mx-auto" />
  <section class="position-relative p-3 bg-gradient2">
    <b-container>
      <b-row>
        <b-col lg="12">
          <div class="page-title">
            <h3 class="my-0">Account Settings</h3>
            <p class="mt-1 fw-medium">Change your account settings</p>
          </div>
        </b-col>
      </b-row>
      <b-row class="mt-2">
        <b-col lg="12">
          <b-card no-body>
            <b-card-body>
              <b-row>
                <b-col lg="3">
                  <ul class="nav navtab-bg nav-pills flex-column">
                    <li class="nav-item">
                      <a href="#/" class="nav-link" :class="show === 1 && 'active'" @click="show = 1">
                        <span>Account</span>
                      </a>
                    </li>
                    <li class="nav-item my-2">
                      <a href="#/" class="nav-link" :class="show === 2 && 'active'" @click="show = 2">
                        <span>Password</span>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a href="#/" class="nav-link" :class="show === 3 && 'active'" @click="show = 3">
                        <span>Notifications</span>
                      </a>
                    </li>
                  </ul>
                </b-col>
                <b-col lg="9">
                  <div class="tab-content p-0">
                    <div class="tab-pane fade px-3" :class="show === 1 && 'show active'" id="account">
                      <AccountInfo />
                    </div>

                    <div class="tab-pane fade px-3" :class="show === 2 && 'show active'" id="password" style="min-height: 600px;">
                      <Password />
                    </div>

                    <div class="tab-pane fade px-3" :class="show === 3 && 'show active'" id="notifications-form" style="min-height: 600px;">
                      <Notifications />
                    </div>
                  </div>
                </b-col>
              </b-row>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </section>

  <Footer />
</template>
<script setup lang="ts">
import { ref } from "vue";
import DashboardNavbar from "@/components/navbar/DashboardNavbar.vue";
import AccountInfo from "@/views/pages/auth/settings/components/AccountInfo.vue";
import Password from "@/views/pages/auth/settings/components/Password.vue";
import Notifications from "@/views/pages/auth/settings/components/Notifications.vue";
import Footer from "@/views/pages/auth/settings/components/Footer.vue";

const show = ref(1)
</script>