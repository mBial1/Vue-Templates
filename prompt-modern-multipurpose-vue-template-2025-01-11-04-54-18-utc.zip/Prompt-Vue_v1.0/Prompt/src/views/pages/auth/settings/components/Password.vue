<template>
    <h4 class="mt-0">Password</h4>
    <form action="#" class="password-form mt-4">
        <b-form-group label="Current Password*" label-for="current_password" class="mb-3">
            <b-form-input type="password" id="current_password" />
        </b-form-group>
        <b-form-group label="New Password*" label-for="new_password" class="mb-3">
            <b-form-input type="password" id="new_password" />
        </b-form-group>
        <b-form-group label="Confirm Password*" label-for="confirm_password" class="mb-3">
            <b-form-input type="password" id="confirm_password" />
        </b-form-group>
        <hr class="my-4" />
        <b-row class="mt-3">
            <b-col lg="12">
                <b-button type="submit" variant="primary">Update Password</b-button>
            </b-col>
        </b-row>
    </form>
</template>
<script setup lang="ts">
</script>