<template>
    <h4 class="mt-0">Notifications</h4>
    <form action="#" class="password-form mt-4">
        <div class="mb-3">
            <label for="name">Send me an email, when</label>
            <ul class="list-unstyled">
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="mention" checked>
                        <label class="form-check-label" for="mention">Someone mentions me</label>
                    </div>
                </li>
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="replies">
                        <label class="form-check-label" for="replies">Someone replies to me</label>
                    </div>
                </li>
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="share-content" checked>
                        <label class="form-check-label" for="share-content">Someone shares the content</label>
                    </div>
                </li>
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="new-content">
                        <label class="form-check-label" for="new-content">There is a new published content</label>
                    </div>
                </li>
            </ul>
        </div>

        <hr class="my-4" />
        <div class="mb-3">
            <label for="name">Other Subscriptions</label>
            <ul class="list-unstyled">
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="newsletter" checked>
                        <label class="form-check-label" for="newsletter">Weekly newsletter</label>
                    </div>
                </li>
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="weekly-jobs">
                        <label class="form-check-label" for="weekly-jobs">Weekly jobs</label>
                    </div>
                </li>
                <li class="mt-2">
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="events" checked>
                        <label class="form-check-label" for="events">Events new me</label>
                    </div>
                </li>
            </ul>
        </div>
        <hr class="my-4" />

        <b-row class="mt-3">
            <b-col lg="12">
                <b-button type="submit" variant="primary">Update Preferences</b-button>
            </b-col>
        </b-row>
    </form>
</template>
<script setup lang="ts">
</script>