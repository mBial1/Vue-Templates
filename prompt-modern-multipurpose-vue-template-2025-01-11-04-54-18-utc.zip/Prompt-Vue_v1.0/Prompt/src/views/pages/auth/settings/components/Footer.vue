<template>
  <section class="section py-4 position-relative">
    <b-container>
      <b-row class="align-items-center">
        <b-col>
          <ul class="list-inline list-with-separator mb-0">
            <li class="list-inline-item me-0"><a href="#">About</a></li>
            <li class="list-inline-item me-0"><a href="#">Privacy</a></li>
            <li class="list-inline-item me-0"><a href="#">Terms</a></li>
            <li class="list-inline-item me-0"><a href="#">Developers</a></li>
            <li class="list-inline-item me-0"><a href="#">Support</a></li>
            <li class="list-inline-item me-0">
              <a href="#">Careers
                <b-badge :variant="null" pill class="badge-soft-info align-middle fw-normal fs-11 px-2 py-1">We're hiring</b-badge>
              </a>
            </li>
          </ul>
        </b-col>
        <div class="col-md-auto text-md-end mt-2 mt-md-0">
          <p class="fs-14 mb-0">
            {{ currentYear }} © {{ appName }}. All rights reserved. Crafted by
            <a :href="developedByLink">{{ developedBy }}</a>
          </p>
        </div>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { currentYear, appName, developedBy, developedByLink } from "@/helpers/constants";
</script>