<template>
  <b-row>
    <b-col lg="12">
      <div class="page-title">
        <h3 class="mb-0">Hi Greeva</h3>
        <p class="mt-1 fw-medium">Welcome to {{appName}}!</p>
      </div>
    </b-col>
  </b-row>
  <b-row class="mt-2">
    <b-col lg="5">
      <b-card no-body>
        <b-card-body>
          <b-row>
            <b-col>
              <div class="d-flex">
                <img :src="avatar8" class="img-fluid avatar-sm rounded-sm me-3" alt="..." />
                <div class="flex-grow-1">
                  <h4 class="mb-1 mt-0 fs-16">Ms. Greeva Navadiya</h4>
                  <p class="text-muted pb-0 fs-14">Web & Graphic Designer</p>
                </div>
              </div>
            </b-col>
            <div class="col-auto text-end">
              <DropDown>
                <a class="btn-link text-muted dropdown-toggle arrow-none" href="#" role="button" id="dropdownMenuLink-1"
                  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon icon-xs" data-feather="more-horizontal"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink-1">
                  <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="edit"></i>Edit</a>
                  <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2"
                      data-feather="refresh-cw"></i>Refresh</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item text-danger" href="#"><i class="icon-xxs icon me-2"
                      data-feather="trash-2"></i>Deactivate</a>
                </div>
              </Dropdown>
            </div>
          </b-row>

          <ul class="list-inline py-3 border-bottom">
            <li class="list-inline-item mb-sm-0 mb-2 me-sm-2">
              <a href="#" class="text-muted fs-14">{{ ' ' }}<i class="icon-xs icon me-1"
                  data-feather="mail"></i>greeva@coderthemes.com</a>
            </li>
            <li class="list-inline-item mb-sm-0 mb-2">
              <a href="#" class="text-muted fs-14"><i class="icon-xxs icon me-2" data-feather="phone"></i>+00
                123-456-789</a>
            </li>
          </ul>

          <b-row class="align-items-center pt-1">
            <b-col md="6">
              <p class="float-end mb-0">85%</p>
              <h6 class="fw-medium my-0">Project Completion</h6>
              <b-progress variant="primary" class="mt-3" style="height: 6px;" :value="85" />
            </b-col>
            <b-col md="6" class="mt-sm-0 mt-4">
              <p class="float-end mb-0">7.5</p>
              <h6 class="fw-medium my-0">Overall Rating</h6>
              <b-progress class="mt-3" style="height: 6px;">
                <b-progress-bar :variant="null" class="bg-orange" :value="75" />
              </b-progress>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>

    <b-col lg="3">
      <b-card no-body>
        <b-card-body>
          <div class="d-flex align-items-center">
            <div class="avatar-sm icon icon-with-bg icon-xs rounded-sm bg-soft-success me-3">
              <i class="icon-dual-success" data-feather="check-circle"></i>
            </div>
            <div class="flex-grow-1">
              <h3 class="mt-0 mb-0">21</h3>
              <p class="text-muted mb-0">Tasks Completed</p>
            </div>
          </div>
        </b-card-body>
      </b-card>
      <b-card no-body>
        <b-card-body>
          <div class="d-flex align-items-center">
            <div class="avatar-sm icon icon-with-bg icon-xs rounded-sm bg-soft-info me-3 flex-shrink-0">
              <i class="icon-dual-info" data-feather="edit-3"></i>
            </div>
            <div class="flex-grow-1">
              <h3 class="mt-0 mb-0">21</h3>
              <p class="text-muted mb-0">Tasks Inprogress</p>
            </div>
          </div>
        </b-card-body>
      </b-card>
    </b-col>

    <b-col lg="4">
      <b-card no-body>
        <b-card-body>
          <b-row>
            <b-col>
              <h4 class="mb-1 mt-0 fs-16">Revenue</h4>
            </b-col>
            <div class="col-auto text-end">
              <DropDown>
                <a class="btn-link text-muted dropdown-toggle arrow-none" href="#" role="button" id="dropdownMenuLink-2"
                  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon icon-xs" data-feather="more-horizontal"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink-2">
                  <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="edit"></i>Edit</a>
                  <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2"
                      data-feather="refresh-cw"></i>Refresh</a>
                </div>
              </DropDown>
            </div>
          </b-row>
          <h1 class="">{{ currency }}2,100.00</h1>
          <p class="text-muted">Last Week</p>

          <hr class="mb-1" />
          <b-row>
            <b-col cols="6">
              <div class="d-flex align-items-center mt-2">
                <div class="me-3 flex-shrink-0">
                  <i class="text-success" data-feather="trending-up"></i>
                </div>
                <div class="flex-grow-1">
                  <h5 class="mt-0 mb-0">15%</h5>
                  <p class="text-muted mb-0 fs-13">Prev Week</p>
                </div>
              </div>
            </b-col>
            <b-col cols="6">
              <div class="d-flex align-items-center mt-2">
                <div class="me-3 flex-shrink-0">
                  <i class="text-danger" data-feather="trending-down"></i>
                </div>
                <div class="flex-grow-1">
                  <h5 class="mt-0 mb-0">10%</h5>
                  <p class="text-muted mb-0 fs-13">Prev Month</p>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-card-body>
      </b-card>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import DropDown from '@/components/DropDown.vue';
import { appName, currency } from '@/helpers';

import avatar8 from "@/assets/images/avatars/img-8.jpg"
</script>