<template>
  <b-row>
    <b-col lg="12">
      <b-row>
        <b-col>
          <h4 class="mb-3 mt-0 fs-16">Recent Projects</h4>
        </b-col>
        <div class="col-auto text-end">
          <a href="#" class="fw-semibold text-primary fs-13">View All <i class="ms-1 icon-xxs"
              data-feather="arrow-right"></i></a>
        </div>
      </b-row>

      <b-row class="my-2">
        <b-col md="4">
          <b-card no-body>
            <b-card-body>
              <b-row class="align-items-center">
                <b-col>
                  <p class="text-muted fs-13 fw-medium mb-0">Aug 09, 2020</p>
                </b-col>
                <div class="col-auto text-end">
                  <DropDown>
                    <a class="btn-link text-muted dropdown-toggle arrow-none" href="#" role="button"
                      id="dropdownMenuLink-3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon icon-xs" data-feather="more-horizontal"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink-3">
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="eye"></i>View</a>
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="edit-3"></i>Edit</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item text-danger" href="#"><i class="icon-xxs icon me-2"
                          data-feather="trash-2"></i>Delete</a>
                    </div>
                  </DropDown>
                </div>
              </b-row>

              <div class="mt-3">
                <h4 class="mt-0 mb-1">
                  <a href="">Shreyu - Design Updates</a>
                </h4>
                <label class="mb-1 badge badge-soft-primary">Designing</label>

                <p class="text-muted fs-14 mt-3">Update shreyu with modern and latest
                  trends...</p>
              </div>

              <div class="mt-4">
                <b-row>
                  <b-col>
                    <h6 class="mt-0">Progress</h6>
                  </b-col>
                  <b-col class="text-end">
                    <small class="fw-semibold">75%</small>
                  </b-col>
                </b-row>
                <b-progress-bar variant="success" style="height: 6px;" :value="75" />
              </div>

              <b-row class="mt-3">
                <b-col>
                  <div class="avatar-group">
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar8" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar5" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                  </div>
                </b-col>
              </b-row>
            </b-card-body>
          </b-card>
        </b-col>

        <b-col md="4">
          <b-card no-body>
            <b-card-body>
              <b-row class="align-items-center">
                <b-col>
                  <p class="text-muted fs-13 fw-medium mb-0">Aug 10, 2020</p>
                </b-col>
                <div class="col-auto text-end">
                  <DropDown>
                    <a class="btn-link text-muted dropdown-toggle arrow-none" href="#" role="button"
                      id="dropdownMenuLink-4" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon icon-xs" data-feather="more-horizontal"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink-4">
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="eye"></i>View</a>
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="edit-3"></i>Edit</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item text-danger" href="#"><i class="icon-xxs icon me-2"
                          data-feather="trash-2"></i>Delete</a>
                    </div>
                  </DropDown>
                </div>
              </b-row>

              <div class="mt-3">
                <h4 class="mt-0 mb-1"><a href="">{{appName}} v2.0</a></h4>
                <label class="badge badge-soft-orange mb-1">Planning</label>

                <p class="text-muted fs-14 mt-3">Plan new features and functionality for {{appName}}...</p>
              </div>

              <div class="mt-4">
                <b-row>
                  <b-col>
                    <h6 class="mt-0">Progress</h6>
                  </b-col>
                  <b-col class="text-end">
                    <small class="fw-semibold">50%</small>
                  </b-col>
                </b-row>
                <b-progress-bar variant="danger" style="height: 6px;" :value="50" />
              </div>

              <b-row class="mt-3">
                <b-col>
                  <div class="avatar-group">
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar8" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar5" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                  </div>
                </b-col>
              </b-row>
            </b-card-body>
          </b-card>
        </b-col>

        <b-col md="4">
          <b-card no-body>
            <b-card-body>
              <b-row class="align-items-center">
                <b-col>
                  <p class="text-muted fs-13 fw-medium mb-0">Aug 11, 2020</p>
                </b-col>
                <div class="col-auto text-end">
                  <DropDown>
                    <a class="btn-link text-muted dropdown-toggle arrow-none" href="#" role="button"
                      id="dropdownMenuLink-5" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="icon icon-xs" data-feather="more-horizontal"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink-5">
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="eye"></i>View</a>
                      <a class="dropdown-item" href="#"><i class="icon-xxs icon me-2" data-feather="edit-3"></i>Edit</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item text-danger" href="#"><i class="icon-xxs icon me-2"
                          data-feather="trash-2"></i>Delete</a>
                    </div>
                  </DropDown>
                </div>
              </b-row>

              <div class="mt-3">
                <h4 class="mt-0 mb-1"><a href="">Hyper React v4.0</a></h4>
                <label class="badge badge-soft-info mb-1">Development</label>

                <p class="text-muted fs-14 mt-3">Update shreyu with modern and latest
                  trends...</p>
              </div>

              <div class="mt-4">
                <b-row>
                  <b-col>
                    <h6 class="mt-0">Progress</h6>
                  </b-col>
                  <b-col class="text-end">
                    <small class="fw-semibold">60%</small>
                  </b-col>
                </b-row>
                <b-progress-bar variant="warning" style="height: 6px;" :value="60" />
              </div>

              <b-row class="mt-3">
                <b-col>
                  <div class="avatar-group">
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar8" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                    <a href="" class="avatar-group-item mb-0">
                      <img :src="avatar5" alt="img"
                        class="img-fluid avatar-xs rounded rounded-circle avatar-border" />
                    </a>
                  </div>
                </b-col>
              </b-row>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-col>
  </b-row>
</template>
<script setup lang="ts">
import DropDown from '@/components/DropDown.vue';

import avatar8 from "@/assets/images/avatars/img-8.jpg";
import avatar5 from "@/assets/images/avatars/img-5.jpg";
import { appName } from '@/helpers';
</script>