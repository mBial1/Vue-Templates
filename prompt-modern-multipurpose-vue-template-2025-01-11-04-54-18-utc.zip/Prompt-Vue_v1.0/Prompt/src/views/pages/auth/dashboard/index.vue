<template>
  <DashboardNavbar topbarColor="navbar-light" classList="mx-auto" />
  <section class="position-relative overflow-hidden bg-gradient2 py-3 px-3">
    <b-container>
      <Profile />
      <RecentProjects />
      <Tasks />
    </b-container>
  </section>

  <Footer />
</template>
<script setup lang="ts">
import DashboardNavbar from "@/components/navbar/DashboardNavbar.vue";
import Profile from "@/views/pages/auth/dashboard/components/Profile.vue";
import RecentProjects from "@/views/pages/auth/dashboard/components/RecentProjects.vue";
import Tasks from "@/views/pages/auth/dashboard/components/Tasks.vue";
import Footer from "@/views/pages/auth/dashboard/components/Footer.vue";
</script>