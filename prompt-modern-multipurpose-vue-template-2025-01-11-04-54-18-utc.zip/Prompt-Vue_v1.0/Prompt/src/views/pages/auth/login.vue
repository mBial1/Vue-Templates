<template>
  <div class="bg-gradient2 min-vh-100 align-items-center d-flex justify-content-center pt-2 pt-sm-5 pb-4 pb-sm-5">
    <b-container>
      <b-row class="justify-content-center">
        <b-col xl="12">
          <b-card no-body>
            <b-card-body class="p-0">
              <b-row class="g-0">
                <b-col md="5" class="shadow">
                  <div class="p-xl-5 p-3">
                    <div class="mx-auto mb-5">
                      <router-link to="/" class="d-flex">
                        <img src="@/assets/images/logo.png" class="align-self-center" alt="logo-img" height="30" />
                      </router-link>
                    </div>

                    <h6 class="h5 mb-0 mt-3">Welcome back!</h6>
                    <p class="text-muted mt-1 mb-4">
                      Enter your email address and password to access admin panel.
                    </p>
                    <form action="#" class="authentication-form">

                      <b-form-group label="Email *" label-for="exampleInputEmail1" class="mb-3">
                        <b-form-input type="password" id="exampleInputEmail1" placeholder="Email" />
                      </b-form-group>

                      <div class="mb-3">
                        <label class="form-label" for="password">Password <small>*</small></label>
                        <router-link :to="{ name: 'auth.forget-password' }"
                          class="float-end text-muted text-unline-dashed ms-1 fs-13">Forgot your password?</router-link>
                        <b-form-input type="password" id="password" placeholder="Enter your password" />
                      </div>

                      <div class="mb-3">
                        <b-form-checkbox id="checkbox-1"> Remember me </b-form-checkbox>
                      </div>

                      <div class="mb-0 text-center d-grid">
                        <b-button variant="primary" type="submit">Log In</b-button>
                      </div>
                    </form>

                    <div class="py-3 text-center"><span class="fs-13 fw-bold">OR</span>
                    </div>
                    <b-row>
                      <b-col cols="12" class="text-center">
                        <a href="" class="btn btn-white w-100">
                          <i data-feather="github" class='icon icon-xs me-2'></i>Github
                        </a>
                      </b-col>
                    </b-row>
                  </div>
                </b-col>
                <b-col md="5" class="offset-md-1 d-none d-md-inline-block">
                  <div class="position-relative mt-5 pt-5">
                    <div class="slider">
                      <Swiper :modules="[Autoplay, Pagination]" :slidesPerView="1" :loop="true" :spaceBetween="0"
                        :autoplay="{ delay: 5000 }"
                        :breakpoints="{ 576: { slidesPerView: 1.2 }, 768: { slidesPerView: 1 } }" :roundLengths="true"
                        :pagination="{ el: '.swiper-pagination', dynamicBullets: true }">
                        <SwiperSlide>
                          <div class="swiper-slide-content">
                            <b-row class="text-center">
                              <b-col>
                                <img :src="saas1" alt="" class="w-75" />
                              </b-col>
                            </b-row>
                            <b-row class="text-center my-4 pb-5">
                              <b-col>
                                <h5 class="fw-medium fs-16">Manage your saas business with ease</h5>
                                <p class="text-muted">Make your saas application stand out with high-quality landing
                                  page designed and developed by professional.</p>
                              </b-col>
                            </b-row>
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div class="swiper-slide-content">
                            <b-row class="text-center">
                              <b-col>
                                <img :src="saas2" alt="" class="w-75" />
                              </b-col>
                            </b-row>
                            <b-row class="text-center my-4 pb-5">
                              <b-col>
                                <h5 class="fw-medium fs-16">The best way to showcase your mobile app</h5>
                                <p class="text-muted">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                  accusantium.
                                </p>
                              </b-col>
                            </b-row>
                          </div>
                        </SwiperSlide>
                        <SwiperSlide>
                          <div class="swiper-slide-content">
                            <b-row class="text-center">
                              <b-col>
                                <img :src="saas3" alt="" class="w-75" />
                              </b-col>
                            </b-row>
                            <b-row class="text-center my-4 pb-5">
                              <b-col>
                                <h5 class="fw-medium fs-16">Smart Solution that convert Lead to Customer</h5>
                                <p class="text-muted">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                                  accusantium.
                                </p>
                              </b-col>
                            </b-row>
                          </div>
                        </SwiperSlide>
                        <div class="swiper-pagination"></div>
                      </Swiper>
                    </div>
                  </div>
                </b-col>
              </b-row>
            </b-card-body>
          </b-card>

          <b-row class="mt-3">
            <b-col cols="12" class="text-center">
              <p class="text-muted">Don't have an account?
                <router-link :to="{ name: 'auth.register' }" class="text-primary fw-semibold ms-1">Sign Up</router-link>
              </p>
            </b-col>
          </b-row>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>
<script setup lang="ts">
import { onMounted } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Pagination } from 'swiper/modules';
import feather from 'feather-icons';

import saas1 from "@/assets/images/hero/saas1.jpg";
import saas2 from "@/assets/images/hero/saas2.jpg";
import saas3 from "@/assets/images/hero/saas3.jpg";

onMounted(() => {
  feather.replace();
});
</script>