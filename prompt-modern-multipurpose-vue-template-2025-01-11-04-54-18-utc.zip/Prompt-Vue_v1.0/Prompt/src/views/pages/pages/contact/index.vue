<template>
  <Hero />
  <Contact />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/pages/pages/contact/components/Hero.vue";
import Contact from "@/views/pages/pages/contact/components/Contact.vue";
import Footer from "@/views/pages/pages/contact/components/Footer.vue";
</script>