<template>
  <section class="py-5 mt-2 position-relative" id="job-openings">
    <b-container>
      <b-row>
        <b-col class="text-center">
          <h1 class="fw-semibold">Job Openings</h1>
          <p class="text-muted mx-auto">
            Interested? Come show us what you're made of!
          </p>
        </b-col>
      </b-row>
      <b-row class="mt-5">
        <b-col lg="12">
          <template v-for="(item, idx) in opening" :key="idx">
            <h3 class="mb-2" :class="idx && 'text-dark'">{{item.department}}</h3>
            <ul class="list-unstyled mb-5 pb-4">
              <li class="py-4 border-bottom" v-for="(role, idx) in item.positions" :key="idx">
                <div class="float-end ms-4"><a href="#" class="text-muted">{{role.type}}</a></div>
                <a href="#" class="h5 fw-medium my-0">{{role.title}}</a>
              </li>
            </ul>
          </template>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { opening } from "@/views/pages/pages/career/components/data";
</script>