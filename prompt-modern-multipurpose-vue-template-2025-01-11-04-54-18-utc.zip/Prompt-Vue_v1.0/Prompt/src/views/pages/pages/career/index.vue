<template>
  <Hero />
  <Benefits />
  <Culture />
  <Job />
  <CTA />
  <Footer />
</template>
<script setup lang="ts">
import Hero from "@/views/pages/pages/career/components/Hero.vue";
import Benefits from "@/views/pages/pages/career/components/Benefits.vue";
import Culture from "@/views/pages/pages/career/components/Culture.vue";
import Job from "@/views/pages/pages/career/components/Job.vue";
import CTA from "@/views/pages/pages/career/components/CTA.vue";
import Footer from "@/views/pages/pages/career/components/Footer.vue";
</script>