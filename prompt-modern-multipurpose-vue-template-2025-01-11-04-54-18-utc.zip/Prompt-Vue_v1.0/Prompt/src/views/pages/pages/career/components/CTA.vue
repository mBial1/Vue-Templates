<template>
  <section class="section py-6 position-relative">
    <b-container>
      <b-row>
        <b-col lg="6">
          <b-card no-body class="shadow-none border mb-lg-0 rounded-sm">
            <b-card-body>
              <h3 class="mt-0 fw-semibold">Get in touch</h3>
              <p>
                Don't find suitable opening? We'd still love to learn more about you. Contact us and we'll reach out to
                have interesting conversation!
              </p>
              <router-link :to="{ name: 'contact' }" class="btn btn-outline-primary mt-4">Contact Us</router-link>
            </b-card-body>
          </b-card>
        </b-col>

        <b-col lg="6">
          <b-card no-body class="shadow-none border mb-0 rounded-sm">
            <b-card-body>
              <h3 class="mt-0 fw-semibold">Meet the team</h3>
              <p>
                Learn more about us and who all work at {{appName}}. You will get chance to work with everyone in the team.
              </p>
              <router-link :to="{ name: 'company' }" class="btn btn-outline-primary mt-4">Meet our team</router-link>
            </b-card-body>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from '@/helpers';

</script>