type PositionType = {
  title: string;
  type: string;
};

export type OpeningType = {
  department: string,
  positions: PositionType[];
};

export type CultureType = {
  image: string,
  title: string;
};