import type { CultureType, OpeningType } from "@/views/pages/pages/career/components/types";

import photos3 from "@/assets/images/photos/3.jpg";
import photos4 from "@/assets/images/photos/4.jpg";
import photos10 from "@/assets/images/photos/10.jpg";
import photos5 from "@/assets/images/photos/5.jpg";

export const culture: CultureType[] = [
  {
    image: photos3,
    title: "Office Desks"
  },
  {
    image: photos4,
    title: "Meeting Room view"
  },
  {
    image: photos10,
    title: "Outside view"
  },
  {
    image: photos5,
    title: "A common seating area"
  }
];

export const opening: OpeningType[] = [
  {
    department: "Engineering",
    positions: [
      {
        title: "Technical Support Engineer",
        type: "Remote"
      },
      {
        title: "Senior Software Engineer (Frontend)",
        type: "Remote"
      },
      {
        title: "Senior Software Engineer (Backend)",
        type: "Remote"
      },
      {
        title: "Engineering Manager",
        type: "Remote"
      }
    ]
  },
  {
    department: "Marketing",
    positions: [
      {
        title: "Junior copywriter/editor",
        type: "Remote"
      }
    ]
  }
];