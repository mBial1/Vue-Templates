<template>
    <div class="bg-gradient2 position-relative">
        <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
        <div class="hero-4 pb-5 pt-7 py-sm-7">
            <b-container>
                <b-row class="align-items-center">
                    <b-col lg="6" md="6">
                        <h1 class="hero-title mt-0">
                            Let's work <span class="highlight highlight-warning d-inline-block">together</span>. Join
                            {{appName}}!
                        </h1>
                        <p class="fs-16 text-muted pt-3 w-75">
                            We're always open for new creative, analytical and technical minds to join our team. Search
                            for the suitable job.
                        </p>
                        <div class="pt-4 pb-md-5 mb-md-4">
                            <a href="#job-openings" class="btn btn-secondary mb-2" data-toggle="smooth-scroll">
                                View All Openings
                                <i class="icon-xxs ms-2" data-feather="arrow-right"></i>
                            </a>
                        </div>
                    </b-col>
                    <b-col lg="6" md="6">
                        <div class="img-container text-end ps-lg-5" data-aos="zoom-in">
                            <b-row class="align-items-center mt-md-0 mt-4">
                                <b-col cols="6">
                                    <b-card no-body class="shadow-lg">
                                        <b-card-body class="p-1">
                                            <img :src="photos12" class="img-fluid" alt="" />
                                        </b-card-body>
                                    </b-card>
                                </b-col>
                                <b-col cols="6">
                                    <b-row>
                                        <b-col>
                                            <b-card no-body class="shadow-lg">
                                                <b-card-body class="p-1">
                                                    <img :src="photos14" class="img-fluid" alt="" />
                                                </b-card-body>
                                            </b-card>
                                        </b-col>
                                    </b-row>
                                    <b-row>
                                        <b-col>
                                            <b-card no-body class="shadow-lg">
                                                <b-card-body class="p-1 mb-0">
                                                    <img :src="photos15" class="img-fluid" alt="" />
                                                </b-card-body>
                                            </b-card>
                                        </b-col>
                                    </b-row>
                                </b-col>
                            </b-row>
                        </div>
                    </b-col>
                </b-row>
            </b-container>
            <div class="shape bottom">
                <svg width="1440px" height="40px" viewBox="0 0 1440 40" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="shape-b" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="curve" fill="#fff">
                            <path
                                d="M0,30.013 C239.659,10.004 479.143,0 718.453,0 C957.763,0 1198.28,10.004 1440,30.013 L1440,40 L0,40 L0,30.013 Z"
                                id="Path"></path>
                        </g>
                    </g>
                </svg>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";

import photos12 from "@/assets/images/photos/12.jpg";
import photos14 from "@/assets/images/photos/14.jpg";
import photos15 from "@/assets/images/photos/15.jpg";
import { appName } from "@/helpers";
</script>