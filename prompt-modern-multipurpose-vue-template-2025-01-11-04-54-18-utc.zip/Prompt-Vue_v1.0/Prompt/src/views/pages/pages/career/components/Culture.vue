<template>
  <section class="py-7 mt-5 position-relative bg-gradient2">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-primary px-2 py-1">Our Beliefs</b-badge>
          <h1 class="fw-semibold">Our Culture</h1>
          <p class="text-muted mx-auto">
            At {{appName}}, We believe in a fully balanced personal and professional life, importance of focus, fun,
            self-motivation and full transparency.
          </p>
        </b-col>
      </b-row>

      <div data-bs-toggle="image-gallery" data-delegate="a" data-type="image" data-enable-gallery="true" class="mt-5">
        <b-row data-aos="fade-up">
          <b-col lg="6" v-for="(item, idx) in culture" :key="idx">
            <a :href="item.image" :data-title="item.title">
              <b-card no-body class="shadow rounded-sm">
                <b-card-body class="p-1">
                  <img :src="item.image" alt="" class="img-fluid rounded-sm">
                </b-card-body>
              </b-card>
            </a>
          </b-col>
        </b-row>
      </div>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import { culture } from "@/views/pages/pages/career/components/data";
</script>