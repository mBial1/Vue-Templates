import { FAQType, PriceType } from "@/types";

export const pricing: PriceType[] = [
  {
    plan: "Starter",
    price: 49,
    features: [
      "Up to 600 minutes usage time",
      "Use for personal only",
      "Add up to 10 attendees",
      "Technical support via email"
    ],
    animationDuration: 300
  },
  {
    plan: "Professional",
    price: 99,
    features: [
      "Up to 6000 minutes usage time",
      "Use for personal or a commercial",
      "Add up to 100 attendees",
      "Up to 5 teams",
      "Technical support via email"
    ],
    animationDuration: 700,
    isPopular: true
  },
  {
    plan: "Enterprise",
    price: 599,
    features: [
      "Unlimited usage time",
      "Use for personal or a commercial",
      "Add Unlimited attendees",
      "24x7 Technical support via phone",
      "Technical support via email"
    ],
    animationDuration: 1100
  }
];

export const faqs: FAQType[] = [
  {
    ques: "Can I use this template for my client?",
    ans: "Yup, the marketplace license allows you to use this theme in any end products. For more information on licenses, please refere license terms on marketplace."
  },
  {
    ques: "Can this theme work with WordPress?",
    ans: "No. This is a HTML template. It won't directly with WordPress, though you can convert this into WordPress compatible theme."
  },
  {
    ques: "How do I get help with the theme?",
    ans: "Use our dedicated support email (support@coderthemes.com) to send your issues or feedback. We are here to help anytime."
  },
  {
    ques: "Will you regularly give updates of Prompt ?",
    ans: "Yes, We will update the Prompt regularly. All the future updates would be available without any cost."
  }
];