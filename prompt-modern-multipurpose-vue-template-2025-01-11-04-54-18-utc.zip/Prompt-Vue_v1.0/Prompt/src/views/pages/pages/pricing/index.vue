<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <Pricing />
  <Benefits />
  <FAQs />
  <CTA />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/pages/pricing/components/Hero.vue";
import Pricing from "@/views/pages/pages/pricing/components/Pricing.vue";
import Benefits from "@/views/pages/pages/pricing/components/Benefits.vue";
import FAQs from "@/views/pages/pages/pricing/components/FAQs.vue";
import CTA from "@/views/pages/pages/pricing/components/CTA.vue";
import Footer from "@/views/pages/pages/pricing/components/Footer.vue";
</script>