<template>
<section class="section py-6 position-relative">
    <b-container>
        <b-row data-aos="fade-up">
            <b-col class="text-center">
                <h1 class="fw-semibold">Still have a question?</h1>
                <p class="text-muted mx-auto">Explore your most suitable option below</p>
            </b-col>
        </b-row>
        <b-row class="mt-5">
            <b-col lg="6">
                <b-card no-body class="shadow-none border mb-lg-0 rounded-sm" data-aos="fade-up" data-aos-duration="500">
                    <b-card-body>
                        <h3 class="mt-0 fw-semibold">Get in touch</h3>
                        <p>Get in touch with our professional business development team and they'll answer your question shortly</p>
                        <router-link :to="{name: 'contact'}" class="btn btn-outline-primary mt-4">Contact Us</router-link>
                    </b-card-body>
                </b-card>
            </b-col>

            <b-col lg="6">
                <b-card no-body class="shadow-none border mb-0 rounded-sm" data-aos="fade-up" data-aos-duration="1000">
                    <b-card-body>
                        <h3 class="mt-0 fw-semibold">Explore Knowledge Base</h3>
                        <p>Learn more about all the features and functionality from our detailed knowledge base.</p>
                        <router-link :to="{name: 'help.desk'}" class="btn btn-outline-primary mt-4">Explore</router-link>
                    </b-card-body>
                </b-card>
            </b-col>
        </b-row>
    </b-container>
</section>
</template>
<script setup lang="ts">
</script>