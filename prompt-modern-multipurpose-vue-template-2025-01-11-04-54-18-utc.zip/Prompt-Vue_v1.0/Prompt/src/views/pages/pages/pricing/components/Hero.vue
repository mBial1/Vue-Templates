<template>
<section class="hero-4 pb-5 pt-7 py-sm-7 bg-gradient2">
    <b-container>
        <b-row class="justify-content-center">
            <b-col lg="7" class="text-center">
                <h1 class="hero-title">Flexible plans that grow with you</h1>
                <p class="fs-17 text-muted">Nemo enim ipsam voluptatem quia voluptas sit aspernatur
                    aut odit aut fugit sed consequuntur ratione voluptatem sequi nesciunt.</p>
            </b-col>
        </b-row>
    </b-container>
</section>
</template>
<script setup lang="ts">
</script>