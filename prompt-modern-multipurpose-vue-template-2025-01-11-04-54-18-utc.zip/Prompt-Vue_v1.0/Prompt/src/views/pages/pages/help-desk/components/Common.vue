<template>
  <section class="section py-5 py-lg-8 mb-5 mb-sm-0 position-relative">
    <b-container>
      <b-row>
        <b-col lg="8">
          <b-row>
            <b-col md="4">
              <div class="mb-5 mb-lg-0">
                <span class="icon icon-md text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <title>Stockholm-icons / Code / Terminal</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Code-/-Terminal" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <polygon id="Shape" points="0 0 24 0 24 24 0 24"></polygon>
                      <path
                        d="M3.70710678,15.7071068 C3.31658249,16.0976311 2.68341751,16.0976311 2.29289322,15.7071068 C1.90236893,15.3165825 1.90236893,14.6834175 2.29289322,14.2928932 L8.29289322,8.29289322 C8.67147216,7.91431428 9.28105859,7.90106866 9.67572463,8.26284586 L15.6757246,13.7628459 C16.0828436,14.1360383 16.1103465,14.7686056 15.7371541,15.1757246 C15.3639617,15.5828436 14.7313944,15.6103465 14.3242754,15.2371541 L9.03007575,10.3841378 L3.70710678,15.7071068 Z"
                        id="Path-94" fill="#335EEA"
                        transform="translate(9.000003, 11.999999) rotate(-270.000000) translate(-9.000003, -11.999999) ">
                      </path>
                      <rect id="Rectangle" fill="#335EEA" opacity="0.3" x="12" y="17" width="10" height="2" rx="1">
                      </rect>
                    </g>
                  </svg>
                </span>
                <h4 class="mt-4 fw-semibold mb-0">Getting started</h4>
                <ul class="list-unstyled text-muted mb-4">
                  <li class="my-3">
                    <a href="" class="text-muted">General information</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">Signup help</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">Preparing the documents</a>
                  </li>
                </ul>
                <a href="#" class="text-primary fw-medium">View More <i class="icon-xs ms-1"
                    data-feather="chevron-right"></i></a>
              </div>
            </b-col>
            <b-col md="4">
              <div class="mb-5 mb-lg-0">
                <span class="icon icon-md text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <title>Stockholm-icons / Communication / Address-card</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Communication-/-Address-card" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M6,2 L18,2 C19.6568542,2 21,3.34314575 21,5 L21,19 C21,20.6568542 19.6568542,22 18,22 L6,22 C4.34314575,22 3,20.6568542 3,19 L3,5 C3,3.34314575 4.34314575,2 6,2 Z M12,11 C13.1045695,11 14,10.1045695 14,9 C14,7.8954305 13.1045695,7 12,7 C10.8954305,7 10,7.8954305 10,9 C10,10.1045695 10.8954305,11 12,11 Z M7.00036205,16.4995035 C6.98863236,16.6619875 7.26484009,17 7.4041679,17 C11.463736,17 14.5228466,17 16.5815,17 C16.9988413,17 17.0053266,16.6221713 16.9988413,16.5 C16.8360465,13.4332455 14.6506758,12 11.9907452,12 C9.36772908,12 7.21569918,13.5165724 7.00036205,16.4995035 Z"
                        id="Combined-Shape" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
                <h4 class="mt-4 fw-semibold mb-0">Managing my account</h4>
                <ul class="list-unstyled text-muted mb-4">
                  <li class="my-3">
                    <a href="" class="text-muted">Account information</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">Identity verification</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">Linking a paymeny method</a>
                  </li>
                </ul>
                <a href="#" class="text-primary fw-medium">View More <i class="icon-xs ms-1"
                    data-feather="chevron-right"></i></a>
              </div>
            </b-col>
            <b-col md="4">
              <div class="mb-5 mb-lg-0">
                <span class="icon icon-md text-primary">
                  <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <title>Stockholm-icons / Code / Git#4</title>
                    <desc>Created with Sketch.</desc>
                    <g id="Stockholm-icons-/-Code-/-Git#4" stroke="none" stroke-width="1" fill="none"
                      fill-rule="evenodd">
                      <rect id="Rectangle-5" x="0" y="0" width="24" height="24"></rect>
                      <path
                        d="M6,7 C7.1045695,7 8,6.1045695 8,5 C8,3.8954305 7.1045695,3 6,3 C4.8954305,3 4,3.8954305 4,5 C4,6.1045695 4.8954305,7 6,7 Z M6,9 C3.790861,9 2,7.209139 2,5 C2,2.790861 3.790861,1 6,1 C8.209139,1 10,2.790861 10,5 C10,7.209139 8.209139,9 6,9 Z"
                        id="Oval-7" fill="#335EEA"></path>
                      <path
                        d="M7,11.4648712 L7,17 C7,18.1045695 7.8954305,19 9,19 L15,19 L15,21 L9,21 C6.790861,21 5,19.209139 5,17 L5,8 L5,7 L7,7 L7,8 C7,9.1045695 7.8954305,10 9,10 L15,10 L15,12 L9,12 C8.27142571,12 7.58834673,11.8052114 7,11.4648712 Z"
                        id="Combined-Shape" fill="#335EEA" opacity="0.3"></path>
                      <path
                        d="M18,22 C19.1045695,22 20,21.1045695 20,20 C20,18.8954305 19.1045695,18 18,18 C16.8954305,18 16,18.8954305 16,20 C16,21.1045695 16.8954305,22 18,22 Z M18,24 C15.790861,24 14,22.209139 14,20 C14,17.790861 15.790861,16 18,16 C20.209139,16 22,17.790861 22,20 C22,22.209139 20.209139,24 18,24 Z"
                        id="Oval-7-Copy" fill="#335EEA"></path>
                      <path
                        d="M18,13 C19.1045695,13 20,12.1045695 20,11 C20,9.8954305 19.1045695,9 18,9 C16.8954305,9 16,9.8954305 16,11 C16,12.1045695 16.8954305,13 18,13 Z M18,15 C15.790861,15 14,13.209139 14,11 C14,8.790861 15.790861,7 18,7 C20.209139,7 22,8.790861 22,11 C22,13.209139 20.209139,15 18,15 Z"
                        id="Oval-7-Copy-3" fill="#335EEA"></path>
                    </g>
                  </svg>
                </span>
                <h4 class="mt-4 fw-semibold mb-0">API & Integrations</h4>
                <ul class="list-unstyled text-muted mb-4">
                  <li class="my-3">
                    <a href="" class="text-muted">Rest API Integrations</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">API SDKs</a>
                  </li>
                  <li class="my-3">
                    <a href="" class="text-muted">Embed scripts</a>
                  </li>
                </ul>
                <a href="#" class="text-primary fw-medium">View More <i class="icon-xs ms-1"
                    data-feather="chevron-right"></i></a>
              </div>
            </b-col>
          </b-row>

          <h4 class="mt-7 fw-semibold mb-0">Frequently Asked Questions</h4>
          <p class="text-muted mx-auto">
            Here are some of the basic types of questions for our customers
          </p>
          <b-row class="mt-3">
            <b-col lg="10">
              <div id="faqContent">
                <div class="accordion custom-accordionwitharrow mt-3 mb-lg-0 mb-4" id="accordionExample">
                  <b-card no-body class="shadow-none mb-1 border rounded-sm" v-for="(item, idx) in faqs" :key="idx">
                    <a href="#/" class="text-dark" @click="show = (idx + 1)">
                      <b-card-header id="headingOne">
                        <h5 class="my-1 fw-medium">{{ item.ques }}
                          <i class="icon-xs accordion-arrow" data-feather="chevron-down"></i>
                        </h5>
                      </b-card-header>
                    </a>
                    <b-collapse id="collapseOne" :visible="show === (idx + 1)">
                      <b-card-body class="text-muted pt-1">
                        {{ item.ans }}
                      </b-card-body>
                    </b-collapse>
                  </b-card>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-col>
        <b-col lg="4">
          <CustomStickyElement data-sticky custom-class="card rounded border sticky-el" data-margin-top="75">
            <b-card-body class="px-5 py-4">
              <h4 class="fw-medium"><i class="icon icon-sm text-muted me-3" data-feather="life-buoy"></i>Support center
              </h4>
              <h5 class="text-muted fw-normal mb-4 pb-3"><span class="fw-medium">Can't find the answer?</span> We are
                here to help you all the time.</h5>
              <h5 class="fw-normal">
                <router-link :to="{ name: 'contact' }" class="text-muted"><i class="icon-xs me-2"
                    data-feather="message-square"></i>Talk
                  to Support Team
                </router-link>
              </h5>
              <h5 class="fw-normal mt-3">
                <a href="#" class="text-muted"><i class="icon-xs me-2" data-feather="mail"></i>help@coderthemes.com</a>
              </h5>
              <h5 class="fw-normal mt-3">
                <a href="#" class="text-muted"><i class="icon-xs me-2" data-feather="twitter"></i>@coderthemes</a>
              </h5>
            </b-card-body>
          </CustomStickyElement>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import CustomStickyElement from "@/components/CustomStickyElement.vue";
import { faqs } from "@/views/pages/pages/help-desk/components/data";
import { ref } from "vue";
const show = ref(1);
</script>