<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <Common />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/pages/help-desk/components/Hero.vue";
import Common from "@/views/pages/pages/help-desk/components/Common.vue";
import Footer from "@/views/pages/pages/help-desk/components/Footer.vue";
</script>