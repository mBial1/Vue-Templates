<template>
  <Navbar topbarColor="navbar-light" classList="ms-auto" ctaButtonClass="btn-outline-secondary btn-sm" />
  <Hero />
  <About />
  <Features />
  <Counter />
  <Team />
  <Clients />
  <Footer />
</template>
<script setup lang="ts">
import Navbar from "@/components/navbar/Navbar.vue";
import Hero from "@/views/pages/pages/company/components/Hero.vue";
import About from "@/views/pages/pages/company/components/About.vue";
import Features from "@/views/pages/pages/company/components/Features.vue";
import Counter from "@/views/pages/pages/company/components/Counter.vue";
import Team from "@/views/pages/pages/company/components/Team.vue";
import Clients from "@/views/pages/pages/company/components/Clients.vue";
import Footer from "@/views/pages/pages/company/components/Footer.vue";
</script>