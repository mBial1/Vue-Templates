<template>
  <section class="position-relative hero-9">

    <div class="hero-top">
      <b-container>
        <b-row class="py-7">
          <b-col>
            <h1 class="hero-title fw-bold">
              We are on a mission to
              <span class="highlight highlight-info d-inline-block">revolutionize</span> the web
            </h1>
            <p class="mt-3 fs-17">
              We are a full-stack web development studio, run by people who are very passionate about making the web
              more beautiful
            </p>
          </b-col>
        </b-row>
      </b-container>
    </div>

    <div class="position-relative">
      <div class="hero-cta">
        <b-button variant="info" class="btn-cta">Let's Have Talk</b-button>
      </div>
    </div>


    <div class="hero-bottom">
      <div class="jarallax hero-image" data-jarallax data-speed=".2" :style="`background-image: url(${coworking2})`">
      </div>
    </div>
  </section>
</template>
<script setup lang="ts">
import { onMounted } from 'vue';
import { jarallax } from 'jarallax';
import 'jarallax/dist/jarallax';
import 'jarallax/dist/jarallax.cjs';
import 'jarallax/dist/jarallax.min.js';

import coworking2 from "@/assets/images/hero/coworking2.jpg";

onMounted(() => {
  // @ts-ignore
  jarallax(document.querySelectorAll(".jarallax"));
});
</script>