<template>
  <section class="position-relative pt-8 pb-4">
    <b-container>
      <b-row data-aos="fade-up">
        <b-col lg="4">
          <span class="border border-top w-25 border-soft-primary d-block"></span>
          <h1 class="fw-semibold mt-4">About Us</h1>
        </b-col>
        <b-col lg="4">
          <p class="text-muted mb-4">Temporibus autem quibusdam et aut as officiis debitis aut rerum
            necessitatibus saepe eveniet voluptates repudiandae sint et molestiae non recusandae itaque
            earum rerum hic tenetur a sapiente delectus reiciendis.</p>
        </b-col>
        <b-col lg="4">
          <p class="text-muted mb-4">Temporibus autem quibusdam et aut as officiis debitis aut rerum
            necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae
            itaque earum rerum hic tenetur a sapiente delectus reiciendis.</p>
        </b-col>
        <b-col lg="8" class="offset-lg-4">
          <p class="text-muted">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
            doloremque laudantium totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
            architecto beatae vitae dicta sunt explicabo.</p>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
</script>