<template>
  <section class="py-5 mb-lg-6 position-relative" data-aos="fade-up">
    <b-container>
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-info px-2 py-1">Investor</b-badge>

          <h1 class="fw-medium">We are backed by</h1>
          <p class="text-muted mx-auto">
            100+ clients trust <span class="text-dark fw-bold">{{appName}}</span> to drive
            perfomance & engagement.
          </p>
        </b-col>
      </b-row>
      <b-row class="mt-5">
        <b-col v-for="(logo, idx) in companies" :class="idx && 'offset-1'" :key="idx">
          <img :src="logo" alt="" height="45" />
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import amazon from "@/assets/images/brands/amazon.svg";
import google from "@/assets/images/brands/google.svg";
import paypal from "@/assets/images/brands/paypal.svg";
import shopify from "@/assets/images/brands/shopify.svg";
import { appName } from "@/helpers";

const companies: string[] = [amazon, google, paypal, shopify];
</script>