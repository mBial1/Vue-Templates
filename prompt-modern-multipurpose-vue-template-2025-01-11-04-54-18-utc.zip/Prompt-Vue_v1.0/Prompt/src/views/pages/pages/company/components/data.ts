import { currency } from '@/helpers';
import type { MemberType, StatType } from "@/views/pages/pages/company/components/types";

import avatar1 from "@/assets/images/avatars/img-1.jpg";
import avatar2 from "@/assets/images/avatars/img-2.jpg";
import avatar3 from "@/assets/images/avatars/img-3.jpg";
import avatar4 from "@/assets/images/avatars/img-4.jpg";
import avatar5 from "@/assets/images/avatars/img-5.jpg";
import avatar6 from "@/assets/images/avatars/img-6.jpg";
import avatar7 from "@/assets/images/avatars/img-7.jpg";
import avatar8 from "@/assets/images/avatars/img-8.jpg";

export const team: MemberType[] = [
  {
    name: "Ana Russo",
    position: "CEO",
    image: avatar1
  },
  {
    name: "Danette Payne",
    position: "CTO",
    image: avatar2
  },
  {
    name: "Tammy Ward",
    position: "VP, Product Development",
    image: avatar3
  },
  {
    name: "Paul Moore",
    position: "Back-End Developer",
    image: avatar4
  },
  {
    name: "Harry Burris",
    position: "PHP Developer",
    image: avatar5
  },
  {
    name: "Patricia Ferraro",
    position: "Web Designer",
    image: avatar6
  },
  {
    name: "Robert Smith",
    position: "Graphic Designer",
    image: avatar7
  },
  {
    name: "Lindsay Clark",
    position: "Web Designer",
    image: avatar8
  },
  {
    name: "Lindsay Clark",
    position: "Front-End Developer",
    image: avatar2
  },
  {
    name: "Ernest Griffith",
    position: "PHP Developer",
    image: avatar4
  },
  {
    name: "Cecelia Poole",
    position: "Back-End Developer",
    image: avatar6
  },
  {
    name: "Morris Hall",
    position: "Graphic Designer",
    image: avatar3
  }
];

export const stats:StatType[] = [
  {
    count: {
      startAmount: 10,
      endAmount: 100,
      duration: 5,
      suffix: "+"
    },
    title: "Products Built",
    description: "helped clients across the globe"
  },
  {
    count: {
      startAmount: 5,
      endAmount: 21,
      duration: 5,
      prefix: currency,
      suffix: "M+"
    },
    title: "Revenue Generated",
    description: "across 10+ countries"
  },
  {
    count: {
      startAmount: 10,
      endAmount: 100,
      duration: 5,
      suffix: "+"
    },
    title: "Satisfied Clients",
    description: "across 100+ locations"
  },
  {
    count: {
      startAmount: 1,
      endAmount: 10,
      duration: 5,
      suffix: "+"
    },
    title: "Awards Won",
    description: "on Awwwards, CSS Design Awards"
  }
];