export type MemberType = {
  name: string;
  position: string;
  image: string;
};

export type StatType = {
  count: {
    startAmount: number;
    endAmount: number;
    duration: number;
    prefix?: string,
    suffix: string;
  },
  title: string;
  description: string;
};