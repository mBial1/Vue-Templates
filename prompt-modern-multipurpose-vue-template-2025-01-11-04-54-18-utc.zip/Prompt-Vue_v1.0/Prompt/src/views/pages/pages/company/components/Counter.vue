<template>
  <section class="pt-8 pb-6 mb-4 mt-lg-4 bg-light position-relative" data-aos="fade-up">
    <div class="divider top d-none d-sm-block"></div>
    <b-container>
      <b-row>
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-info px-2 py-1">Stats</b-badge>

          <h1 class="fw-medium">{{appName}} In Numbers</h1>
          <p class="text-muted mx-auto"></p>
        </b-col>
      </b-row>
      <b-row class="mt-5 text-center">
        <b-col cols="6" md="3" class="mb-4 mb-sm-0" v-for="(item, idx) in stats" :key="idx">
          <div class="display-4 fw-normal">
            <Vue3autocounter ref='counter' :startAmount='item.count.startAmount' :endAmount='item.count.endAmount'
              :duration='item.count.duration' :prefix='item.count.prefix' :suffix='item.count.suffix' />
          </div>
          <p class="mt-2 mb-0 fw-semibold">
            {{ item.title }}
          </p>
          <p>{{ item.description }}</p>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import Vue3autocounter from 'vue3-autocounter';
import { stats } from "@/views/pages/pages/company/components/data";
import { appName } from '@/helpers';
</script>