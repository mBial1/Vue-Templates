<template>
  <section class="py-5 mb-xl-5 mb-lg-4 position-relative" data-aos="fade-up">
    <b-container>
      <b-row class="align-items-center mt-5">
        <b-col lg="5">
          <h1 class="fw-semibold">Build amazing things together</h1>
          <p class="text-muted my-4">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
            accusantium doloremque laudantium totam rem aperiam beatae vitae dicta sunt explicabo.</p>

          <p class="text-muted my-4">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
            accusantium doloremque laudantium totam rem aperiam beatae vitae dicta sunt explicabo.</p>

          <a href="#" class="h6 text-primary">Learn more <i class="ms-2 icon-xxs" data-feather="arrow-right"></i></a>
        </b-col>
        <b-col lg="6" class="offset-lg-1">
          <div class="img-content2 position-relative mt-4 mt-lg-0">
            <div class="img-up mb-lg-0 mb-6">
              <img :src="photos3" alt="app img" class="img-fluid d-block shadow" />
            </div>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import photos3 from "@/assets/images/photos/3.jpg"
</script>