<template>
  <section class="pb-5 pt-6 mt-4 position-relative" data-aos="fade-up">
    <b-container>
      <b-row class="justify-content-center">
        <b-col class="text-center">
          <b-badge :variant="null" pill class="badge-soft-info px-2 py-1">Our Team</b-badge>

          <h1 class="fw-medium">Meet Our Team</h1>
          <p class="text-muted mx-auto">
            Start working with <span class="text-dark fw-bold">{{appName}}</span> to manage your
            workforce better.</p>
        </b-col>
      </b-row>
      <b-row class="mt-5">
        <b-col lg="4" md="6" v-for="(item, idx) in team" :key="idx">
          <div class="d-flex align-items-center mb-4 pb-md-3">
            <img :src="item.image" alt="..." class="img-fluid avatar-md d-block rounded me-3" />
            <div class="flex-grow-1">
              <h5 class="mt-0 mb-1 fw-medium">{{ item.name }}</h5>
              <p class="text-muted fw-medium mb-0">{{ item.position }}</p>
            </div>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import { appName } from "@/helpers";
import { team } from "@/views/pages/pages/company/components/data";
</script>