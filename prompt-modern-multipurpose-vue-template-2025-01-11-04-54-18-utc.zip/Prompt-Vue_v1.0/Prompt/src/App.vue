<template>
  <RouterView />
  <BackToTop />
</template>

<script setup lang="ts">
import BackToTop from "@/components/BackToTop.vue";
import { RouterView } from 'vue-router';
</script>