<template>
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="cn-info">
                        <ul>
                            <li><i class="fa-solid fa-phone"></i>91 256 584 5748</li>
                            <li class="d-inline-flex align-items-center"><i class="ti ti-email"></i>support@Rikada.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <ul class="top-social">
                        <li><router-link to="#"><i class="ti ti-facebook text-muted"></i></router-link></li>
                        <li><router-link to="#"><i class="ti ti-linkedin text-muted"></i></router-link></li>
                        <li><router-link to="#"><i class="ti ti-instagram text-muted"></i></router-link></li>
                        <li><router-link to="#"><i class="ti ti-twitter text-muted"></i></router-link></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>
