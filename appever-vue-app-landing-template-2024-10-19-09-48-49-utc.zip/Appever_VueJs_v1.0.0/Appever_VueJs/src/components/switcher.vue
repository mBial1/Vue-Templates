<template>
    <div>
 <!-- Switcher -->
        <div class="fixed top-1/4 -right-3 z-50">
            <span class="relative inline-block rotate-90">
                <input type="checkbox" class="checkbox opacity-0 absolute" id="chk" @change="changeMode($event)"/>
                <label class="label bg-slate-900 dark:bg-white shadow dark:shadow-gray-800 cursor-pointer rounded-full flex justify-between items-center p-1 w-14 h-8" for="chk" >
                    <i data-feather="moon" class="size-4 text-yellow-500"></i>
                    <i data-feather="sun" class="size-4 text-yellow-500"></i>
                    <span class="ball bg-white dark:bg-slate-900 rounded-full absolute top-[2px] left-[2px] size-7"></span>
                </label>
            </span>
        </div>
        <!-- Switcher -->

        <!-- LTR & RTL Mode Code -->
        <div class="fixed top-1/3 -right-3 z-50">
            <a href="" id="switchRtl">
                <span @click="changeThem($event)" class="py-1 px-3 relative inline-block rounded-t-md -rotate-90 bg-white dark:bg-slate-900 shadow-md dark:shadow dark:shadow-gray-800 font-semibold rtl:block ltr:hidden" >LTR</span>
                <span @click="changeThem($event)" class="py-1 px-3 relative inline-block rounded-t-md -rotate-90 bg-white dark:bg-slate-900 shadow-md dark:shadow dark:shadow-gray-800 font-semibold ltr:block rtl:hidden">RTL</span>
            </a>
        </div>
        <!-- LTR & RTL Mode Code -->
    </div>
</template>

<script setup>
    import * as feather from 'feather-icons'
    import { onMounted, ref } from 'vue';

    const htmlTag = ref(document.getElementsByTagName("html")[0])
    onMounted(()=>{
        feather.replace()
        console.log(htmlTag.value.className.includes("light"));
        
    })


    const changeMode = (event) =>{
        event.preventDefault();
        if (htmlTag.value.className.includes("dark")) {
            htmlTag.value.className = 'light'
        } else {
            htmlTag.value.className = 'dark'
        }
    }

    const changeThem =(event) =>{
        event.preventDefault();
        
        if (event.target.innerText === "LTR") {
            htmlTag.value.dir = "ltr"
        }
        else {
            htmlTag.value.dir = "rtl"
        }
    }

</script>