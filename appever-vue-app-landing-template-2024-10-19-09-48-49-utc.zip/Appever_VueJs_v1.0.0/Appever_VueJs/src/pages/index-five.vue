<template>
    <div>
        <Navbar :playBtn="true" :navCenter="true"/>

        <HomeFiveBanner/>

        <!-- Start -->
        <section class="relative md:py-24 py-16" id="features">
            <FeatureOne/>

            <div class="container relative md:mt-24 mt-16">
                <AboutOne/>
            </div><!--end container-->

            <div class="container relative md:mt-24 mt-16">
                <AboutTwo/>
            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->

        <!-- Start -->
        <section class="relative md:py-24 py-16 bg-slate-50/50 dark:bg-slate-800/20" id="screenshot">
            <Screenshort/>
        </section><!--end section-->
        <!-- End -->

         <!-- Start -->
        <section class="relative overflow-hidden md:py-24 py-16" id="faqs">
            <Faq/>
        </section><!--end section-->
        <!-- End Section-->

        <!-- Start -->
        <section class="relative md:py-24 py-16 bg-slate-50/50 dark:bg-slate-800/20" id="download">
            <Download/>
        </section><!--end section-->
        <!-- End -->

        <!-- Start -->
        <section class="relative md:py-24 py-16" id="reviews">
            <div class="container relative">
                <div class="grid grid-cols-1 pb-6 text-center">
                    <h6 class="text-red-500 uppercase text-sm font-bold tracking-wider mb-3">Reviews</h6>
                    <h4 class="mb-6 md:text-3xl text-2xl md:leading-normal leading-normal font-bold">10k+ Customers Trust Us</h4>

                    <p class="text-slate-400 max-w-xl mx-auto">Unleash the power of our platform with a multitude of powerful features, empowering you to achieve your goals.</p>
                </div><!--end grid-->

                <Client/>
            </div><!--end container-->
        </section><!--end section-->
        <!-- End Section-->

        <!-- Start -->
        <section class="relative md:py-24 py-16 bg-slate-50/50 dark:bg-slate-800/20" id="contact">
            <Contact/>
        </section><!--end section-->
        <!-- End -->

        <!-- Business Partner -->
        <section class="py-6 border-t border-b border-gray-100 dark:border-gray-800">
            <Partner/>
        </section><!--end section-->
        <!-- Business Partner -->

        <FooterOne/>

        <ScrollToTop/>

        <Switcher/>

    </div>
</template>

<script setup>
    import AboutOne from '@/components/about-one.vue';
    import AboutTwo from '@/components/about-two.vue';
    import Client from '@/components/client.vue';
    import Contact from '@/components/contact.vue';
    import Download from '@/components/download.vue';
    import Faq from '@/components/faq.vue';
    import FeatureOne from '@/components/feature-one.vue';
    import FooterOne from '@/components/footer-one.vue';
    import HomeFiveBanner from '@/components/home-five-banner.vue';
    import Navbar from '@/components/navbar.vue';
    import Partner from '@/components/partner.vue';
    import Screenshort from '@/components/screenshort.vue';
    import ScrollToTop from '@/components/scroll-to-top.vue';
    import Switcher from '@/components/switcher.vue';
</script>
