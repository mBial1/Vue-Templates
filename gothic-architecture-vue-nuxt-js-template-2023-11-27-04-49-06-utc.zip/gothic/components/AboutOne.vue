<template>
    <div class="section-padding-top overflow-hidden">
        <div class="container">
            <div class="row mb-n10">
                <div class="col-lg-6 mb-10 col-md-12 order-2 order-lg-1" data-aos="fade-right" data-aos-delay="500">
                    <div class="history-image">
                        <img class="fit-image" src="/images/history/history-1.png" alt="">
                    </div>
                </div>
                <div class="col-lg-6 mb-10 col-md-12 align-self-center order-1 order-lg-2" data-aos="fade-left" data-aos-delay="500">
                    <div class="history-wrapper">
                        <h1 class="title">Gothic Studio</h1>
                        <div class="history-content">
                            <h4 class="subtitle">Founded in Lebanon in 1967, Archo Architecture Company (KCC) has grown to become one of the Middle East's leading construction contractors.</h4>
                            <p>We specialise in complex and prestigious construction and infrastructure projects. Our portfolio includes some of the region’s most iconic landmarks, from super high-rise luxury developments, to five star hotels, hospitals and intricately sophisticated smart buildings. </p>
                            <p>We have compiled an extensive list of other area clinics and health resources, so that when someone calls.</p>
                        </div>
                        <div class="signature">
                            <img src="/images/icon/sign.png" alt="Sign">
                            <h4 class="title">Daniel JR</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>