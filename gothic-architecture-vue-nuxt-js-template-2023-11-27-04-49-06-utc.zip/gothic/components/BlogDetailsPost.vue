<template>
    <div class="blog-details-wrapper">
        <div class="blog-detils-image">
            <img class="fit-image" src="/images/news/blog/large-blog.jpg" alt="Project">
        </div>

        <div class="section-padding-top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-10 offset-xl-2 offset-lg-1">
                        <!-- Blog Details cntent Start -->
                        <div class="blog-details-content" data-aos="fade-up" data-aos-delay="300">
                            <div class="inner-container">

                                <!-- Page Breadcrumbs Start -->
                                <ul class="page-breadcrumb">
                                    <li><n-link to="/">Home</n-link></li>
                                    <li><n-link to="/blog">Blog</n-link></li>
                                    <li>Nordic Interior STyle</li>
                                </ul>
                                <!-- Page Breadcrumbs End -->

                                <!-- Title Start -->
                                <h1 class="title">Nordic Interior Style</h1>
                                <!-- Title End -->

                                <!-- Info List Start -->
                                <ul class="info-list">
                                    <li>Dec 23, 2021</li>
                                    <li>news</li>
                                </ul>
                                <!-- Info List End -->

                                <!-- Big Text Start -->
                                <div class="big-text">To mark the first UK show of artist <br> Henri Barande, graphic designer Alex Maxell and German studio Schultzschultz have created <br> The Lodge Wooden</div>
                                <!-- Big Text End -->

                                <p>This response is important for our ability to learn from mistakes, but it also <br> gives rise to self-criticism, because it is part of the threat-protection system. In other words, what keeps us safe can go too far, and keep us too safe. In fact <br> it can trigger self-censoring.</p>

                                <!-- List Style One Start -->
                                <ul class="list-style-one">
                                    <li>Welsh novelist Sarah Waters sums it up eloquently</li>
                                    <li>In their classic book, Creativity in Business, based on a popular course they co-taught</li>
                                    <li>Novelist and screenwriter Steven Pressfield</li>
                                    <li>A possible off-the-wall idea or solution appears like a blip and disappears without us</li>
                                </ul>
                                <!-- List Style One End -->

                                <!-- Sub Title Start -->
                                <h3 class="sub-title">Defaulting to Mindfulness</h3>
                                <!-- Sub Title End -->

                                <p>Everything along the way, to and from, fascinated her: every pebble, ant, stick, leaf, blade of grass, and crack in the sidewalk was something to be picked up, looked at, tasted, smelled, and shaken. Everything was interesting to her. She knew nothing. <br>I knew everything…been there, done that. She was in the moment, I was in the past. She was mindful. I was mindless.</p>

                                <!-- BlockQuote -->
                                <blockquote class="blockquote">
                                    <p>Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time.</p>
                                    <footer class="blockquote-footer">
                                        <h2 class="title-name">John Doe</h2>
                                        <h4 class="title-desig">Project Director</h4>
                                    </footer>
                                </blockquote>
                                <!-- End BlockQuote -->

                                <p>Both of these assumptions, of course, could be entirely false. Self-censoring is firmly rooted in our experiences with mistakes in the past and not the present. The brain messages arising from those experiences can be deceptive. </p>

                                <!-- Post Share Options Start -->
                                <div class="post-share-options">
                                    <div class="post-share-inner">
                                        <div class="post-title">Tags:</div>
                                        <ul class="tags">
                                            <li><a href="#">Construction,</a></li>
                                            <li><a href="#">Building,</a></li>
                                            <li><a href="#">Structure,</a></li>
                                        </ul><br>
                                        <ul class="social-box">
                                            <li class="facebook">
                                                <a href="#"><i class="icofont-facebook"></i></a>
                                            </li>
                                            <li class="twitter">
                                                <a href="#"><i class="icofont-twitter"></i></a>
                                            </li>
                                            <li class="linkedin">
                                                <a href="#"><i class="icofont-linkedin"></i></a>
                                            </li>
                                            <li class="rss">
                                                <a href="#"><i class="icofont-rss"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Post Share Options End -->

                            </div>
                        </div>
                        <!-- Blog Details cntent End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>

<style lang="scss" scoped>

</style>