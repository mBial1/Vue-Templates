<template>
    <div class="work-image-bg">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="content">
                        <h4 class="subtitle" data-aos="fade-up" data-aos-delay="300">how we work</h4>
                        <h2 class="title" data-aos="fade-up" data-aos-delay="300">Easy &amp; Trusted <br> Progress</h2>
                        <p data-aos="fade-up" data-aos-delay="300">We understand that you’re hiring us to actually listen, and more <br> importantly, understand your vision, so that your home reflects your spirit and <br> personality, not ours. Above all else, when the project is finished, <br> we want you to  LOVE WHERE YOU LIVE</p>
                        <a href="#" class="pdf-file" data-aos="fade-up" data-aos-delay="300"><span class="icon icofont-file-pdf"></span>Download Offer [.PDF]</a>

                            <a href="https://www.youtube.com/watch?v=eS9Qm4AOOBY" target="_blank" class="video-box clearfix" data-aos="fade-up" data-aos-delay="300">
                                See How we work
                                <span class="fa-play icofont-play"><i class="ripple "></i></span>
                            </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>