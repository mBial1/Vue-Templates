<template>
    <footer class="section-padding-top bg-light overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Footer Logo Start -->
                    <div class="footer-logo">
                        <nuxt-link to="/">
                            <img src="/images/logo/logo-black.png" alt="Logo Black" />
                        </nuxt-link>
                    </div>
                    <!-- Footer Logo End -->

                    <!-- Footer Nav Start -->
                    <ul class="footer-nav mb-n3">
                        <li class="mb-3">
                            <nuxt-link to="/">Home</nuxt-link>
                        </li>
                        <li class="mb-3">
                            <nuxt-link to="/project">Project</nuxt-link>
                        </li>
                        <li class="mb-3">
                            <nuxt-link to="/blog">Blogs</nuxt-link>
                        </li>
                        <li class="mb-3">
                            <nuxt-link to="/about">About</nuxt-link>
                        </li>
                        <li class="mb-3">
                            <nuxt-link to="/contact">Contact</nuxt-link>
                        </li>
                    </ul>
                    <!-- Footer Nav End -->

                    <!-- Contact Info Start -->
                    <div class="contact-info">Your address goes here<br> <a href="tel:0123456789">0123456789</a> <br> <a href="mailto:demo@example.com">demo@example.com</a></div>
                    <!-- Contact Info End -->

                    <!-- Footer Social Icons Start -->
                    <ul class="footer-social-icons social-media-link justify-content-center">
                        <li>
                            <a href="#" target="_blank" class="icofont-facebook"></a>
                        </li>
                        <li>
                            <a href="#" target="_blank" class="icofont-twitter"></a>
                        </li>
                        <li>
                            <a href="#" target="_blank" class="icofont-instagram"></a>
                        </li>
                        <li>
                            <a href="#" target="_blank" class="icofont-linkedin"></a>
                        </li>
                        <li>
                            <a href="#" target="_blank" class="icofont-pinterest"></a>
                        </li>
                    </ul>
                    <!-- Footer Social Icons End -->

                    <!-- Copyright Start -->
                    <div class="copyright">© 2023 <span>GOTHIC</span> Made with <i class="icofont-heart-alt text-danger"></i> by <a href="#">HasThemes</a></div>
                    <!-- Copyright End -->
                </div>
            </div>
        </div>
    </footer>
</template>