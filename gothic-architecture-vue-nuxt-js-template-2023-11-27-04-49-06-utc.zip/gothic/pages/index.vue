<template>
    <div class="main-container">
        <TheHeader />
        <OffCanvasMobileMenu />
        <HeroOne />
        <AboutOne />
        <Features />
        <CounterUp />
        <GalleryOne />
        <Testimonial />
        <BrandLogoCarousel />
        <BlogStyleOne />
        <Footer />
    </div>
</template>


