<template>
    <div class="main-container">
        <TheHeader />
        <OffCanvasMobileMenu />
        <BannerOne />
        <AboutOne />
        <Features />
        <CounterUp />
        <VideoCallToAction />
        <TeamOne />
        <Testimonial />
        <BrandLogoCarousel />
        <Footer />
    </div>
</template>


