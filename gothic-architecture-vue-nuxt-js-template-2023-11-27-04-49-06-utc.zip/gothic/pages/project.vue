<template>
    <div class="main-container">
        <TheHeaderTwo />
        <OffCanvasMobileMenu />
        <Breadcrumb activeText="All Project" pageTitle="Our Project" />
        <GalleryWrapper />
        <Footer />
    </div>
</template>


