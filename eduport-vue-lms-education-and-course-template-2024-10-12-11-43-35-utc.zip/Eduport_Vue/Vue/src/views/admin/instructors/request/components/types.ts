export type RequestType = {
  name: string
  image: string
  skills: string
  date: string
  status: string
}
