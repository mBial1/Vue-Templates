export type TopRatedRType = {
  image: string;
  title: string;
  views: number;
  rating: number;
};