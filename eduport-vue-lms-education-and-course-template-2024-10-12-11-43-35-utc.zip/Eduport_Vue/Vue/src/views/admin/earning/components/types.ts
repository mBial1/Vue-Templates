export type EarningType = {
  id: string;
  title: string;
  date: string;
  client_logo: string;
  amount: number;
  status: string;
  type: string;
};