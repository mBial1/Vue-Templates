<template>
  <b-row class="g-4 mb-4">
    <b-col sm="6" lg="4">
      <div class="text-center p-4 bg-primary bg-opacity-10 border border-primary rounded-3">
        <h6>Total Courses</h6>
        <h2 class="mb-0 fs-1 text-primary">1200</h2>
      </div>
    </b-col>

    <b-col sm="6" lg="4">
      <div class="text-center p-4 bg-success bg-opacity-10 border border-success rounded-3">
        <h6>Activated Courses</h6>
        <h2 class="mb-0 fs-1 text-success">996</h2>
      </div>
    </b-col>

    <b-col sm="6" lg="4">
      <div class="text-center p-4  bg-warning bg-opacity-15 border border-warning rounded-3">
        <h6>Pending Courses</h6>
        <h2 class="mb-0 fs-1 text-warning">200</h2>
      </div>
    </b-col>
  </b-row>
</template>