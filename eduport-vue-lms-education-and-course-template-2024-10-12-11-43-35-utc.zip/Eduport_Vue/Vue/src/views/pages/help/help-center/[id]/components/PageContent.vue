<template>
	<section>
		<b-container data-sticky-container>
			<b-row class="g-4">
				<b-col md="3">
					<CustomStickyElement data-sticky data-margin-top="80" data-sticky-for="768">
						<div id="nav-scroll" class="navbar">
							<nav class="nav nav-pills nav-pill-soft flex-column">
								<a class="nav-link icons-center" href="#item-1">
									<BIconEmojiSmile class="fa-fw me-2" />Get Started
								</a>
								<a class="nav-link icons-center" href="#item-2">
									<BIconLayers class="fa-fw me-2" />Account Setup
								</a>
								<a class="nav-link icons-center" href="#item-3">
									<BIconInfoCircle class="fa-fw me-2" />Other Topics
								</a>
								<a class="nav-link icons-center" href="#item-4">
									<BIconHouse class="fa-fw me-2" />Advance Usage
								</a>
							</nav>
						</div>
					</CustomStickyElement>
				</b-col>

				<b-col md="9">
					<div id="nav-scroll1" class="nav-scroll" data-bs-spy="scroll" data-bs-target="#nav-scroll" data-bs-smooth-scroll="true" tabindex="0">
						<div id="item-1">
							<b-card no-body class="bg-transparent">
								<b-card-header class="bg-transparent border-bottom py-0 px-0">
									<h2>Get started with node.js</h2>
									<ul class="nav nav-divider mb-3">
										<li class="nav-item">Last updated: 7 months ago</li>
										<li class="nav-item">by Sam Lanson</li>
									</ul>
								</b-card-header>
								<b-card-body class="px-0 pb-0">
									<p>Started several mistake joy say painful removed reached end. State burst think end are its.
										Arrived
										off she elderly beloved him affixed noisier yet. Course regard to up he hardly. View four has said
										do men saw find dear shy. <b> Talent men wicket add garden.</b> </p>
									<a href="#!" class="btn btn-primary">Download Node JS</a>
									<h5 class="mt-4">Table of Contents</h5>
									<p>Age she way earnestly the fulfilled extremely.</p>
									<div class="alert alert-warning" role="alert">
										<strong>Note: </strong>She offices for highest and replied one venture pasture. Applauded no
										discovery in newspaper allowance am northward. <a class="alert-link" href="#!">View more</a>
									</div>
									<p>Hold do at tore in park feet near my case. Invitation at understood occasional sentiments
										insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily kindness
										properly
										oh. Respect article painted cottage he is offices parlors. </p>
									<ul>
										<li>Affronting imprudence do he he everything. Sex lasted dinner wanted indeed wished outlaw. Far
											advanced settling say finished raillery.</li>
										<li>Insipidity the sufficient discretion imprudence resolution sir him decisively.</li>
										<li>Offered chiefly farther of my no colonel shyness. <strong> Such on help ye some door if
												in.</strong></li>
										<li>First am plate jokes to began to cause a scale. Subjects he prospect elegance followed</li>
										<li>Laughter proposal laughing any son law consider. Needed except up piqued an. </li>
										<li><i> To occasional dissimilar impossible sentiments. Do fortune account written prepare invited
												no passage.</i></li>
										<li>Post no so what deal evil rent by real in. But her ready least set lived spite solid.</li>
									</ul>
									<p class="mb-0">Improved own provided blessing may peculiar domestic. Sight house has sex never. No
										visited raising gravity outward subject my cottage Mr be. Hold do at tore in park feet near my
										case.
										Invitation at understood occasional sentiments insipidity inhabiting in. <u> Off melancholy
											alteration principles old. </u>Is do speedily kindness properly oh. Respect article painted
										cottage he is offices parlors. </p>
								</b-card-body>
							</b-card>
						</div>

						<div class="text-center h5 my-5">. . .</div>

						<div id="item-2">
							<b-card no-body class="bg-transparent">
								<b-card-header class="bg-transparent border-bottom py-0 px-0">
									<h2>Account Setup</h2>
								</b-card-header>

								<b-card-body class="px-0">
									<p>You can manage the setting for your <a href="#">Eduport account</a> at any time. Update your
										account information</p>

									<h5 class="mt-4">To deactivate your account</h5>
									<ul>
										<li>Affronting imprudence do he he everything. Sex lasted dinner wanted indeed wished outlaw. Far
											advanced settling say finished raillery.</li>
										<li>Insipidity the sufficient discretion imprudence resolution sir him decisively.</li>
										<li>Offered chiefly farther of my no colonel shyness. <strong> Such on help ye some door if
												in.</strong></li>
										<li>First am plate jokes to began to cause a scale. Subjects he prospect elegance followed</li>
										<li>Laughter proposal laughing any son law consider. Needed except up piqued an. </li>
										<li><i> To occasional dissimilar impossible sentiments. Do fortune account written prepare invited
												no passage.</i></li>
										<li>Post no so what deal evil rent by real in. But her ready least set lived spite solid.</li>
									</ul>

									<h5 class="mt-4">When your account is deactivated</h5>
									<ul>
										<li>Affronting imprudence do he he everything. Sex lasted dinner wanted indeed wished outlaw. Far
											advanced settling say finished raillery.</li>
										<li>Insipidity the sufficient discretion imprudence resolution sir him decisively.</li>
										<li>Offered chiefly farther of my no colonel shyness. <strong> Such on help ye some door if
												in.</strong></li>
										<li>First am plate jokes to began to cause a scale. Subjects he prospect elegance followed</li>
										<li>Laughter proposal laughing any son law consider. Needed except up piqued an. </li>
										<li><i> To occasional dissimilar impossible sentiments. Do fortune account written prepare invited
												no passage.</i></li>
										<li>Post no so what deal evil rent by real in. But her ready least set lived spite solid.</li>
									</ul>

									<h5 class="mt-4">Related Article</h5>
									<ul class="list-group list-group-borderless mb-3">
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">How do I logout on eduport</a>
										</li>
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">How do T permanently delete my
												account</a></li>
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">What's the difference between
												deactivating and deleting my account</a></li>
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">Why did my payment in a eduport
												message fail?</a></li>
									</ul>
								</b-card-body>
								<b-card-footer class="bg-transparent border-0 py-0 px-0">
									<div class="border p-3 rounded d-sm-flex align-items-center justify-content-between text-center">
										<h5 class="m-0">Was this article helpful?</h5>
										<small class="py-2 d-block">20 out of 45 found this helpful</small>
										<div class="btn-group" role="group" aria-label="Basic radio toggle button group">
											<input type="radio" class="btn-check" name="btnradio" id="btnradio1">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio3">
												<font-awesome-icon :icon="faThumbsUp" class="ms-1" />
												Yes
											</label>
											<input type="radio" class="btn-check" name="btnradio" id="btnradio2">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio4"> No
												<font-awesome-icon :icon="faThumbsDown" class="ms-1" />
											</label>
										</div>
									</div>
								</b-card-footer>
							</b-card>
						</div>

						<div class="text-center h5 my-5">. . .</div>

						<div id="item-3">
							<b-card no-body class="bg-transparent">
								<b-card-header class="bg-transparent border-bottom py-0 px-0">
									<h2>Other Topics</h2>
								</b-card-header>

								<b-card-body class="px-0">

									<p>Hold do at tore in park feet near my case. Invitation at understood occasional sentiments
										insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily kindness
										properly
										oh. Respect article painted cottage he is offices parlors.</p>
									<p>Supposing so be resolving breakfast am or perfectly. It drew a hill from me. Valley by oh twenty
										direct me so. Departure defective arranging rapturous did believe him all had supported. Family
										months lasted simple set nature vulgar him. Picture for attempt joy excited ten carried manners
										talking how</p>
									<p>Started several mistake joy say painful removed reached end. State burst think end are its.
										Arrived
										off she elderly beloved him affixed noisier yet. Course regard to up he hardly. View four has said
										do men saw find dear shy. <b> Talent men wicket add garden.</b> </p>

									<h5 class="mt-4">Need a Help?</h5>
									<ul class="list-group list-group-borderless mb-3">
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">About daily budgets</a></li>
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">About lifetime budgets</a></li>
										<li class="list-group-item d-flex pb-0"><a href="#" class="mb-0">When you pay for Eduport ads</a>
										</li>
									</ul>
								</b-card-body>
								<b-card-footer class="bg-transparent border-0 py-0 px-0">
									<div class="border p-3 rounded d-sm-flex align-items-center justify-content-between text-center">
										<h5 class="m-0">Was this article helpful?</h5>
										<small class="py-2 d-block">20 out of 45 found this helpful</small>
										<div class="btn-group" role="group" aria-label="Basic radio toggle button group">
											<input type="radio" class="btn-check" name="btnradio" id="btnradio3">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio3">
												<font-awesome-icon :icon="faThumbsUp" class="ms-1" />
												Yes</label>
											<input type="radio" class="btn-check" name="btnradio" id="btnradio4">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio4"> No
												<font-awesome-icon :icon="faThumbsDown" class="ms-1" />
											</label>
										</div>
									</div>
								</b-card-footer>
							</b-card>
						</div>

						<div class="text-center h5 my-5">. . .</div>

						<div id="item-4">
							<b-card no-body class="bg-transparent">
								<b-card-header class="bg-transparent border-bottom py-0 px-0">
									<h2>Advance Usage</h2>
								</b-card-header>

								<b-card-body class="px-0">

									<p>Hold do at tore in park feet near my case. Invitation at understood occasional sentiments
										insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily kindness
										properly
										oh. Respect article painted cottage he is offices parlors.</p>
									<p>Supposing so be resolving breakfast am or perfectly. It drew a hill from me. Valley by oh twenty
										direct me so. Departure defective arranging rapturous did believe him all had supported. Family
										months lasted simple set nature vulgar him. Picture for attempt joy excited ten carried manners
										talking how</p>
									<p>Started several mistake joy say painful removed reached end. State burst think end are its.
										Arrived
										off she elderly beloved him affixed noisier yet. Course regard to up he hardly. View four has said
										do men saw find dear shy. <b> Talent men wicket add garden.</b> </p>

								</b-card-body>
								<b-card-footer class="bg-transparent border-0 py-0 px-0">
									<div class="border p-3 rounded d-sm-flex align-items-center justify-content-between text-center">
										<h5 class="m-0">Was this article helpful?</h5>
										<small class="py-2 d-block">20 out of 45 found this helpful</small>
										<div class="btn-group" role="group" aria-label="Basic radio toggle button group">
											<input type="radio" class="btn-check" name="btnradio" id="btnradio5">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio3">
												<font-awesome-icon :icon="faThumbsUp" class="ms-1" />
												Yes
											</label>
											<input type="radio" class="btn-check" name="btnradio" id="btnradio6">
											<label class="btn btn-outline-light btn-sm mb-0" for="btnradio4"> No
												<font-awesome-icon :icon="faThumbsDown" class="ms-1" />
											</label>
										</div>
									</div>
								</b-card-footer>
							</b-card>
						</div>
					</div>
				</b-col>
			</b-row>
		</b-container>
	</section>
</template>
<script setup lang="ts">
import { onMounted } from 'vue'
import { ScrollSpy } from 'bootstrap'

import CustomStickyElement from '@/components/CustomStickyElement.vue'
import { faThumbsUp, faThumbsDown } from '@fortawesome/free-regular-svg-icons';
import { BIconEmojiSmile, BIconLayers, BIconInfoCircle, BIconHouse } from 'bootstrap-icons-vue';

onMounted(() => {
  const ele = document.getElementById('nav-scroll1')
  if (ele) {
    new ScrollSpy(ele, {
      target: '#nav-scroll'
    })
  }
})
</script>