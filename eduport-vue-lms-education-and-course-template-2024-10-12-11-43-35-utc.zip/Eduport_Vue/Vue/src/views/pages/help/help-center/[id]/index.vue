<template>
	<TopBar6 />
	<PageBanner />
	<PageContent />
	<Footer4 />
</template>
<script setup lang="ts">
import TopBar6 from '@/views/pages/help/help-center/[id]/components/TopBar6.vue';
import Footer4 from '@/views/pages/help/help-center/[id]/components/Footer4.vue';
import PageBanner from '@/views/pages/help/help-center/[id]/components/PageBanner.vue';
import PageContent from '@/views/pages/help/help-center/[id]/components/PageContent.vue';
</script>