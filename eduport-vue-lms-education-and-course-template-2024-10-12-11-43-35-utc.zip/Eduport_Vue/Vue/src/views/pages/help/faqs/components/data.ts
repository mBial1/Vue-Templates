import type { FAQType } from "@/types";

export const faqsList: FAQType[] = [
  {
    question: 'How can we help?',
    answer: `Yet remarkably appearance gets him his projection. Diverted endeavor bed peculiar men the not
                  desirous. Acuteness abilities ask can offending furnished fulfilled sex. Warrant fifteen exposed
                  ye at mistake. Blush since so in noisy still built up an again. As young ye hopes no he place
                  means. Partiality diminution gay yet entreaties admiration. In mention perhaps attempt pointed
                  suppose. Unknown ye chamber of warrant of Norland arrived.` },
  {
    question: 'How to edit my Profile?',
    answer: `What deal evil rent by real in. But her ready least set lived spite solid. September how men saw
                  tolerably two behavior arranging. She offices for highest and replied one venture pasture.
                  Applauded no discovery in newspaper allowance am northward. Frequently partiality possession
                  resolution at or appearance unaffected me. Engaged its was the evident pleased husband. Ye
                  goodness felicity do disposal dwelling no. First am plate jokes to began to cause a scale.
                  Subjects he prospect elegance followed no overcame possible it on. Improved own provided blessing
                  may peculiar domestic. Sight house has sex never. No visited raising gravity outward subject my
                  cottage Mr be.` },
  {
    question: 'How much should I offer the sellers?',
    answer: `Post no so what deal evil rent by real in. But her ready least set lived spite solid. September
                  how men saw tolerably two behavior arranging. She offices for highest and replied one venture
                  pasture. Applauded no discovery in newspaper allowance am northward. Frequently partiality
                  possession resolution at or appearance unaffected me. Engaged its was the evident pleased husband.
                  Ye goodness felicity do disposal dwelling no. First am plate jokes to began to cause a scale.
                  Subjects he prospect elegance followed no overcame possible it on. Improved own provided blessing
                  may peculiar domestic. Sight house has sex never. No visited raising gravity outward subject my
                  cottage Mr be. Hold do at tore in park feet near my case. Invitation at understood occasional
                  sentiments insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily
                  kindness properly oh. Respect article painted cottage he is offices parlors.` },
  {
    question: 'Installation Guide',
    answer: `<p>What deal evil rent by real in. But her ready least set lived spite solid. September how men
                    saw tolerably two behavior arranging. She offices for highest and replied one venture pasture.
                    Applauded no discovery in newspaper allowance am northward. Frequently partiality possession
                    resolution at or appearance unaffected me. Engaged its was the evident pleased husband. Ye
                    goodness felicity do disposal dwelling no. First am plate jokes to began to cause a scale.
                    Subjects he prospect elegance followed no overcame possible it on. Improved own provided
                    blessing may peculiar domestic. Sight house has sex never. No visited raising gravity outward
                    subject my cottage Mr be.</p>
                  <p class="mb-0">At the moment, we only accept Credit/Debit cards and Paypal payments. Paypal is
                    the easiest way to make payments online. While checking out your order. Be sure to fill in
                    correct details for fast & hassle-free payment processing.</p>` },
  {
    question: 'Additional Options and Services',
    answer: `Post no so what deal evil rent by real in. But her ready least set lived spite solid. September
                  how men saw tolerably two behavior arranging. She offices for highest and replied one venture
                  pasture. Applauded no discovery in newspaper allowance am northward. Frequently partiality
                  possession resolution at or appearance unaffected me. Engaged its was the evident pleased husband.
                  Ye goodness felicity do disposal dwelling no. First am plate jokes to began to cause a scale.
                  Subjects he prospect elegance followed no overcame possible it on. Improved own provided blessing
                  may peculiar domestic. Sight house has sex never. No visited raising gravity outward subject my
                  cottage Mr be. Hold do at tore in park feet near my case. Invitation at understood occasional
                  sentiments insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily
                  kindness properly oh. Respect article painted cottage he is offices parlors.` },
  {
    question: `What's are the difference between a college and a university?`,
    answer: `Post no so what deal evil rent by real in. But her ready least set lived spite solid. September
                  how men saw tolerably two behavior arranging. She offices for highest and replied one venture
                  pasture. Applauded no discovery in newspaper allowance am northward. Frequently partiality
                  possession resolution at or appearance unaffected me. Engaged its was the evident pleased husband.
                  Ye goodness felicity do disposal dwelling no. First am plate jokes to began to cause a scale.
                  Subjects he prospect elegance followed no overcame possible it on. Improved own provided blessing
                  may peculiar domestic. Sight house has sex never. No visited raising gravity outward subject my
                  cottage Mr be. Hold do at tore in park feet near my case. Invitation at understood occasional
                  sentiments insipidity inhabiting in. Off melancholy alteration principles old. Is do speedily
                  kindness properly oh. Respect article painted cottage he is offices parlors.` },
];