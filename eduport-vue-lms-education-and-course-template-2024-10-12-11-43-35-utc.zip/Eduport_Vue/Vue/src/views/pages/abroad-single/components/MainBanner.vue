<template>
  <section class="bg-light">
    <b-container>
      <b-row class="position-relative pb-4">
        <b-col lg="8" class="position-relative">
          <h1>Study in Canada for international students</h1>
          <p>
            For who thoroughly her boy estimating conviction. Removed demands expense account in outward tedious do.
            Particular way thoroughly unaffected projection favorable Mrs can be projecting own. Thirty it matter enable
            become admire in giving.
          </p>
        </b-col>
      </b-row>
      <div class="h-300px mb-n9 rounded-3"
        :style="`background-image:url(${bg05}); background-position: center left; background-size: cover;`">
      </div>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import bg05 from '@/assets/images/bg/05.jpg';
</script>