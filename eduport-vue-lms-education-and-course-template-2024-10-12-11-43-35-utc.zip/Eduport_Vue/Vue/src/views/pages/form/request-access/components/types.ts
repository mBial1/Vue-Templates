export type TestimonialType = {
  content: string;
  avatar: string;
  name: string;
  position: string;
};