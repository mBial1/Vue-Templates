<template>
  <TopBar5 />
  <main>

    <Hero />

    <Client />

    <Testimonials />

    <Newsletter />
  </main>
  <Footer10 />
</template>
<script setup lang="ts">
import TopBar5 from '@/views/pages/form/request-access/components/TopBar5.vue';
import Hero from '@/views/pages/form/request-access/components/Hero.vue';
import Client from '@/views/pages/form/request-access/components/Client.vue';
import Testimonials from '@/views/pages/form/request-access/components/Testimonials.vue';
import Newsletter from '@/views/pages/form/request-access/components/Newsletter.vue';
import Footer10 from '@/views/pages/form/request-access/components/Footer10.vue';
</script>