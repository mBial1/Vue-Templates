export type ContactInfo = {
  name: string;
  address: string;
  phone: string;
  email: string;
}
