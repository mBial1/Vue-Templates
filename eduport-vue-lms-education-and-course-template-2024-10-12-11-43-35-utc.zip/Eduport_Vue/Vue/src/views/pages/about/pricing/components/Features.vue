<template>
	<section>
		<b-container>
			<b-row>
				<b-col md="8" class="text-center mx-auto mb-4">
					<h2>Full Features List</h2>
					<p class="mb-0">Perceived end knowledge certainly day sweetness why cordially</p>
				</b-col>
			</b-row>

			<b-row class="mb-5">
				<b-col lg="10" class="mx-auto">
					<div class="bg-light p-3 rounded-3">
						<b-row class="align-items-center">
							<b-col md="6" class="text-center text-md-start">
								<h5 class="mb-2 mb-md-0">Template Feature</h5>
							</b-col>
							<b-col md="6">
								<b-row>
									<b-col cols="4" class="text-center py-2">
										<h6 class="mb-0">Basic</h6>
									</b-col>
									<b-col cols="4" class="text-center py-2">
										<h6 class="mb-0">Professional</h6>
									</b-col>
									<b-col cols="4" class="text-center py-2">
										<h6 class="mb-0">Premium</h6>
									</b-col>
								</b-row>
							</b-col>
						</b-row>
					</div>

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Up to 05 users monthly</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Free 5 host & domain</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Custom infrastructure</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Access to all our room</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
				</b-col>
			</b-row>
			<b-row class="mb-5">
				<b-col lg="10" class="mx-auto">
					<b-row>
						<b-col cols="12" class="bg-light p-3 rounded-3">
							<b-row class="align-items-center">
								<b-col md="6" class="text-center text-md-start">
									<h5 class="mb-2 mb-md-0">Support team member growth</h5>
								</b-col>
								<b-col md="6">
									<b-row>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Basic</h6>
										</b-col>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Professional</h6>
										</b-col>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Premium</h6>
										</b-col>
									</b-row>
								</b-col>
							</b-row>
						</b-col>
					</b-row>

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Team Goals</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Free 5 host & domain</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">

								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Custom infrastructure</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">

								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-2 mb-md-0">Access to all our room</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center">

								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">

								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
				</b-col>
			</b-row>
			<b-row>
				<b-col lg="10" class="mx-auto">
					<b-row>
						<b-col cols="12" class="bg-light p-3 rounded-3">
							<b-row class="align-items-center">
								<b-col md="6" class="text-center text-md-start">
									<h5 class="mb-2 mb-md-0">Connectivity</h5>
								</b-col>
								<b-col md="6">
									<b-row>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Basic</h6>
										</b-col>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Professional</h6>
										</b-col>
										<b-col cols="4" class="text-center py-2">
											<h6 class="mb-0">Premium</h6>
										</b-col>
									</b-row>
								</b-col>
							</b-row>
						</b-col>
					</b-row>

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">API Access</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center"></b-col>
								<b-col cols="4" class="d-flex justify-content-center"></b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success">
										<font-awesome-icon :icon="faCheck" />
									</div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
					<hr class="m-0">

					<b-row class="align-items-center p-3">
						<b-col md="6" class="text-center text-md-start">
							<h6 class="mb-3 mb-md-0">Premium Add-ons</h6>
						</b-col>
						<b-col md="6" class="pt-2 pt-md-0">
							<b-row>
								<b-col cols="4" class="d-flex justify-content-center"></b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
								<b-col cols="4" class="d-flex justify-content-center">
									<div class="icon-md bg-success bg-opacity-10 rounded-circle text-success"><font-awesome-icon
											:icon="faCheck" /></div>
								</b-col>
							</b-row>
						</b-col>
					</b-row>
				</b-col>
			</b-row>
		</b-container>
	</section>
</template>
<script setup lang="ts">
import { faCheck } from '@fortawesome/free-solid-svg-icons';
</script>