export type GridListType = {
  image: string;
  badge: string;
  badgeColor: string;
  title: string;
  description: string;
  author: string;
  time: string;
}; 