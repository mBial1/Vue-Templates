export type BlogType = {
  img: string;
  title: string;
  timestamp: string;
};