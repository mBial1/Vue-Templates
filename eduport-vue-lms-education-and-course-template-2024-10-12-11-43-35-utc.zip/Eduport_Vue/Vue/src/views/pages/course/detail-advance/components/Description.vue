<template>
  <b-col cols="12">
    <b-card no-body class="border">
      <b-card-header class="border-bottom">
        <h3 class="mb-0">Course description</h3>
      </b-card-header>

      <b-card-body>
        <p class="mb-3">Welcome to the <strong> Digital Marketing Ultimate Course Bundle - 12 Courses in 1
            (Over 36 hours of content)</strong></p>
        <p class="mb-3">In this practical hands-on training, you’re going to learn to become a digital
          marketing expert with this <strong> ultimate course bundle that includes 12 digital marketing
            courses in 1!</strong></p>
        <p class="mb-0">If you wish to find out the skills that should be covered in a basic digital
          marketing course syllabus in India or anywhere around the world, then reading this blog will help.
          Before we delve into the advanced <strong><a href="#" class="text-reset text-decoration-underline">digital
              marketing course</a></strong> syllabus,
          let’s look at the scope of digital marketing and what the future holds.</p>
        <b-collapse id="collapseContent">
          <p class="my-3">We focus a great deal on the understanding of behavioral psychology and influence
            triggers which are crucial for becoming a well rounded Digital Marketer. We understand that
            theory is important to build a solid foundation, we understand that theory alone isn’t going to
            get the job done so that’s why this course is packed with practical hands-on examples that you
            can follow step by step.</p>
          <p class="mb-0">Behavioral psychology and influence triggers which are crucial for becoming a well
            rounded Digital Marketer. We understand that theory is important to build a solid foundation, we
            understand that theory alone isn’t going to get the job done so that’s why this course is packed
            with practical hands-on examples that you can follow step by step.</p>
        </b-collapse>
        <a class="p-0 mb-0 mt-2 btn-more d-flex align-items-center" data-bs-toggle="collapse" href="#collapseContent"
          role="button" aria-expanded="false" aria-controls="collapseContent" v-b-toggle="'navbarCollapse'">
          See <span class="see-more ms-1">more</span><span class="see-less ms-1">less</span>
          <font-awesome-icon :icon="faAngleDown" class="ms-2" />
        </a>

        <h5 class="mt-4">What you’ll learn</h5>
        <b-row class="mb-3">
          <b-col md="6">
            <ul class="list-group list-group-borderless">
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Digital marketing course introduction
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Customer Life cycle
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                What is Search engine optimization(SEO)
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Facebook ADS
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Facebook Messenger Chatbot
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Search engine optimization tools
              </li>
            </ul>
          </b-col>
          <b-col md="6">
            <ul class="list-group list-group-borderless">
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Why SEO
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                URL Structure
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Featured Snippet
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                SEO tips and tricks
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Google tag manager
              </li>
            </ul>
          </b-col>
        </b-row>
        <p class="mb-0">As it so contrasted oh estimating instrument. Size like body some one had. Are
          conduct viewing boy minutes warrant the expense? Tolerably behavior may admit daughters offending
          her ask own. Praise effect wishes change way and any wanted. Lively use looked latter regard had.
          Do he it part more last in. </p>
      </b-card-body>
    </b-card>
  </b-col>
</template>
<script setup lang="ts">
import { faAngleDown, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
</script>