<template>
  <b-col cols="12">
    <b-tabs pills nav-class="nav-pills-bg-soft px-3" content-class="pt-4 px-3" nav-item-class="mb-0">
      <b-tab title="Overview" class="fade" title-item-class="me-2 me-sm-4">
        <h5 class="mb-3">Course Description</h5>
        <p class="mb-3">Welcome to the <strong> Digital Marketing Ultimate Course Bundle - 12 Courses in 1
            (Over 36 hours of content)</strong></p>
        <p class="mb-3">In this practical hands-on training, you’re going to learn to become a digital
          marketing expert with this <strong> ultimate course bundle that includes 12 digital marketing
            courses in 1!</strong></p>
        <p class="mb-3">If you wish to find out the skills that should be covered in a basic digital marketing
          course syllabus in India or anywhere around the world, then reading this blog will help. Before we
          delve into the advanced <strong><a href="#" class="text-reset text-decoration-underline">digital
              marketing course</a></strong> syllabus, let’s look at the scope of digital marketing and what
          the future holds.</p>
        <p class="mb-0">We focus a great deal on the understanding of behavioral psychology and influence
          triggers which are crucial for becoming a well rounded Digital Marketer. We understand that theory
          is important to build a solid foundation, we understand that theory alone isn’t going to get the job
          done so that’s why this course is packed with practical hands-on examples that you can follow step
          by step.</p>

        <h5 class="mt-4">What you’ll learn</h5>

        <b-row class="mb-3">
          <b-col md="6">
            <ul class="list-group list-group-borderless">
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Digital marketing course introduction
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Customer Life cycle
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                What is Search engine optimization(SEO)
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Facebook ADS
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Facebook Messenger Chatbot
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Search engine optimization tools
              </li>
            </ul>
          </b-col>

          <b-col md="6">
            <ul class="list-group list-group-borderless">
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Why SEO
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                URL Structure
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Featured Snippet
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                SEO tips and tricks
              </li>
              <li class="list-group-item h6 fw-light d-flex mb-0">
                <font-awesome-icon :icon="faCheckCircle" class="text-success me-2" />
                Google tag manager
              </li>
            </ul>
          </b-col>
        </b-row>

        <p class="mb-0">As it so contrasted oh estimating instrument. Size like body someone had. Are conduct
          viewing boy minutes warrant the expense? Tolerably behavior may admit daughters offending her ask
          own. Praise effect wishes change way and any wanted. Lively use looked latter regard had. Do he it
          part more last in. </p>
      </b-tab>
      <b-tab title="Reviews" class="fade" title-item-class="me-2 me-sm-4">
        <b-row class="mb-4">
          <h5 class="mb-4">Our Student Reviews</h5>

          <b-col md="4" class="mb-3 mb-md-0">
            <div class="text-center">
              <h2 class="mb-0">4.5</h2>
              <ul class="list-inline mb-0 flex-centered hstack gap-1">
                <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                <li class="list-inline-item me-0"><font-awesome-icon :icon="faStarHalfAlt" class="text-warning" /></li>
              </ul>
              <p class="mb-0">(Based on todays review)</p>
            </div>
          </b-col>

          <b-col md="8">
            <b-row class="align-items-center text-center">
              <b-col cols="6" sm="8">
                <b-progress class="progress-sm bg-warning bg-opacity-15">
                  <b-progress-bar class="bg-warning" :value="100" />
                </b-progress>
              </b-col>

              <b-col cols="6" sm="4">
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                </ul>
              </b-col>

              <b-col cols="6" sm="8">
                <b-progress class="progress-sm bg-warning bg-opacity-15">
                  <b-progress-bar class="bg-warning" :value="80" />
                </b-progress>
              </b-col>

              <b-col cols="6" sm="4">
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </b-col>

              <b-col cols="6" sm="8">
                <b-progress class="progress-sm bg-warning bg-opacity-15">
                  <b-progress-bar class="bg-warning" :value="60" />
                </b-progress>
              </b-col>

              <b-col cols="6" sm="4">
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </b-col>

              <b-col cols="6" sm="8">
                <b-progress class="progress-sm bg-warning bg-opacity-15">
                  <b-progress-bar class="bg-warning" :value="40" />
                </b-progress>
              </b-col>

              <b-col cols="6" sm="4">
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </b-col>

              <b-col cols="6" sm="8">
                <b-progress class="progress-sm bg-warning bg-opacity-15">
                  <b-progress-bar class="bg-warning" :value="20" />
                </b-progress>
              </b-col>

              <b-col cols="6" sm="4">
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                  <li class="list-inline-item me-0 small"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </b-col>
            </b-row>
          </b-col>
        </b-row>

        <b-row>
          <div class="d-md-flex my-4">
            <div class="avatar avatar-xl me-4 flex-shrink-0">
              <img class="avatar-img rounded-circle" :src="avatar09" alt="avatar">
            </div>
            <div>
              <div class="d-sm-flex mt-1 mt-md-0 align-items-center">
                <h5 class="me-3 mb-0">Jacqueline Miller</h5>
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </div>
              <p class="small mb-2">2 days ago</p>
              <p class="mb-2">Perceived end knowledge certainly day sweetness why cordially. Ask a quick six
                seven offer see among. Handsome met debating sir dwelling age material. As style lived he
                worse dried. Offered related so visitors we private removed. Moderate do subjects to distance.
              </p>

              <a href="#" class="text-body mb-0"><font-awesome-icon :icon="faReply" class="me-2" />Reply</a>
            </div>
          </div>
          <hr>

          <div class="d-md-flex my-4">
            <div class="avatar avatar-xl me-4 flex-shrink-0">
              <img class="avatar-img rounded-circle" :src="avatar07" alt="avatar">
            </div>
            <div>
              <div class="d-sm-flex mt-1 mt-md-0 align-items-center">
                <h5 class="me-3 mb-0">Dennis Barrett</h5>
                <ul class="list-inline mb-0 hstack gap-1">
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStar" class="text-warning" /></li>
                  <li class="list-inline-item me-0"><font-awesome-icon :icon="faStarR" class="text-warning" /></li>
                </ul>
              </div>
              <p class="small mb-2">2 days ago</p>
              <p class="mb-2">Handsome met debating sir dwelling age material. As style lived he worse dried.
                Offered related so visitors we private removed. Moderate do subjects to distance. </p>
              <a href="#" class="text-body mb-0"><font-awesome-icon :icon="faReply" class="me-2" />Reply</a>
            </div>
          </div>
          <hr>
        </b-row>

        <div class="mt-2">
          <h5 class="mb-4">Leave a Review</h5>
          <b-form class="row g-3">
            <b-col md="6">
              <b-form-input type="text" id="inputtext" placeholder="Name" />
            </b-col>
            <b-col md="6">
              <b-form-input type="email" placeholder="Email" id="inputEmail4" />
            </b-col>
            <b-col cols="12">
              <ChoicesSelect id="inputState2">
                <option selected>★★★★★ (5/5)</option>
                <option>★★★★☆ (4/5)</option>
                <option>★★★☆☆ (3/5)</option>
                <option>★★☆☆☆ (2/5)</option>
                <option>★☆☆☆☆ (1/5)</option>
              </ChoicesSelect>
            </b-col>
            <b-col cols="12">
              <b-form-textarea placeholder="Your review" rows="3" max-rows="6" id="exampleFormControlTextarea1" />
            </b-col>
            <b-col cols="12">
              <b-button type="submit" variant="primary" class="mb-0">Post Review</b-button>
            </b-col>
          </b-form>
        </div>
      </b-tab>
      <b-tab title="FAQs" class="fade" title-item-class="me-2 me-sm-4">
        <h5 class="mb-3">Frequently Asked Questions</h5>
        <div class="mt-4" v-for="(item, idx) in faqsData" :key="idx">
          <h6>{{ item.question }}</h6>
          <p class="mb-0">{{ item.answer }}</p>
        </div>
      </b-tab>
      <b-tab title="Comment" class="fade" title-item-class="me-2 me-sm-4">
        <b-row class="mb-4">
          <b-col cols="12">
            <h5 class="mb-4">Ask Your Question</h5>

            <div class="d-flex mb-4">
              <div class="avatar avatar-sm flex-shrink-0 me-2">
                <a href="#"> <img class="avatar-img rounded-circle" :src="avatar09" alt=""> </a>
              </div>

              <b-form class="w-100 d-flex">
                <b-form-textarea class="one pe-4 bg-light" id="autoheighttextarea" rows="1" placeholder="Add a comment..." />
                <b-button variant="primary" class="ms-2 mb-0" type="button">Post</b-button>
              </b-form>
            </div>

            <div class="border p-2 p-sm-4 rounded-3 mb-4">
              <ul class="list-unstyled mb-0">
                <li class="comment-item">
                  <div class="d-flex mb-3">
                    <div class="avatar avatar-sm flex-shrink-0">
                      <a href="#"><img class="avatar-img rounded-circle" :src="avatar05" alt=""></a>
                    </div>
                    <div class="ms-2">
                      <div class="bg-light p-3 rounded">
                        <div class="d-flex justify-content-center">
                          <div class="me-2">
                            <h6 class="mb-1 lead fw-bold"> <a href="#!"> Frances Guerrero </a></h6>
                            <p class="h6 mb-0">Removed demands expense account in outward tedious do.
                              Particular way thoroughly unaffected projection?</p>
                          </div>
                          <small>5hr</small>
                        </div>
                      </div>
                      <ul class="nav nav-divider py-2 small">
                        <li class="nav-item"> <a class="text-primary-hover" href="#"> Like (3)</a> </li>
                        <li class="nav-item"> <a class="text-primary-hover" href="#"> Reply</a> </li>
                        <li class="nav-item"> <a class="text-primary-hover" href="#"> View 5 replies</a> </li>
                      </ul>
                    </div>
                  </div>

                  <ul class="list-unstyled ms-4">
                    <li class="comment-item">
                      <div class="d-flex">
                        <div class="avatar avatar-xs flex-shrink-0">
                          <a href="#"><img class="avatar-img rounded-circle" :src="avatar06" alt=""></a>
                        </div>
                        <div class="ms-2">
                          <div class="bg-light p-3 rounded">
                            <div class="d-flex justify-content-center">
                              <div class="me-2">
                                <h6 class="mb-1  lead fw-bold"> <a href="#"> Lori Stevens </a> </h6>
                                <p class=" mb-0">See resolved goodness felicity shy civility domestic had but
                                  Drawings offended yet answered Jennings perceive. Domestic had but Drawings
                                  offended yet answered Jennings perceive.</p>
                              </div>
                              <small>2hr</small>
                            </div>
                          </div>
                          <ul class="nav nav-divider py-2 small">
                            <li class="nav-item"><a class="text-primary-hover" href="#!"> Like (5)</a></li>
                            <li class="nav-item"><a class="text-primary-hover" href="#!"> Reply</a> </li>
                          </ul>
                        </div>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>

            <div class="border p-2 p-sm-4 rounded-3">
              <ul class="list-unstyled mb-0">
                <li class="comment-item">
                  <div class="d-flex">
                    <div class="avatar avatar-sm flex-shrink-0">
                      <a href="#"><img class="avatar-img rounded-circle" :src="avatar02" alt=""></a>
                    </div>
                    <div class="ms-2">
                      <div class="bg-light p-3 rounded">
                        <div class="d-flex justify-content-center">
                          <div class="me-2">
                            <h6 class="mb-1 lead fw-bold"> <a href="#!"> Louis Ferguson </a></h6>
                            <p class="h6 mb-0">Removed demands expense account in outward tedious do.
                              Particular way thoroughly unaffected projection?</p>
                          </div>
                          <small>5hr</small>
                        </div>
                      </div>
                      <ul class="nav nav-divider py-2 small">
                        <li class="nav-item"> <a class="text-primary-hover" href="#"> Like</a> </li>
                        <li class="nav-item"> <a class="text-primary-hover" href="#"> Reply</a> </li>
                      </ul>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </b-col>
        </b-row>
      </b-tab>
    </b-tabs>
  </b-col>
</template>
<script setup lang="ts">
import { faqsData } from '@/views/pages/course/detail-minimal/components/data';
import { faCheckCircle, faStar, faStarHalfAlt, faReply } from '@fortawesome/free-solid-svg-icons';
import { faStar as faStarR } from '@fortawesome/free-regular-svg-icons';

import avatar02 from '@/assets/images/avatar/02.jpg';
import avatar05 from '@/assets/images/avatar/05.jpg';
import avatar06 from '@/assets/images/avatar/06.jpg';
import avatar07 from '@/assets/images/avatar/07.jpg';
import avatar09 from '@/assets/images/avatar/09.jpg';
</script>