export type PayoutType = {
  title: string
  amount: number
  status: string
  date: string
}