export type OrderType = {
  title: string;
  order_id: string;
  date: string;
  amount: number;
  payment_method: string;
};