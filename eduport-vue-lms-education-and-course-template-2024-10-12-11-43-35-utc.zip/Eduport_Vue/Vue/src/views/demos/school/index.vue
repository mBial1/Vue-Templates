<template>
  <TopBar9 />
  <main>
    <MainBanner />
    <Subject />
    <About />
    <ActionBox />
    <Gallery />
    <Blog />
  </main>
  <Footer4 />
  <AdmissionAlertBox />
</template>
<script setup lang="ts">
import TopBar9 from '@/views/demos/school/components/TopBar9.vue';
import MainBanner from '@/views/demos/school/components/MainBanner.vue';
import Subject from '@/views/demos/school/components/Subject.vue';
import About from '@/views/demos/school/components/About.vue';
import ActionBox from '@/views/demos/school/components/ActionBox.vue';
import Gallery from '@/views/demos/school/components/Gallery.vue';
import Blog from '@/views/demos/school/components/Blog.vue';
import Footer4 from '@/views/demos/school/components/Footer4.vue';
import AdmissionAlertBox from '@/views/demos/school/components/AdmissionAlertBox.vue';
</script>