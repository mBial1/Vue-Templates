<template>
  <section class="py-0">
    <b-container class="position-relative">
      <b-row>
        <b-col cols="12">
          <div class="bg-light rounded-3 position-relative p-3 p-sm-5">
            <b-row class="g-4 align-items-center">
              <b-col md="6">
                <h6 class="text-primary">Newsletter</h6>
                <h2 class="mb-0">Subscribe Mail list!</h2>
                <p class="mb-0">Speedily say has suitable disposal add boy. On forth doubt miles of child. Exercise
                  joy man children rejoiced.</p>
              </b-col>

              <b-col md="6">
                <b-form class="bg-body rounded-2 p-2">
                  <b-input-group>
                    <b-form-input class="border-0 me-1" type="email" placeholder="Enter your email" />
                    <b-button type="button" :variant="null" class="btn-blue mb-0 rounded-2">Subscribe!</b-button>
                  </b-input-group>
                </b-form>
              </b-col>
            </b-row>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>