<template>
  <TopBar11 />
  <main>
    <MainBanner />
    <Feature />
    <Instructor />
    <ActionBox />
    <TopListed />
    <FAQs />
  </main>
  <Footer8 />
</template>
<script setup lang="ts">
import TopBar11 from '@/views/demos/workshop/components/TopBar11.vue';
import MainBanner from '@/views/demos/workshop/components/MainBanner.vue';
import Feature from '@/views/demos/workshop/components/Feature.vue';
import Instructor from '@/views/demos/workshop/components/Instructor.vue';
import ActionBox from '@/views/demos/workshop/components/ActionBox.vue';
import TopListed from '@/views/demos/workshop/components/TopListed.vue';
import FAQs from '@/views/demos/workshop/components/FAQs.vue';
import Footer8 from '@/views/demos/workshop/components/Footer8.vue';
</script>