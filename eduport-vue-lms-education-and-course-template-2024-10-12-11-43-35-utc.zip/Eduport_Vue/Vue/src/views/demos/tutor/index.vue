<template>
  <TopBar8 />
  <main>

    <MainBanner />

    <Services />

    <Contact />

    <FAQs />

  </main>
  <Footer7 />
</template>
<script setup lang="ts">
import TopBar8 from '@/views/demos/tutor/components/TopBar8.vue'
import MainBanner from '@/views/demos/tutor/components/MainBanner.vue'
import Services from '@/views/demos/tutor/components/Services.vue'
import Contact from '@/views/demos/tutor/components/Contact.vue'
import FAQs from '@/views/demos/tutor/components/FAQs.vue'
import Footer7 from '@/views/demos/tutor/components/Footer7.vue'
</script>