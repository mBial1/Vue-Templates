export type TestimonialType = {
  avatar: string;
  testimonial: string;
  name: string;
};