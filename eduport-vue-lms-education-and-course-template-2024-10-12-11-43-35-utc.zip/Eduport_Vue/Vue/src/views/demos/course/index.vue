<template>
  <TopBar4 />

  <main>

    <MainBanner />

    <VideoSec />

    <Category />

    <FeaturedCourse />

    <ActionBox />

    <ITCourses />

    <LiveCourses />

    <ActionBox2 />

  </main>
  <Footer4 />
  <StickyElement />
</template>
<script setup lang="ts">import TopBar4 from '@/views/demos/course/components/TopBar4.vue';
import MainBanner from '@/views/demos/course/components/MainBanner.vue';
import VideoSec from '@/views/demos/course/components/VideoSec.vue';
import Category from '@/views/demos/course/components/Category.vue';
import FeaturedCourse from '@/views/demos/course/components/FeaturedCourse.vue';
import ActionBox from '@/views/demos/course/components/ActionBox.vue';
import ITCourses from '@/views/demos/course/components/ITCourses.vue';
import LiveCourses from '@/views/demos/course/components/LiveCourses.vue';
import ActionBox2 from '@/views/demos/course/components/ActionBox2.vue';
import Footer4 from '@/views/demos/course/components/Footer4.vue';
import StickyElement from '@/views/demos/course/components/StickyElement.vue';
</script>