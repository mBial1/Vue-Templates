<template>
  <TopBar10 />
  <main>
    <MainBanner />
    <CounterCountries />
    <About />
    <Courses />
    <Client />
    <ActionBox />
    <Contact />
  </main>
  <Footer4 />
</template>
<script setup lang="ts">
import TopBar10 from '@/views/demos/abroad/components/TopBar10.vue';
import MainBanner from '@/views/demos/abroad/components/MainBanner.vue';
import CounterCountries from '@/views/demos/abroad/components/CounterCountries.vue';
import About from '@/views/demos/abroad/components/About.vue';
import Courses from '@/views/demos/abroad/components/Courses.vue';
import Client from '@/views/demos/abroad/components/Client.vue';
import ActionBox from '@/views/demos/abroad/components/ActionBox.vue';
import Contact from '@/views/demos/abroad/components/Contact.vue';
import Footer4 from '@/views/demos/abroad/components/Footer4.vue';
</script>