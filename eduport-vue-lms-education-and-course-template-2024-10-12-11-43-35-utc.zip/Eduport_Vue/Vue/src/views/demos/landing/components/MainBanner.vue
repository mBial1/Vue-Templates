<template>
  <section class="position-relative">
    <figure class="position-absolute top-50 end-0 translate-middle-y mt-n8">
      <svg class="rtl-flip" width="1360.5px" height="793px" viewBox="0 0 1360.5 793"
        style="enable-background:new 0 0 1360.5 793;" xml:space="preserve">
        <path class="fill-primary opacity-1"
          d="M33.5,766.3c75.3-24.2,124.5-20.3,155.2-62.8c35.4-49,53.1-184.7,138-191.2s100.9,55.6,208.8-21.2 s44.5-134.3,166.4-174.9c121.8-40.6,177,80.1,279.6,36s122.1-248.4,178.8-290.9c49.3-37,171.2-56.7,200.2-61.1v793H33.5 C33.5,793-41.9,790.4,33.5,766.3z" />
      </svg>
    </figure>

    <b-container class="position-relative mt-0 mt-sm-5 pt-5">
      <b-row class="align-items-center">
        <b-col md="5">
          <h1 class="mb-3">We will help you Grow your Knowledge and Skills</h1>
          <h6 class="mb-3">1000+ professional Courses for Your Career</h6>
          <a href="#" class="btn btn-primary">Get Started</a>
        </b-col>
        <b-col md="7">
          <img :src="element05" alt="">
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>
<script setup lang="ts">
import element05 from '@/assets/images/element/05.svg';
</script>