<template>
  <TopBar7 />
  <main>

    <MainBanner />

    <About />

    <ListedCourse />

    <Download />

    <ActionBox />

    <ClientFeedback />

  </main>
  <Footer6 />
</template>
<script setup lang="ts">
import TopBar7 from '@/views/demos/landing/components/TopBar7.vue'
import MainBanner from '@/views/demos/landing/components/MainBanner.vue'
import About from '@/views/demos/landing/components/About.vue'
import ListedCourse from '@/views/demos/landing/components/ListedCourse.vue'
import Download from '@/views/demos/landing/components/Download.vue'
import ActionBox from '@/views/demos/landing/components/ActionBox.vue'
import ClientFeedback from '@/views/demos/landing/components/ClientFeedback.vue'
import Footer6 from '@/views/demos/landing/components/Footer6.vue'
</script>