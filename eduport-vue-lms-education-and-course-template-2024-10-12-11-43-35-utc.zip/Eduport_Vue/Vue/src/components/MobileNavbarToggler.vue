<template>
  <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" v-b-toggle="'navbarCollapse'">
    <span class="navbar-toggler-animation">
      <span></span>
      <span></span>
      <span></span>
    </span>
  </button>
</template>